-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 05-12-2024 a las 08:12:52
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `recesur`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `datos_usuarios`
--

CREATE TABLE `datos_usuarios` (
  `id_dato` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `rut` varchar(15) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  `estado_cuenta` enum('activa','desactivada','eliminada') DEFAULT 'activa'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `datos_usuarios`
--

INSERT INTO `datos_usuarios` (`id_dato`, `id_usuario`, `rut`, `telefono`, `fecha_nacimiento`, `estado_cuenta`) VALUES
(2, 2, '23.456.789-0', '987654322', '1992-06-23', 'activa'),
(3, 3, '34.567.890-1', '987654323', '1985-07-15', 'activa'),
(4, 4, '45.678.901-2', '987654324', '1988-09-25', 'activa'),
(5, 5, '56.789.012-3', '987654325', '1991-10-30', 'activa'),
(6, 6, '67.890.123-4', '987654326', '1986-11-12', 'activa'),
(7, 7, '78.901.234-5', '987654327', '1994-12-05', 'activa'),
(8, 8, '89.012.345-6', '987654328', '1990-03-14', 'activa'),
(9, 9, '90.123.456-7', '987654329', '1992-04-02', 'activa'),
(10, 10, '01.234.567-8', '987654330', '1993-01-20', 'activa'),
(11, 11, '12.345.678-9', '987654331', '1990-02-18', 'activa'),
(12, 12, '23.456.789-0', '987654332', '1987-12-09', 'activa'),
(13, 13, '34.567.890-1', '987654333', '1991-08-07', 'activa'),
(14, 14, '45.678.901-2', '987654334', '1994-06-26', 'activa'),
(15, 15, '56.789.012-3', '987654335', '1989-11-17', 'activa'),
(16, 16, '67.890.123-4', '987654336', '1995-01-30', 'activa');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ingredientes`
--

CREATE TABLE `ingredientes` (
  `id_ingrediente` int(11) NOT NULL,
  `nombre_ingrediente` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `ingredientes`
--

INSERT INTO `ingredientes` (`id_ingrediente`, `nombre_ingrediente`) VALUES
(1, 'Arroz'),
(2, 'Pollo'),
(3, 'Zanahoria'),
(4, 'Aceite de oliva'),
(5, 'Sal'),
(6, 'Ajo'),
(7, 'Pimiento'),
(8, 'Tomate'),
(9, 'Pechuga de pollo'),
(10, 'Caldo de pollo'),
(11, 'Frijoles'),
(12, 'Aguacate'),
(13, 'Papas'),
(14, 'Lechuga'),
(15, 'Pepino'),
(16, 'Quinoa'),
(17, 'Tortillas de maíz'),
(18, 'Mozzarella'),
(19, 'Coliflor'),
(20, 'Tomillo'),
(21, 'Comino'),
(22, 'Espinaca'),
(100, 'Garbanzos'),
(101, 'Pepino'),
(102, 'Cebolla morada'),
(103, 'Lechuga'),
(104, 'Tortillas de maíz'),
(105, 'Jengibre'),
(106, 'Leche de coco'),
(107, 'Arroz integral'),
(108, 'Curry en polvo'),
(109, 'Cúrcuma'),
(110, 'Spaghetti'),
(111, 'Carne molida'),
(112, 'Salsa de tomate'),
(113, 'Queso parmesano'),
(114, 'Papas'),
(115, 'Jamón'),
(116, 'Queso mozzarella'),
(117, 'Masa para pizza'),
(118, 'Cebolla'),
(119, 'Hojas de lechuga'),
(120, 'Croutons'),
(121, 'Aderezo César'),
(122, 'Quinoa'),
(123, 'Pepino'),
(124, 'Limón'),
(125, 'Aguacate'),
(126, ' chorizos o salchichas veganas'),
(127, 'Chimichurri');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `lista_compras`
--

CREATE TABLE `lista_compras` (
  `id_lista` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `id_receta` int(11) NOT NULL,
  `id_ingrediente` int(11) NOT NULL,
  `cantidad` varchar(50) NOT NULL,
  `estado` enum('pendiente','comprado') DEFAULT 'pendiente'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `lista_compras`
--

INSERT INTO `lista_compras` (`id_lista`, `id_usuario`, `id_receta`, `id_ingrediente`, `cantidad`, `estado`) VALUES
(1, 13, 15, 110, '', 'comprado'),
(2, 13, 15, 111, '', 'comprado'),
(3, 13, 15, 113, '', 'comprado'),
(4, 13, 15, 110, '', 'comprado'),
(5, 13, 15, 111, '', 'comprado'),
(6, 13, 15, 113, '', 'comprado'),
(7, 13, 15, 110, '', 'comprado'),
(8, 13, 15, 111, '', 'comprado'),
(9, 13, 15, 113, '', 'comprado'),
(11, 13, 15, 4, '', 'comprado'),
(12, 13, 15, 5, '', 'comprado'),
(13, 13, 15, 113, '', 'comprado'),
(14, 13, 12, 2, '', 'comprado'),
(15, 13, 12, 121, '', 'comprado'),
(16, 13, 15, 110, '', 'comprado'),
(17, 13, 15, 113, '', 'comprado'),
(18, 13, 15, 110, '', 'comprado'),
(19, 13, 15, 113, '', 'comprado'),
(20, 13, 12, 2, '', 'comprado'),
(21, 13, 15, 113, '', 'comprado'),
(22, 14, 4, 8, '', 'comprado'),
(23, 14, 4, 12, '', 'comprado'),
(24, 14, 4, 101, '', 'comprado'),
(25, 18, 3, 6, '1', 'comprado'),
(26, 18, 3, 11, '2', 'comprado'),
(27, 18, 3, 12, '2', 'comprado'),
(28, 4, 9, 2, '', 'comprado'),
(29, 4, 9, 5, '', 'comprado'),
(30, 4, 9, 114, '', 'comprado');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `opiniones`
--

CREATE TABLE `opiniones` (
  `id_opinion` int(11) NOT NULL,
  `id_receta` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `comentario` text NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp(),
  `calificacion` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `opiniones`
--

INSERT INTO `opiniones` (`id_opinion`, `id_receta`, `id_usuario`, `comentario`, `fecha`, `calificacion`) VALUES
(1, 6, 14, 'ta weno', '2024-12-04 05:08:32', 0),
(2, 1, 15, 'oye me keo weno', '2024-12-04 05:17:29', 0),
(3, 1, 15, 'oye me keo weno', '2024-12-04 05:21:02', 0),
(4, 1, 15, 'oye me keo weno', '2024-12-04 05:27:53', 0),
(5, 1, 15, 'oye me keo weno', '2024-12-04 05:30:02', 0),
(6, 1, 15, 'oye me keo weno', '2024-12-04 05:30:26', 0),
(7, 1, 15, 'oye me keo weno', '2024-12-04 05:30:29', 0),
(8, 14, 15, 'muy weno', '2024-12-04 05:58:38', 0),
(9, 11, 15, 'me salió todo quemado, lol xd', '2024-12-04 06:02:57', 1),
(10, 3, 18, 'me quearon malos', '2024-12-04 19:46:00', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `planificacion`
--

CREATE TABLE `planificacion` (
  `id_planificacion` int(11) NOT NULL,
  `id_usuario` int(11) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `id_receta` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `planificacion`
--

INSERT INTO `planificacion` (`id_planificacion`, `id_usuario`, `fecha`, `id_receta`) VALUES
(1, 1, '2024-12-02', 1),
(2, 1, '2024-12-02', 2),
(3, 2, '2024-12-02', 3),
(4, 2, '2024-12-02', 3),
(5, 4, '2024-12-02', 9),
(6, 13, '2024-12-03', 15),
(7, 13, '2024-12-03', 12),
(8, 14, '2024-12-04', 4),
(9, 15, '2024-12-04', 1),
(10, 4, '2024-12-04', 15),
(11, 18, '2024-12-04', 3),
(12, 7, '2024-12-04', 1),
(13, 7, '2024-12-04', 13),
(14, 7, '2024-12-04', 11),
(15, 7, '2024-12-04', 20),
(16, 7, '2024-12-04', 20),
(17, 7, '2024-12-04', 20),
(18, 7, '2024-12-04', 9),
(19, 7, '2024-12-04', 9),
(20, 7, '2024-12-04', 10),
(21, 7, '2024-12-04', 10),
(23, 8, '2024-12-04', 2),
(24, 8, '2024-12-04', 1),
(25, 8, '2024-12-05', 2),
(26, 8, '2024-12-05', 2),
(27, 8, '2024-12-05', 4),
(29, 8, '2024-12-05', 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `planificacion_comida`
--

CREATE TABLE `planificacion_comida` (
  `id_planificacion_comida` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `id_receta` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `hora` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `recetas`
--

CREATE TABLE `recetas` (
  `id_receta` int(11) NOT NULL,
  `nombre_receta` varchar(150) NOT NULL,
  `descripcion` text DEFAULT NULL,
  `tipo_comida` enum('desayuno','almuerzo','cena','snack') DEFAULT NULL,
  `dieta` enum('sin_gluten','vegetariano','vegano','normal') DEFAULT NULL,
  `instrucciones` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `recetas`
--

INSERT INTO `recetas` (`id_receta`, `nombre_receta`, `descripcion`, `tipo_comida`, `dieta`, `instrucciones`) VALUES
(1, 'Arroz con Pollo', 'Receta clásica de arroz con pollo, ideal para el almuerzo.', 'almuerzo', 'normal', '1. Calienta una sartén grande a fuego medio.\n2. Añade aceite de oliva y sofríe el ajo durante 2 minutos.\n3. Agrega las zanahorias, pimientos y tomates picados, y cocina durante 5 minutos.\n4. Incorpora el arroz y revuelve bien para que se mezcle con los ingredientes.\n5. Vierte el caldo de pollo y ajusta la sal al gusto.\n6. Cocina a fuego lento hasta que el arroz esté tierno, unos 20-25 minutos.\n7. Mientras tanto, cocina el pollo a la parrilla o en sartén.\n8. Sirve el arroz con pollo encima, y disfruta.'),
(2, 'Ensalada de Quinoa', 'Ensalada fresca de quinoa con vegetales y un toque de limón.', 'almuerzo', 'sin_gluten', '1. Cocina la quinoa según las instrucciones del paquete y deja enfriar. 2. Lava y corta los vegetales: pepino, zanahoria, pimiento y tomate. 3. Mezcla la quinoa con los vegetales picados en un bol grande. 4. Adereza con aceite de oliva, jugo de limón, sal y pimienta al gusto. 5. Sirve frío y decora con hojas de menta.'),
(3, 'Tacos Vegetarianos', 'Tacos con relleno de vegetales y frijoles.', 'cena', 'vegetariano', '1. Cocina los frijoles en una sartén con cebolla, ajo y especias (como comino y pimentón). 2. Rellena las tortillas de maíz con la mezcla de frijoles. 3. Agrega vegetales frescos como lechuga, cebolla morada y aguacate. 4. Añade salsa de tomate o guacamole al gusto. 5. Sirve caliente y disfruta.'),
(4, 'Ensalada de Garbanzos', 'Ensalada fresca con garbanzos, pepino, tomate, cebolla morada y aguacate.', 'almuerzo', 'vegetariano', '1. Cocina los garbanzos hasta que estén tiernos.\n2. En un tazón grande, mezcla los garbanzos con pepino, tomate, cebolla morada y aguacate.\n3. Adereza con aceite de oliva, limón y sal.\n4. Sirve frío y disfruta.'),
(5, 'Tacos Vegetarianos', 'Tacos con relleno de frijoles, zanahorias, pimientos y aguacate.', 'cena', 'vegetariano', '1. Cocina los frijoles con cebolla, ajo y especias como comino y pimentón.\n2. Rellena las tortillas de maíz con la mezcla de frijoles.\n3. Agrega vegetales frescos como lechuga, cebolla morada y aguacate.\n4. Sirve caliente y disfruta.'),
(6, 'Curry de Garbanzos', 'Curry de garbanzos con leche de coco y arroz integral.', 'almuerzo', 'vegano', '1. En una sartén, saltea cebolla, ajo y jengibre.\n2. Agrega los garbanzos cocidos y especias como curry y cúrcuma.\n3. Vierte leche de coco y cocina durante 15 minutos.\n4. Sirve caliente con arroz integral.'),
(7, 'Ensalada de Quinoa con Verduras', 'Ensalada fresca de quinoa con pepino, zanahoria, pimiento y aguacate.', 'almuerzo', 'vegano', '1. Cocina la quinoa y deja enfriar.\n2. En un tazón grande, mezcla la quinoa con pepino, zanahoria, pimiento, y aguacate.\n3. Adereza con aceite de oliva, limón, y sal al gusto.\n4. Sirve frío y disfruta.'),
(8, 'Spaghetti a la Boloñesa', 'Spaghetti con salsa boloñesa tradicional de carne.', 'almuerzo', 'normal', '1. Cocina los spaghetti en agua con sal hasta que estén al dente.\n2. En una sartén, fríe carne molida con cebolla, ajo y especias.\n3. Agrega salsa de tomate y cocina durante 10 minutos.\n4. Sirve la pasta con la salsa boloñesa y queso rallado.'),
(9, 'Pollo a la Parrilla con Papas', 'Pollo a la parrilla con papas asadas y especias.', 'cena', 'normal', '1. Cocina el pollo a la parrilla con especias como romero, tomillo, sal y pimienta.\n2. Asa las papas en el horno con aceite de oliva.\n3. Sirve el pollo con las papas y una ensalada fresca.'),
(10, 'Pizza de Jamón y Queso', 'Pizza con base de masa y topping de jamón, queso mozzarella y orégano.', 'almuerzo', 'normal', '1. Precalienta el horno a 220°C.\n2. Estira la masa de pizza y coloca salsa de tomate.\n3. Añade jamón, queso mozzarella y orégano.\n4. Hornea durante 15 minutos y sirve caliente.'),
(11, 'Lasagna de Carne', 'Lasagna con capas de carne, pasta, salsa de tomate y queso.', 'almuerzo', 'normal', '1. Cocina la carne molida con cebolla, ajo y salsa de tomate.\n2. En una fuente para hornear, coloca capas de pasta, carne, y queso.\n3. Hornea durante 40 minutos.\n4. Sirve caliente con ensalada.'),
(12, 'Ensalada César con Pollo', 'Ensalada César con pollo a la parrilla, lechuga, croutons y aderezo César.', 'almuerzo', 'normal', '1. Cocina el pollo a la parrilla.\n2. Mezcla con lechuga, croutons, y aderezo César.\n3. Sirve con queso parmesano.'),
(13, 'Ensalada de Quinoa con Verduras', 'Ensalada fresca de quinoa con pepino, zanahoria, pimiento y aguacate.', 'almuerzo', 'vegano', '1. Cocina la quinoa y deja enfriar.\n2. En un tazón grande, mezcla la quinoa con pepino, zanahoria, pimiento, y aguacate.\n3. Adereza con aceite de oliva, limón, y sal al gusto.\n4. Sirve frío y disfruta.'),
(14, 'Pollo a la Miel y Mostaza', 'Pechugas de pollo bañadas en una mezcla de miel y mostaza, asadas a la perfección.', 'almuerzo', 'sin_gluten', '1. Precalienta el horno a 200°C.\n2. Mezcla la miel, la mostaza, el aceite, la sal y la pimienta.\n3. Cubre las pechugas de pollo con la mezcla y colócalas en una bandeja.\n4. Hornea durante 30 minutos o hasta que estén doradas.\n5. Sirve acompañado de ensalada fresca.'),
(15, 'Spaghetti Carbonara', 'Spaghetti con salsa carbonara tradicional con panceta.', 'almuerzo', 'normal', '1. Cocina los spaghetti en agua con sal.\n2. Fría la panceta en una sartén hasta que esté crujiente.\n3. Mezcla los spaghetti con la panceta y la salsa carbonara.\n4. Sirve con queso parmesano rallado.'),
(16, 'Pollo a la Parrilla con Papas', 'Pollo a la parrilla con papas asadas y especias.', 'cena', 'normal', '1. Cocina el pollo a la parrilla con especias como romero, tomillo, sal y pimienta.\n2. Asa las papas en el horno con aceite de oliva.\n3. Sirve el pollo con las papas y una ensalada fresca.'),
(17, 'Pizza Vegetariana', 'Pizza con base de coliflor y topping de vegetales.', 'almuerzo', 'vegetariano', '1. Precalienta el horno a 200°C.\n2. Forma la base de pizza con coliflor triturada y hornea por 10 minutos.\n3. Coloca salsa de tomate, mozzarella y vegetales encima.\n4. Hornea por 15 minutos más.'),
(18, 'Ensalada de Garbanzos', 'Ensalada fresca con garbanzos, pepino, tomate, cebolla morada y aguacate.', 'almuerzo', 'vegano', '1. Cocina los garbanzos hasta que estén tiernos.\n2. En un tazón grande, mezcla los garbanzos con pepino, tomate, cebolla morada y aguacate.\n3. Adereza con aceite de oliva, limón y sal.\n4. Sirve frío y disfruta.'),
(19, 'Tacos de Pescado', 'Tacos con pescado a la parrilla, salsa de aguacate y pico de gallo.', 'cena', 'normal', '1. Cocina el pescado a la parrilla o en sartén con especias.\n2. Prepara un pico de gallo con tomate, cebolla y cilantro.\n3. Sirve el pescado en tortillas de maíz y acompaña con pico de gallo y salsa de aguacate.'),
(20, 'Ensalada César con Pollo', 'Ensalada fresca con pollo a la parrilla, croutons y aderezo César.', 'almuerzo', 'normal', '1. Cocina el pollo a la parrilla y córtalo en tiras.\n2. Mezcla la lechuga con croutons, queso parmesano y aderezo César.\n3. Añade el pollo por encima.\n4. Sirve con más queso parmesano si lo deseas.'),
(21, 'choripan vegano', 'El choripán es un tipo de emparedado que forma parte importante en la gastronomía de Argentina, Chile, Uruguay y Paraguay, pero también es muy popular en otros países latinoamericanos como Brasil, Perú, Bolivia, y muchos otros. \r\n\r\nConsiste en un trozo pan que suele ser de un tipo de corteza firme como el baguette o pan francés relleno con chorizo a la parrilla y salsa, que puede ser chimichurri, pebre o similares. De ahí el nombre Choripán= Chorizo + pan  \r\n\r\nUsualmente el mejor momento para disfrutar un buen choripán es durante un asado o parrillada, durante un juego de futbol, ¡o pues en realidad a cualquier momento! Ya que es fácil de hacer, fácil de comer y es ultra satisfactorio. ', 'almuerzo', 'normal', '1. Para preparar el choripán puedes hacer unas pequeñas incisiones a lo largo del chorizo vegano y barnizarlo ligeramente con un poco de chimichurri. \r\n2. Pon a precalentar la parrilla, el sartén o la plancha donde lo vayas a cocinar. Cocina a temperatura media-alta durante unos 6 minutos aproximadamente, girando frecuentemente. 3. Puedes reaplicar un poco más de salsa chimichurri mientras cocinas los chorizos. \r\n4. Corta el pan a la mitad a lo largo y ponlo a tostar. \r\n5. Finalmente, arma el emparedado colocando salsa chimichurri al gusto en el pan y agregando el chorizo. Puedes cubrir con más chimichurri.\r\n');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `receta_ingredientes`
--

CREATE TABLE `receta_ingredientes` (
  `id_receta` int(11) NOT NULL,
  `id_ingrediente` int(11) NOT NULL,
  `cantidad` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `receta_ingredientes`
--

INSERT INTO `receta_ingredientes` (`id_receta`, `id_ingrediente`, `cantidad`) VALUES
(1, 1, '200g de Arroz'),
(1, 2, '500g de Pollo'),
(1, 3, '100g de Zanahoria'),
(1, 4, '20ml de Aceite de oliva'),
(1, 5, 'Sal al gusto'),
(1, 6, '2 dientes de Ajo'),
(1, 7, '1 Pimiento'),
(1, 8, '2 Tomates'),
(1, 9, '2 Pechugas de Pollo'),
(1, 10, '500ml de Caldo de pollo'),
(2, 1, '150g de Quinoa'),
(2, 3, '1 Zanahoria'),
(2, 7, '1 Pimiento'),
(2, 8, '1 Tomate'),
(2, 11, 'Al gusto de Limón'),
(3, 3, '1 Zanahoria'),
(3, 4, 'Aceite de oliva al gusto'),
(3, 5, 'Sal al gusto'),
(3, 6, '2 dientes de Ajo'),
(3, 7, '1 Pimiento'),
(3, 8, '2 Tomates'),
(3, 11, '500g de Frijoles'),
(3, 12, '1 Aguacate'),
(3, 16, 'Tortillas de maíz al gusto'),
(4, 4, '20ml de Aceite de oliva'),
(4, 5, 'Sal al gusto'),
(4, 8, '2 Tomates'),
(4, 12, '1 Aguacate'),
(4, 100, '200g de Garbanzos'),
(4, 101, '1 Pepino'),
(4, 102, '1 Cebolla morada'),
(5, 4, '20ml de Aceite de oliva'),
(5, 5, 'Sal al gusto'),
(5, 6, '2 dientes de Ajo'),
(5, 7, '1 Pimiento'),
(5, 12, '1 Aguacate'),
(5, 100, '500g de Frijoles'),
(5, 102, '1 Cebolla morada'),
(5, 103, '2 hojas de Lechuga'),
(5, 104, 'Tortillas de maíz al gusto'),
(6, 4, '20ml de Aceite de oliva'),
(6, 5, 'Sal al gusto'),
(6, 8, '2 Tomates'),
(6, 100, '300g de Garbanzos cocidos'),
(6, 102, '1 Cebolla morada'),
(6, 105, '1 trozo de Jengibre fresco'),
(6, 106, '200ml de Leche de coco'),
(6, 107, '200g de Arroz integral'),
(6, 108, '1 cucharada de Curry en polvo'),
(6, 109, '1 cucharadita de Cúrcuma'),
(8, 4, '20ml de Aceite de oliva'),
(8, 5, 'Sal al gusto'),
(8, 110, '250g de Spaghetti'),
(8, 111, '300g de Carne molida'),
(8, 112, '200ml de Salsa de tomate'),
(8, 113, '50g de Queso parmesano rallado'),
(8, 118, '1 Cebolla picada'),
(9, 2, '2 piezas de Pollo'),
(9, 4, '20ml de Aceite de oliva'),
(9, 5, 'Sal al gusto'),
(9, 6, '2 dientes de Ajo'),
(9, 114, '500g de Papas'),
(10, 4, '20ml de Aceite de oliva'),
(10, 112, '100ml de Salsa de tomate'),
(10, 115, '100g de Jamón'),
(10, 116, '150g de Queso mozzarella'),
(10, 117, '1 base de Masa para pizza'),
(11, 6, '2 dientes de Ajo'),
(11, 111, '300g de Carne molida'),
(11, 112, '300ml de Salsa de tomate'),
(11, 113, '100g de Queso parmesano'),
(11, 117, '6 láminas de Pasta para lasagna'),
(11, 118, '1 Cebolla picada'),
(12, 2, '1 pieza de Pechuga de pollo'),
(12, 4, '10ml de Aceite de oliva'),
(12, 113, '20g de Queso parmesano rallado'),
(12, 119, '100g de Hojas de lechuga'),
(12, 120, '50g de Croutons'),
(12, 121, '30ml de Aderezo César'),
(13, 3, '1 Zanahoria'),
(13, 4, '20ml de Aceite de oliva'),
(13, 5, 'Sal al gusto'),
(13, 7, '1 Pimiento'),
(13, 122, '200g de Quinoa'),
(13, 123, '1 Pepino'),
(13, 124, '1 cucharada de Jugo de limón'),
(13, 125, '1 Aguacate'),
(15, 4, '10ml de Aceite de oliva'),
(15, 5, 'Sal al gusto'),
(15, 110, '200g de Spaghetti'),
(15, 111, '100g de Panceta'),
(15, 113, '50g de Queso parmesano rallado'),
(16, 4, '20ml de Aceite de oliva'),
(16, 5, 'Sal y pimienta al gusto'),
(16, 9, '2 Pechugas de pollo'),
(16, 113, '2 Papas grandes'),
(17, 7, '1 Pimiento'),
(17, 8, '2 Tomates'),
(17, 19, '200g de Coliflor'),
(17, 112, '50g de Salsa de tomate'),
(17, 116, '100g de Queso mozzarella'),
(18, 4, '20ml de Aceite de oliva'),
(18, 8, '1 Tomate'),
(18, 100, '200g de Garbanzos'),
(18, 101, '1 Pepino'),
(18, 102, '1 Cebolla morada'),
(18, 124, '1 cucharada de Jugo de limón'),
(18, 125, '1 Aguacate'),
(19, 19, '200g de Pescado (tilapia o el de tu preferencia)'),
(19, 101, '1 Pepino'),
(19, 102, '1 Cebolla morada'),
(19, 104, '6 Tortillas de maíz'),
(19, 125, '1 Aguacate'),
(20, 9, '2 Pechugas de pollo'),
(20, 103, '100g de Lechuga'),
(20, 113, '30g de Queso parmesano'),
(20, 120, '50g de Croutons'),
(20, 121, '50ml de Aderezo César'),
(21, 126, '4'),
(21, 127, '500ml');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reportes_foro`
--

CREATE TABLE `reportes_foro` (
  `id_reporte` int(11) NOT NULL,
  `id_opinion` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `motivo` text NOT NULL,
  `fecha_reporte` datetime DEFAULT current_timestamp(),
  `estado` enum('pendiente','revisado') DEFAULT 'pendiente'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `reportes_foro`
--

INSERT INTO `reportes_foro` (`id_reporte`, `id_opinion`, `id_usuario`, `motivo`, `fecha_reporte`, `estado`) VALUES
(1, 10, 8, 'No aprecia la escencia de unos buenos tacos vegetarianos ', '2024-12-05 00:14:34', 'pendiente'),
(2, 7, 4, 'mentira ta malo', '2024-12-05 04:00:32', 'pendiente');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `respuestas`
--

CREATE TABLE `respuestas` (
  `id_respuesta` int(11) NOT NULL,
  `id_opinion` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `respuesta` text NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `respuestas`
--

INSERT INTO `respuestas` (`id_respuesta`, `id_opinion`, `id_usuario`, `respuesta`, `fecha`) VALUES
(1, 9, 15, 'lo hice de nuevo y me queo riko, no le presté atención al tiempo de cocción xd', '2024-12-04 06:17:52'),
(2, 7, 4, 'ola', '2024-12-05 07:00:43');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id_usuario` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `apellido_paterno` varchar(100) NOT NULL,
  `apellido_materno` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `contrasena` varchar(255) NOT NULL,
  `preferencias_dietas` text DEFAULT NULL,
  `rol` enum('admin','usuario') DEFAULT 'usuario'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id_usuario`, `nombre`, `apellido_paterno`, `apellido_materno`, `email`, `contrasena`, `preferencias_dietas`, `rol`) VALUES
(2, 'Ana', 'Gomez', 'Lopez', 'ana.gomez@gmail.com', '123', 'vegetariano', 'usuario'),
(3, 'Luis', 'Martinez', 'Lopez', 'luis.martinez@gmail.com', '123', 'normal', 'admin'),
(4, 'Marta', 'Sanchez', 'Diaz', 'marta.sanchez@gmail.com', '123', 'sin_gluten', 'usuario'),
(5, 'Pedro', 'Garcia', 'Fernandez', 'pedro.garcia@gmail.com', '123', 'vegano', 'usuario'),
(6, 'Elena', 'Rodriguez', 'Perez', 'elena.rodriguez@gmail.com', '123', 'normal', 'usuario'),
(7, 'David', 'Lopez', 'Martin', 'david.lopez@gmail.com', '123', 'vegetariano', 'usuario'),
(8, 'Laura', 'Serrano', 'Martinez', 'laura.serrano@gmail.com', '123', 'sin_gluten', 'usuario'),
(9, 'Juan', 'Gonzalez', 'Garcia', 'juan.gonzalez@gmail.com', '123', 'normal', 'usuario'),
(10, 'Sara', 'Fernandez', 'Lopez', 'sara.fernandez@gmail.com', '123', 'vegano', 'usuario'),
(11, 'Oscar', 'Vega', 'Martinez', 'oscar.vega@gmail.com', '123', 'vegetariano', 'usuario'),
(12, 'Pablo', 'Torres', 'Gomez', 'pablo.torres@gmail.com', '123', 'normal', 'usuario'),
(13, 'Julia', 'Cruz', 'Soto', 'julia.cruz@gmail.com', '123', 'sin_gluten', 'usuario'),
(14, 'Ricardo', 'Diaz', 'Lopez', 'ricardo.diaz@gmail.com', '123', 'vegano', 'usuario'),
(15, 'Maria', 'Lopez', 'Rodriguez', 'maria.lopez@gmail.com', '123', 'vegetariano', 'usuario'),
(16, 'Diego', 'Rodriguez', 'Soto', 'diegoadmin@admin.com', '123', NULL, 'admin');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `datos_usuarios`
--
ALTER TABLE `datos_usuarios`
  ADD PRIMARY KEY (`id_dato`),
  ADD KEY `id_usuario` (`id_usuario`);

--
-- Indices de la tabla `ingredientes`
--
ALTER TABLE `ingredientes`
  ADD PRIMARY KEY (`id_ingrediente`);

--
-- Indices de la tabla `lista_compras`
--
ALTER TABLE `lista_compras`
  ADD PRIMARY KEY (`id_lista`),
  ADD KEY `id_usuario` (`id_usuario`),
  ADD KEY `id_receta` (`id_receta`),
  ADD KEY `id_ingrediente` (`id_ingrediente`);

--
-- Indices de la tabla `opiniones`
--
ALTER TABLE `opiniones`
  ADD PRIMARY KEY (`id_opinion`),
  ADD KEY `id_receta` (`id_receta`),
  ADD KEY `id_usuario` (`id_usuario`);

--
-- Indices de la tabla `planificacion`
--
ALTER TABLE `planificacion`
  ADD PRIMARY KEY (`id_planificacion`),
  ADD KEY `id_usuario` (`id_usuario`),
  ADD KEY `id_receta` (`id_receta`);

--
-- Indices de la tabla `planificacion_comida`
--
ALTER TABLE `planificacion_comida`
  ADD PRIMARY KEY (`id_planificacion_comida`),
  ADD KEY `fk_planificacion_usuario` (`id_usuario`),
  ADD KEY `fk_planificacion_receta` (`id_receta`);

--
-- Indices de la tabla `recetas`
--
ALTER TABLE `recetas`
  ADD PRIMARY KEY (`id_receta`);

--
-- Indices de la tabla `receta_ingredientes`
--
ALTER TABLE `receta_ingredientes`
  ADD PRIMARY KEY (`id_receta`,`id_ingrediente`),
  ADD KEY `id_ingrediente` (`id_ingrediente`);

--
-- Indices de la tabla `reportes_foro`
--
ALTER TABLE `reportes_foro`
  ADD PRIMARY KEY (`id_reporte`),
  ADD KEY `id_opinion` (`id_opinion`),
  ADD KEY `id_usuario` (`id_usuario`);

--
-- Indices de la tabla `respuestas`
--
ALTER TABLE `respuestas`
  ADD PRIMARY KEY (`id_respuesta`),
  ADD KEY `id_opinion` (`id_opinion`),
  ADD KEY `id_usuario` (`id_usuario`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id_usuario`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `datos_usuarios`
--
ALTER TABLE `datos_usuarios`
  MODIFY `id_dato` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de la tabla `ingredientes`
--
ALTER TABLE `ingredientes`
  MODIFY `id_ingrediente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=128;

--
-- AUTO_INCREMENT de la tabla `lista_compras`
--
ALTER TABLE `lista_compras`
  MODIFY `id_lista` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT de la tabla `opiniones`
--
ALTER TABLE `opiniones`
  MODIFY `id_opinion` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `planificacion`
--
ALTER TABLE `planificacion`
  MODIFY `id_planificacion` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

--
-- AUTO_INCREMENT de la tabla `planificacion_comida`
--
ALTER TABLE `planificacion_comida`
  MODIFY `id_planificacion_comida` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `recetas`
--
ALTER TABLE `recetas`
  MODIFY `id_receta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT de la tabla `reportes_foro`
--
ALTER TABLE `reportes_foro`
  MODIFY `id_reporte` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `respuestas`
--
ALTER TABLE `respuestas`
  MODIFY `id_respuesta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `datos_usuarios`
--
ALTER TABLE `datos_usuarios`
  ADD CONSTRAINT `datos_usuarios_ibfk_1` FOREIGN KEY (`id_usuario`) REFERENCES `usuarios` (`id_usuario`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

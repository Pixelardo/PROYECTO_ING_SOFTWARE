<?php
session_start();

// Verificar si el usuario está logueado, si no, redirigir al login
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_nombre']) || !isset($_SESSION['user_email'])) {
    header("Location: login.php");
    exit;
}

// Definir clase Administrador
class Administrador {
    private $nombre;

    public function __construct($nombre) {
        $this->nombre = $nombre;
    }

    public function getNombre() {
        return htmlspecialchars($this->nombre, ENT_QUOTES, 'UTF-8');
    }
}

// Crear un objeto Administrador a partir de los datos de la sesión
$admin = new Administrador($_SESSION['user_nombre']);

// Manejo de acciones enviadas por el usuario
$accion = isset($_POST['accion']) ? $_POST['accion'] : null;
$resultado = "";

if ($accion) {
    switch ($accion) {
        case 'anadir_receta':
            $resultado = '
                <form method="POST" action="procesar_receta.php" class="formulario">
                    <label>Nombre de la Receta: <input type="text" name="nombre_receta" required></label><br>
                    <label>Descripción: <textarea name="descripcion" required></textarea></label><br>
                    <label>Tiempo de Preparación (minutos): <input type="number" name="tiempo_preparacion" required></label><br>
                    <label>Tipo de Comida:
                        <select name="tipo_comida" required>
                            <option value="desayuno">Desayuno</option>
                            <option value="almuerzo">Almuerzo</option>
                            <option value="cena">Cena</option>
                            <option value="snack">Snack</option>
                        </select>
                    </label><br>
                    <label>Dieta:
                        <select name="dieta" required>
                            <option value="sin_gluten">Sin Gluten</option>
                            <option value="vegetariano">Vegetariano</option>
                            <option value="vegano">Vegano</option>
                            <option value="normal">Normal</option>
                        </select>
                    </label><br>
                    <label>Instrucciones: <textarea name="instrucciones" required></textarea></label><br>
                    <button class="btn bubbly-button" type="submit">Añadir Receta</button>
                </form>';
            break;
        case 'cerrar_sesion':
            session_destroy();
            header("Location: login.php");
            exit;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Administrador</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        header {
            background: #35424a;
            color: white;
            padding: 20px 0;
            text-align: center;
            position: relative;
        }
        header h1 {
            margin: 0;
            font-size: 24px;
        }
        .container {
            width: 80%;
            margin: auto;
            overflow: hidden;
            padding-top: 20px;
        }
        .menu {
            display: flex;
            justify-content: space-around;
            margin: 20px 0;
        }
        .menu button {
            padding: 10px 20px;
            font-size: 16px;
            background-color: #35424a;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }
        .menu button:hover {
            background-color: #e8491d;
        }
        .formulario {
            background: #ffffff;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            padding: 20px;
            max-width: 600px;
            margin: auto;
            text-align: left;
        }
        .formulario label {
            display: block;
            margin: 10px 0 5px;
            font-size: 14px;
            font-weight: bold;
            color: #333;
        }
        .formulario input[type="text"], 
        .formulario input[type="number"], 
        .formulario textarea, 
        .formulario select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
        }
        .formulario textarea {
            resize: vertical;
        }
        .formulario button {
            display: block;
            width: 100%;
            padding: 10px;
            background-color: #e8491d;
            color: #ffffff;
            border: none;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        .formulario button:hover {
            background-color: #35424a;
        }

        /* Estilos para el icono de perfil y el menú desplegable */
        .profile-container {
            position: absolute;
            top: 20px;
            right: 20px;
        }
        .profile-icon {
            width: 40px;
            height: 40px;
            background-color: #e8491d;
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            cursor: pointer;
        }
        .profile-icon img {
            width: 60%;
            height: auto;
        }

        /* Menú desplegable de opciones de perfil */
        .dropdown-menu {
            display: none;
            position: absolute;
            top: 50px;
            right: 0;
            background-color: #35424a;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
            z-index: 10;
        }
        .dropdown-menu a {
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            display: block;
            font-size: 14px;
        }
        .dropdown-menu a:hover {
            background-color: #e8491d;
        }

        /* Mostrar el menú cuando se hace clic en el icono */
        .profile-icon:hover + .dropdown-menu {
            display: block;
        }

        /* Contenedor del logo */
        .logo-container {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .logo-container img {
            width: 200px; /* Ajusta el tamaño del logo aquí */
            height: auto;
        }

        /* Estilo para la lista con iconos */
        .description ul {
            list-style-type: none; /* Elimina el punto */
            padding-left: 0;
        }

        .description ul li {
            display: flex;
            align-items: center; /* Centra el texto y la imagen verticalmente */
            margin-bottom: 10px;
            font-size: 16px;
        }

        .description ul li img {
            width: 40px; /* Ajusta el tamaño de las imágenes */
            height: auto;
            margin-right: 15px; /* Espacio entre la imagen y el texto */
        }

    </style>
</head>
<body>
    <header>
        <h1>Bienvenido/a, <?php echo $admin->getNombre(); ?> (Administrador)</h1>
        
        <div class="logo-container">
            <a href="dashboard_usuario.php">
                <img src="logod.png" alt="Logo">
            </a>
        </div>

        <!-- Icono de perfil y menú desplegable -->
        <div class="profile-container">
            <div class="profile-icon" onclick="toggleDropdown()">
                <img src="profile-icon.png" alt="Perfil">
            </div>
            <div class="dropdown-menu" id="dropdown-menu">
                <a href="foro.php">Ver Foro</a>
                <a href="logout.php">Cerrar Sesión</a>
            </div>
        </div>
    </header>
    
    <div class="container">
        <div class="description">
            <h2>Funciones del Administrador</h2>
            <p>Como administrador, puedes gestionar las recetas de la plataforma, ver métricas de usuarios y tener acceso a reportes detallados.</p>
            <p>Algunas de las acciones disponibles son:</p>
            <ul>
                <li><img src="añadir.png" alt="Añadir Receta"> <strong>Añadir Receta:</strong> Crea nuevas recetas para que los usuarios las vean y las agreguen a su lista.</li>
                <li><img src="editar.png" alt="Editar Receta"> <strong>Editar Receta:</strong> Modifica cualquier receta existente si es necesario.</li>
                <li><img src="eliminar.png" alt="Eliminar Receta"> <strong>Eliminar Receta:</strong> Elimina recetas que ya no sean relevantes o que se deseen eliminar.</li>
                <li><img src="usuarios.png" alt="Consultar Usuarios"> <strong>Consultar Usuarios:</strong> Visualiza los datos de los usuarios registrados en la plataforma.</li>
                <li><img src="reportes.png" alt="Ver Reportes"> <strong>Ver Reportes:</strong> Accede a reportes detallados sobre la actividad de las recetas y los usuarios.</li>
                <li><img src="metricas.png" alt="Ver Métricas"> <strong>Ver Métricas:</strong> Consulta métricas de usuarios activos y desactivados, así como las preferencias dietéticas de los usuarios.</li>
            </ul>
        </div>

        <div class="menu">
            <!-- Redirige directamente a anadir_receta.php -->
            <form method="GET" action="anadir_receta.php">
                <button type="submit">Añadir Receta</button>
            </form>
            
            <!-- Redirige a editar_receta.php -->
            <form method="GET" action="editar_recetas.php">
                <button type="submit">Editar Receta</button>
            </form>

            <!-- Redirige a eliminar_receta.php -->
            <form method="GET" action="eliminar_receta.php">
                <button type="submit">Eliminar Receta</button>
            </form>

            <!-- Redirige a consultar_usuarios.php -->
            <form method="GET" action="consultar_usuarios.php">
                <button type="submit">Consultar Usuarios</button>
            </form>

            <!-- Redirige a ver_reportes.php -->
            <form method="GET" action="ver_reportes.php">
                <button type="submit">Ver Reportes</button>
            </form>

            <!-- Redirige a ver_metricas.php -->
            <form method="GET" action="ver_metricas.php">
                <button type="submit">Ver Métricas</button>
            </form>
        </div>

        <?php if (isset($resultado) && $resultado): ?>
            <div class="result">
                <?php echo $resultado; ?>
            </div>
        <?php endif; ?>
    </div>

    <script>
        // Función para abrir y cerrar el menú desplegable de perfil
        function toggleDropdown() {
            var menu = document.getElementById('dropdown-menu');
            menu.style.display = menu.style.display === 'block' ? 'none' : 'block';
        }
    </script>
</body>
</html>


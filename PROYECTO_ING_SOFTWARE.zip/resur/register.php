<?php
require_once 'includes/connection_db.php';

class Auth {
    private $db;

    public function __construct() {
        $this->db = (new Database())->getConnection();
    }

    public function register($name, $apellido_paterno, $apellido_materno, $email, $password, $diet_preferences = 'normal', $rut, $telefono, $fecha_nacimiento) {
        try {
            // Iniciar transacción
            $this->db->beginTransaction();

            // Insertar datos en la tabla usuarios
            $sqlUsuario = "INSERT INTO usuarios (nombre, apellido_paterno, apellido_materno, email, contrasena, preferencias_dietas, rol) 
                           VALUES (:nombre, :apellido_paterno, :apellido_materno, :email, :contrasena, :preferencias_dietas, 'usuario')";
            $stmtUsuario = $this->db->prepare($sqlUsuario);

            $stmtUsuario->bindParam(':nombre', $name);
            $stmtUsuario->bindParam(':apellido_paterno', $apellido_paterno);
            $stmtUsuario->bindParam(':apellido_materno', $apellido_materno);
            $stmtUsuario->bindParam(':email', $email);
            $stmtUsuario->bindParam(':contrasena', $password);  // Contraseña en texto plano
            $stmtUsuario->bindParam(':preferencias_dietas', $diet_preferences);

            $stmtUsuario->execute();

            // Obtener el ID del usuario recién insertado
            $idUsuario = $this->db->lastInsertId();

            // Insertar datos en la tabla datos_usuarios
            $sqlDatos = "INSERT INTO datos_usuarios (id_usuario, rut, telefono, fecha_nacimiento) 
                         VALUES (:id_usuario, :rut, :telefono, :fecha_nacimiento)";
            $stmtDatos = $this->db->prepare($sqlDatos);

            $stmtDatos->bindParam(':id_usuario', $idUsuario, PDO::PARAM_INT);
            $stmtDatos->bindParam(':rut', $rut);
            $stmtDatos->bindParam(':telefono', $telefono);
            $stmtDatos->bindParam(':fecha_nacimiento', $fecha_nacimiento);

            $stmtDatos->execute();

            // Confirmar la transacción
            $this->db->commit();
            return true;
        } catch (PDOException $e) {
            // Deshacer la transacción en caso de error
            $this->db->rollBack();
            echo "Error al registrar: " . $e->getMessage();
            return false;
        }
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'] ?? '';
    $apellido_paterno = $_POST['apellido_paterno'] ?? '';
    $apellido_materno = $_POST['apellido_materno'] ?? '';
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $diet_preferences = $_POST['diet_preferences'] ?? 'normal';

    $rut = $_POST['rut'] ?? '';
    $telefono = $_POST['telefono'] ?? '';
    $fecha_nacimiento = $_POST['fecha_nacimiento'] ?? '';

    $auth = new Auth();
    $success = $auth->register($name, $apellido_paterno, $apellido_materno, $email, $password, $diet_preferences, $rut, $telefono, $fecha_nacimiento);

    if ($success) {
        // Redirigir con parámetro 'registered=1'
        header("Location: register.php?registered=1");
        exit;
    } else {
        $error = "Error al registrar el usuario. Intente nuevamente.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .form-container {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            width: 350px; /* Aumenta el ancho para hacer los campos más cómodos */
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        .form-container h1 {
            text-align: center;
            margin-bottom: 20px;
            font-size: 24px;
            color: #35424a;
        }

        .logo-container {
            text-align: center;
            margin-bottom: 20px;
        }

        .logo-container img {
            width: 150px;
            height: auto;
        }

        .form-container label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-size: 14px;
        }

        .form-container input,
        .form-container select {
            width: 100%;
            padding: 12px; /* Ajusta el tamaño de las casillas */
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }

        /* Estilo al foco del campo de entrada */
        .form-container input:focus,
        .form-container select:focus {
            border-color: #e8491d;
            box-shadow: 0 0 8px rgba(232, 73, 29, 0.5);
            outline: none;
        }

        .form-container button {
            width: 100%;
            padding: 12px;
            background: #35424a;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        .form-container button:hover {
            background: #e8491d;
        }

        .error {
            color: red;
            text-align: center;
            margin-bottom: 10px;
        }

        /* Modal */
        .modal {
            display: none; /* Hidden by default */
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            text-align: center;
        }

        .modal-content {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            margin: 10% auto;
            width: 300px;
        }

        .modal-button {
            padding: 10px;
            background-color: #35424a;
            color: white;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        .modal-button:hover {
            background-color: #e8491d;
        }

        /* Botón de Volver en la esquina superior izquierda */
        .btn-back {
            position: absolute;
            top: 20px;
            left: 20px;
            background-color: #35424a;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
        }

        .btn-back:hover {
            background-color: #e8491d;
        }
    </style>
</head>
<body>
    <!-- Botón de Volver -->
    <a href="index.php" class="btn-back">Volver</a>

    <div class="form-container">
        <div class="logo-container">
            <img src="logod.png" alt="Logo"> <!-- Ajusta la ruta de la imagen según sea necesario -->
        </div>
        <h1>Registro</h1>
        <?php if (!empty($error)): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>
        <form method="POST">
            <label for="name">Nombre</label>
            <input type="text" name="name" id="name" required>

            <label for="apellido_paterno">Apellido Paterno</label>
            <input type="text" name="apellido_paterno" id="apellido_paterno" required>

            <label for="apellido_materno">Apellido Materno</label>
            <input type="text" name="apellido_materno" id="apellido_materno" required>

            <label for="email">Correo Electrónico</label>
            <input type="email" name="email" id="email" required>

            <label for="password">Contraseña</label>
            <input type="password" name="password" id="password" required>

            <label for="diet_preferences">Preferencias Dietéticas</label>
            <select name="diet_preferences" id="diet_preferences">
                <option value="normal">Normal</option>
                <option value="sin_gluten">Sin Gluten</option>
                <option value="vegetariano">Vegetariano</option>
                <option value="vegano">Vegano</option>
            </select>

            <label for="rut">RUT</label>
            <input type="text" name="rut" id="rut" required>

            <label for="telefono">Teléfono</label>
            <input type="text" name="telefono" id="telefono" required>

            <label for="fecha_nacimiento">Fecha de Nacimiento</label>
            <input type="date" name="fecha_nacimiento" id="fecha_nacimiento" required>

            <button type="submit">Registrar</button>

            <div class="register-link">
            <p>¿Ya tienes cuenta? <a href="login.php">¡Inicia Sesión aquí!</a></p>
        </div>
        </form>
    </div>

    <!-- Modal para mostrar mensaje de éxito -->
    <div id="successModal" class="modal">
        <div class="modal-content">
            <h3>¡Te has registrado con éxito!</h3>
            <p>Ahora puedes iniciar sesión.</p>
            <button id="loginButton" class="modal-button">Aceptar</button>
        </div>
    </div>


    <script>
        // Mostrar el modal si el parámetro 'registered' está presente
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.get('registered') === '1') {
            const modal = document.getElementById("successModal");
            const button = document.getElementById("loginButton");

            modal.style.display = "block";  // Mostrar el modal

            button.onclick = function() {
                window.location.href = "login.php"; // Redirigir a la página de login
            }
        }
    </script>
</body>
</html>



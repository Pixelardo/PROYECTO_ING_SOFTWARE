<?php
session_start();

// Verificar si el usuario está logueado
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_nombre']) || !isset($_SESSION['user_email'])) {
    header("Location: login.php");
    exit;
}

// Clases para el foro
class Database {
    private $host = 'localhost';
    private $db = 'recesur';
    private $user = 'root';
    private $pass = '';
    private $charset = 'utf8mb4';
    private $pdo;

    public function __construct() {
        $dsn = "mysql:host={$this->host};dbname={$this->db};charset={$this->charset}";
        try {
            $this->pdo = new PDO($dsn, $this->user, $this->pass);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die("Error de conexión: " . $e->getMessage());
        }
    }

    public function getConnection() {
        return $this->pdo;
    }
}

class Foro {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    // Agregar una nueva opinión
    public function agregarOpinion($idReceta, $idUsuario, $comentario, $calificacion) {
        $query = "INSERT INTO opiniones (id_receta, id_usuario, comentario, calificacion) 
                  VALUES (:id_receta, :id_usuario, :comentario, :calificacion)";
        $stmt = $this->pdo->prepare($query);
        $stmt->bindParam(':id_receta', $idReceta, PDO::PARAM_INT);
        $stmt->bindParam(':id_usuario', $idUsuario, PDO::PARAM_INT);
        $stmt->bindParam(':comentario', $comentario, PDO::PARAM_STR);
        $stmt->bindParam(':calificacion', $calificacion, PDO::PARAM_INT);
        return $stmt->execute();
    }
}

$database = new Database();
$pdo = $database->getConnection();
$userId = $_SESSION['user_id'];
$foro = new Foro($pdo);

// Variable para el mensaje de éxito
$mensajeExito = "";

// Lógica para agregar opiniones
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['agregar_opinion'])) {
    $idReceta = $_POST['id_receta'];
    $comentario = $_POST['comentario'];
    $calificacion = $_POST['calificacion'];

    // Agregar la opinión con la calificación
    $foro->agregarOpinion($idReceta, $userId, $comentario, $calificacion);

    // Mostrar mensaje de éxito
    $mensajeExito = "Opinión publicada en el foro correctamente";
    header("Refresh: 3; URL=foro.php"); // Redirige después de 3 segundos
}

// Obtener las recetas disponibles para que el usuario pueda elegir
$recetas = [];
$stmt = $pdo->query("SELECT id_receta, nombre_receta FROM recetas");
while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    $recetas[] = $row;
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Agregar Opinión</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 80%;
            margin: 40px auto;
            padding: 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: #35424a;
            text-align: center;
        }
        label {
            display: block;
            margin-bottom: 10px;
            font-size: 16px;
        }
        select, textarea, button {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 5px;
            border: 1px solid #ccc;
            font-size: 16px;
        }
        button {
            background-color: #e8491d;
            color: white;
            cursor: pointer;
            font-size: 18px;
        }
        button:hover {
            background-color: #35424a;
        }
        .mensaje-exito {
            background-color: #e0ffe0;
            color: green;
            padding: 10px;
            text-align: center;
            margin-bottom: 20px;
            border-radius: 5px;
        }
        .btn-volver {
            background-color: #35424a;
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 5px;
            text-align: center;
            display: inline-block;
            font-size: 16px;
        }
        .btn-volver:hover {
            background-color: #e8491d;
        }
    </style>
</head>
<body>

    <div class="container">
        <h1>Agregar Opinión a una Receta</h1>

        <!-- Mensaje de éxito -->
        <?php if (!empty($mensajeExito)): ?>
            <div class="mensaje-exito"><?php echo $mensajeExito; ?></div>
        <?php endif; ?>

        <form method="POST">
            <label for="id_receta">Selecciona una receta:</label>
            <select name="id_receta" id="id_receta" required>
                <?php foreach ($recetas as $receta): ?>
                    <option value="<?php echo $receta['id_receta']; ?>">
                        <?php echo htmlspecialchars($receta['nombre_receta']); ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <label for="comentario">Escribe tu comentario:</label>
            <textarea name="comentario" rows="5" placeholder="Escribe aquí tu opinión..." required></textarea>

            <label for="calificacion">Calificación (1 a 5):</label>
            <select name="calificacion" id="calificacion" required>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
            </select>

            <button type="submit" name="agregar_opinion">Enviar Opinión</button>
        </form>

        <!-- Botón Volver -->
        <a href="foro.php" class="btn-volver">Volver al Foro</a>
    </div>

</body>
</html>

<?php
session_start();

// Verificar si el usuario está logueado
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_nombre']) || !isset($_SESSION['user_email'])) {
    header("Location: login.php");
    exit;
}

// Conexión a la base de datos
class Database {
    private $host = 'localhost';
    private $db = 'recesur';
    private $user = 'root';
    private $pass = '';
    private $charset = 'utf8mb4';
    private $pdo;

    public function __construct() {
        $dsn = "mysql:host={$this->host};dbname={$this->db};charset={$this->charset}";
        try {
            $this->pdo = new PDO($dsn, $this->user, $this->pass);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die("Error de conexión: " . $e->getMessage());
        }
    }

    public function getConnection() {
        return $this->pdo;
    }
}

// Clase Foro para gestionar las opiniones y respuestas
class Foro {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    // Obtener una opinión por ID
    public function obtenerOpinion($idOpinion) {
        $query = "SELECT o.id_opinion, r.nombre_receta, u.nombre, o.comentario, o.fecha 
                  FROM opiniones o
                  JOIN recetas r ON o.id_receta = r.id_receta
                  JOIN usuarios u ON o.id_usuario = u.id_usuario
                  WHERE o.id_opinion = :id_opinion";
        $stmt = $this->pdo->prepare($query);
        $stmt->bindParam(':id_opinion', $idOpinion, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Obtener las respuestas de una opinión
    public function obtenerRespuestas($idOpinion) {
        $query = "SELECT r.respuesta, u.nombre, r.fecha 
                  FROM respuestas r
                  JOIN usuarios u ON r.id_usuario = u.id_usuario
                  WHERE r.id_opinion = :id_opinion
                  ORDER BY r.fecha ASC";
        $stmt = $this->pdo->prepare($query);
        $stmt->bindParam(':id_opinion', $idOpinion, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Agregar una nueva respuesta
    public function agregarRespuesta($idOpinion, $idUsuario, $respuesta) {
        $query = "INSERT INTO respuestas (id_opinion, id_usuario, respuesta) 
                  VALUES (:id_opinion, :id_usuario, :respuesta)";
        $stmt = $this->pdo->prepare($query);
        $stmt->bindParam(':id_opinion', $idOpinion, PDO::PARAM_INT);
        $stmt->bindParam(':id_usuario', $idUsuario, PDO::PARAM_INT);
        $stmt->bindParam(':respuesta', $respuesta, PDO::PARAM_STR);
        return $stmt->execute();
    }

    // Registrar un reporte
    public function reportarOpinion($idOpinion, $idUsuario, $motivo) {
        $query = "INSERT INTO reportes_foro (id_opinion, id_usuario, motivo) 
                  VALUES (:id_opinion, :id_usuario, :motivo)";
        $stmt = $this->pdo->prepare($query);
        $stmt->bindParam(':id_opinion', $idOpinion, PDO::PARAM_INT);
        $stmt->bindParam(':id_usuario', $idUsuario, PDO::PARAM_INT);
        $stmt->bindParam(':motivo', $motivo, PDO::PARAM_STR);
        return $stmt->execute();
    }
}

// Crear objetos de las clases
$database = new Database();
$pdo = $database->getConnection();
$userId = $_SESSION['user_id'];
$foro = new Foro($pdo);

// Obtener la opinión seleccionada
$id_opinion = $_GET['id'];
$opinion = $foro->obtenerOpinion($id_opinion);

// Obtener las respuestas de la opinión seleccionada
$respuestas = $foro->obtenerRespuestas($id_opinion);

// Lógica para agregar una respuesta
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['agregar_respuesta'])) {
        $respuesta = $_POST['respuesta'];
        $foro->agregarRespuesta($id_opinion, $userId, $respuesta);
        header("Location: ver_opinion.php?id=" . $id_opinion);
        exit;
    }

    // Lógica para reportar una opinión
    if (isset($_POST['reportar_opinion'])) {
        $motivo = $_POST['motivo'];
        $foro->reportarOpinion($id_opinion, $userId, $motivo);
        header("Location: ver_opinion.php?id=" . $id_opinion . "&reporte=exitoso");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ver Opinión</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        header {
            background: #35424a;
            color: white;
            padding: 20px;
            text-align: center;
        }
        .container {
            width: 80%;
            margin: 20px auto;
        }
        .opinion-card, .response-card, .form-report {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }
        .opinion-card h3 {
            color: #35424a;
        }
        .opinion-card p {
            color: #555;
        }
        .btn {
            display: inline-block;
            padding: 10px 20px;
            color: white;
            background: #e8491d;
            border-radius: 5px;
            text-decoration: none;
            margin: 10px 0;
        }
        .btn:hover {
            background: #35424a;
        }
        .form-report textarea {
            width: 100%;
            height: 100px;
            margin-top: 10px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .form-report button {
            margin-top: 10px;
        }
        .response-card h4, .form-response h4 {
            margin-top: 0;
        }
        .form-response {
            margin-top: 20px;
        }
        .form-response textarea {
            width: 100%;
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            margin-top: 10px;
            font-size: 16px;
            height: 100px;
        }
        .form-response button {
            padding: 10px 20px;
            background-color: #e8491d;
            color: white;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
        }
        .form-response button:hover {
            background-color: #35424a;
        }
    </style>
    <script>
        function mostrarFormularioReporte() {
            document.getElementById('formularioReporte').style.display = 'block';
        }
        function cerrarFormularioReporte() {
            document.getElementById('formularioReporte').style.display = 'none';
        }
    </script>
</head>
<body>
    <header>
        <h1>Detalles de Opinión</h1>
    </header>

    <div class="container">
        <!-- Mostrar la opinión seleccionada -->
        <?php if ($opinion): ?>
            <div class="opinion-card">
                <h3><?php echo htmlspecialchars($opinion['nombre_receta']); ?></h3>
                <p><strong><?php echo htmlspecialchars($opinion['nombre']); ?></strong> - <?php echo $opinion['fecha']; ?></p>
                <p><?php echo nl2br(htmlspecialchars($opinion['comentario'])); ?></p>
                <button class="btn" onclick="mostrarFormularioReporte()">Reportar Comentario</button>
            </div>
        <?php else: ?>
            <p>No se encontró la opinión.</p>
        <?php endif; ?>

        <!-- Formulario emergente para reportar -->
        <div id="formularioReporte" class="form-report" style="display:none;">
            <h4>Reportar Comentario</h4>
            <form method="POST">
                <textarea name="motivo" placeholder="Escribe el motivo del reporte..." required></textarea>
                <button type="submit" name="reportar_opinion" class="btn">Enviar Reporte</button>
                <button type="button" class="btn" onclick="cerrarFormularioReporte()">Cancelar</button>
            </form>
        </div>

                <!-- Mostrar las respuestas -->
                <h3>Respuestas</h3>
        <?php if ($respuestas): ?>
            <?php foreach ($respuestas as $respuesta): ?>
                <div class="response-card">
                    <h4>Respuesta de <?php echo htmlspecialchars($respuesta['nombre']); ?> - <?php echo $respuesta['fecha']; ?></h4>
                    <p><?php echo nl2br(htmlspecialchars($respuesta['respuesta'])); ?></p>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>Aún no hay respuestas para esta opinión.</p>
        <?php endif; ?>

        <!-- Formulario para agregar una nueva respuesta -->
        <div class="form-response">
            <h4>Agregar Respuesta</h4>
            <form method="POST">
                <textarea name="respuesta" required placeholder="Escribe tu respuesta..."></textarea><br><br>
                <button type="submit" name="agregar_respuesta">Enviar Respuesta</button>
            </form>
        </div>

        <!-- Reportar comentario -->
        <div id="formularioReporte" class="form-report" style="display:none;">
            <h4>Reportar Comentario</h4>
            <form method="POST">
                <textarea name="motivo" placeholder="Escribe el motivo del reporte..." required></textarea><br><br>
                <button type="submit" name="reportar_opinion" class="btn">Enviar Reporte</button>
                <button type="button" class="btn" onclick="cerrarFormularioReporte()">Cancelar</button>
            </form>
        </div>

        <!-- Botón de Volver -->
        <a href="foro.php" class="btn">Volver al Foro</a>
    </div>

    <script>
        function mostrarFormularioReporte() {
            document.getElementById('formularioReporte').style.display = 'block';
        }

        function cerrarFormularioReporte() {
            document.getElementById('formularioReporte').style.display = 'none';
        }
    </script>
</body>
</html>

<?php
session_start();

// Desactivar la visualización de errores
error_reporting(E_ALL & ~E_NOTICE & ~E_WARNING); // Desactiva Warnings y Notices
ini_set('display_errors', '0'); // No mostrar errores en pantalla


// Verificar si el usuario está logueado
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_nombre']) || !isset($_SESSION['user_email'])) {
    header("Location: login.php");
    exit;
}

// Clase Database: conexión a la base de datos
class Database {
    private $host = 'localhost';
    private $db = 'recesur';
    private $user = 'root';
    private $pass = '';
    private $charset = 'utf8mb4';
    private $pdo;

    public function __construct() {
        $dsn = "mysql:host={$this->host};dbname={$this->db};charset={$this->charset}";
        try {
            $this->pdo = new PDO($dsn, $this->user, $this->pass);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die("Error de conexión: " . $e->getMessage());
        }
    }

    public function getConnection() {
        return $this->pdo;
    }
}

// Clase Usuario para gestionar la información del usuario
class Usuario {
    private $pdo;
    private $user_id;

    public function __construct($pdo, $user_id) {
        $this->pdo = $pdo;
        $this->user_id = $user_id;
    }

    public function getNombre() {
        $query = "SELECT nombre FROM usuarios WHERE id_usuario = :user_id";
        $stmt = $this->pdo->prepare($query);
        $stmt->bindParam(':user_id', $this->user_id, PDO::PARAM_INT);
        $stmt->execute();
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
        return $usuario ? $usuario['nombre'] : null;
    }

    // Obtener las preferencias de dieta del usuario
    public function getPreferenciasDietas() {
        $query = "SELECT preferencias_dietas FROM usuarios WHERE id_usuario = :user_id";
        $stmt = $this->pdo->prepare($query);
        $stmt->bindParam(':user_id', $this->user_id, PDO::PARAM_INT);
        $stmt->execute();
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
        return $usuario ? $usuario['preferencias_dietas'] : 'normal';
    }
}

// Clase Receta para gestionar las recetas
class Receta {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    // Obtener las recetas filtradas por las preferencias de dieta
    public function obtenerRecetas($filtro = '', $preferencias_dietas = 'normal') {
        $query = "SELECT DISTINCT id_receta, nombre_receta, descripcion, tipo_comida, dieta, instrucciones 
                  FROM recetas 
                  WHERE nombre_receta LIKE :filtro ";

        if ($preferencias_dietas != 'normal') {
            $query .= " AND dieta = :preferencias_dietas ";
        }

        $stmt = $this->pdo->prepare($query);
        $stmt->bindValue(':filtro', "%$filtro%", PDO::PARAM_STR);
        if ($preferencias_dietas != 'normal') {
            $stmt->bindParam(':preferencias_dietas', $preferencias_dietas, PDO::PARAM_STR);
        }
        $stmt->execute();
        $recetas = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Convertir cada receta en un objeto de tipo RecetaItem
        $recetasObjetos = [];
        foreach ($recetas as $receta) {
            $recetasObjetos[] = new RecetaItem($receta, $this->pdo);
        }

        return $recetasObjetos;
    }

    // Obtener los ingredientes y cantidades de una receta
    public function obtenerIngredientes($id_receta) {
        $query = "SELECT i.nombre_ingrediente, ri.cantidad 
                  FROM receta_ingredientes ri 
                  JOIN ingredientes i ON ri.id_ingrediente = i.id_ingrediente
                  WHERE ri.id_receta = :id_receta";
        $stmt = $this->pdo->prepare($query);
        $stmt->bindParam(':id_receta', $id_receta, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Guardar receta en la planificación del usuario
    public function guardarReceta($user_id, $receta_id) {
        $query = "INSERT INTO planificacion (id_usuario, id_receta, fecha) VALUES (:user_id, :receta_id, CURDATE())";
        $stmt = $this->pdo->prepare($query);
        $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $stmt->bindParam(':receta_id', $receta_id, PDO::PARAM_INT);
        return $stmt->execute();
    }
}

// Nueva clase RecetaItem para representar cada receta como un objeto
class RecetaItem {
    private $id_receta;
    private $nombre_receta;
    private $descripcion;
    private $tipo_comida;
    private $dieta;
    private $instrucciones;
    private $pdo;

    public function __construct($receta, $pdo) {
        $this->id_receta = $receta['id_receta'];
        $this->nombre_receta = $receta['nombre_receta'];
        $this->descripcion = $receta['descripcion'];
        $this->tipo_comida = $receta['tipo_comida'];
        $this->dieta = $receta['dieta'];
        $this->instrucciones = $receta['instrucciones'];
        $this->pdo = $pdo;
    }

    public function getIdReceta() {
        return $this->id_receta;
    }

    public function getNombreReceta() {
        return $this->nombre_receta;
    }

    public function getDescripcion() {
        return $this->descripcion;
    }

    public function getTipoComida() {
        return $this->tipo_comida;
    }

    public function getDieta() {
        return $this->dieta;
    }

    public function getInstrucciones() {
        return $this->instrucciones;
    }

    public function obtenerIngredientes() {
        $receta = new Receta($this->pdo);
        return $receta->obtenerIngredientes($this->id_receta);
    }

    public function guardarReceta($user_id) {
        $receta = new Receta($this->pdo);
        return $receta->guardarReceta($user_id, $this->id_receta);
    }
}

// Crear la conexión a la base de datos
$database = new Database();
$pdo = $database->getConnection();

// Obtener el ID del usuario logueado
$user_id = $_SESSION['user_id']; // ID del usuario logueado

// Crear instancia del objeto Usuario
$usuario = new Usuario($pdo, $user_id);
$nombreUsuario = $usuario->getNombre();
$preferenciasDietas = $usuario->getPreferenciasDietas();

// Obtener los filtros de búsqueda
$filtro = isset($_POST['filtro']) ? $_POST['filtro'] : '';
$preferencias_dietas = isset($_POST['diet_preferences']) ? $_POST['diet_preferences'] : $preferenciasDietas;

// Crear instancia del objeto Receta
$receta = new Receta($pdo);

// Obtener las recetas filtradas por los criterios
$recetas = $receta->obtenerRecetas($filtro, $preferencias_dietas);

// Verificar si se ha guardado alguna receta
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['guardar_receta'])) {
    $receta_id = $_POST['receta_id'];
    $recetaSeleccionada = new RecetaItem(['id_receta' => $receta_id], $pdo);
    $recetaSeleccionada->guardarReceta($user_id);
    $mensaje = "Receta guardada exitosamente."; // Mostrar el mensaje
}
?>


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ver Recetas</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 80%;
            margin: auto;
            overflow: hidden;
        }
        header {
            position: relative;
            background: #35424a;
            color: white;
            padding: 20px 0;
            text-align: center;
        }
        header h1 {
            margin: 0;
            font-size: 24px;
        }
        .btn-back {
            position: absolute;
            top: 20px;
            right: 20px;
            background-color: #e8491d;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
        }
        .btn-back:hover {
            background-color: #35424a;
        }
        .menu {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            margin: 20px 0;
        }
        .menu button {
            margin: 10px;
            padding: 10px 20px;
            font-size: 16px;
            background-color: #35424a;
            color: white;
            border: none;
            cursor: pointer;
        }
        .menu button:hover {
            background-color: #e8491d;
        }
        .receta-card {
            background: #ffffff;
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            cursor: pointer;
        }
        .receta-card:hover {
            background-color: #f1f1f1;
        }
        .receta-detalles {
            margin-top: 15px;
            display: none;
        }
        .result {
            margin: 20px 0;
            text-align: center;
            font-size: 18px;
            color: #333;
        }
        .logout {
            text-align: center;
            margin-top: 20px;
        }
        .btn.bubbly-button {
            background-color: #e8491d;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        .btn.bubbly-button:hover {
            background-color: #35424a;
        }
        .logo-container {
            margin-top: 10px;
        }
        .logo-container img {
            width: 150px; /* Ajusta el tamaño del logo según tus necesidades */
            height: auto;
        }
    </style>
    <script>
        // Mostrar/ocultar detalles de la receta
        function toggleDetalles(id) {
            var details = document.getElementById('detalles-' + id);
            if (details.style.display === 'none') {
                details.style.display = 'block';
            } else {
                details.style.display = 'none';
            }
        }
    </script>
</head>
<body>
    <header>
        <h1>Ver Recetas Disponibles</h1>
        <!-- Botón de Volver -->
        <a href="dashboard_usuario.php" class="btn-back">Volver</a>
        <div class="logo-container">
            <a href="dashboard_usuario.php">
                <img src="logod.png" alt="Logo">
            </a>
        </div>
    </header>
    
    <div class="container">
        <!-- Mostrar mensaje de éxito -->
        <?php if (isset($mensaje)): ?>
            <div class="alerta-mensaje">
                <p><?php echo htmlspecialchars($mensaje); ?></p>
            </div>
        <?php endif; ?>

        <!-- Filtros -->
        <form method="POST" class="filters">
            <input type="text" name="filtro" placeholder="Buscar por receta..." value="<?php echo htmlspecialchars($filtro); ?>" />
            <select name="diet_preferences">
                <option value="normal" <?php echo $preferencias_dietas == 'normal' ? 'selected' : ''; ?>>Todas</option>
                <option value="sin_gluten" <?php echo $preferencias_dietas == 'sin_gluten' ? 'selected' : ''; ?>>Sin Gluten</option>
                <option value="vegetariano" <?php echo $preferencias_dietas == 'vegetariano' ? 'selected' : ''; ?>>Vegetariano</option>
                <option value="vegano" <?php echo $preferencias_dietas == 'vegano' ? 'selected' : ''; ?>>Vegano</option>
            </select>
            <button type="submit">Buscar</button>
        </form>

        <h2>Recetas:</h2>
        <?php if ($recetas): ?>
            <ul>
                <?php foreach ($recetas as $receta): ?>
                    <li class="receta-card" onclick="toggleDetalles(<?php echo $receta->getIdReceta(); ?>)">
                        <strong><?php echo htmlspecialchars($receta->getNombreReceta()); ?></strong> - <?php echo htmlspecialchars($receta->getDescripcion()); ?>
                        <br>
                        Tipo de comida: <?php echo htmlspecialchars($receta->getTipoComida()); ?>
                        <br>
                        Dieta: <?php echo htmlspecialchars($receta->getDieta()); ?>
                        <div class="receta-detalles" id="detalles-<?php echo $receta->getIdReceta(); ?>">
                            <h3>Ingredientes:</h3>
                            <ul>
                                <?php
                                $ingredientes = $receta->obtenerIngredientes();
                                if ($ingredientes):
                                    foreach ($ingredientes as $ingrediente):
                                ?>
                                    <li><?php echo htmlspecialchars($ingrediente['nombre_ingrediente']); ?> - <?php echo htmlspecialchars($ingrediente['cantidad']); ?></li>
                                <?php endforeach; ?>
                                <?php else: ?>
                                    <p>No hay ingredientes disponibles para esta receta.</p>
                                <?php endif; ?>
                            </ul>
                            <h3>Instrucciones:</h3>
                            <p><?php echo nl2br(htmlspecialchars($receta->getInstrucciones())); ?></p>
                            <form method="POST">
                                <input type="hidden" name="receta_id" value="<?php echo $receta->getIdReceta(); ?>">
                                <button type="submit" name="guardar_receta" class="btn bubbly-button">Guardar Receta</button>
                            </form>
                        </div>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php else: ?>
            <p>No hay recetas disponibles.</p>
        <?php endif; ?>
    </div>
</body>
</html>
<?php
session_start();

// Verificar si el usuario está logueado, si no, redirigir al login
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_nombre']) || !isset($_SESSION['user_email'])) {
    header("Location: login.php");
    exit;
}

// Conexión a la base de datos
class Database {
    private $host = 'localhost';
    private $db = 'recesur';
    private $user = 'root';
    private $pass = '';
    private $charset = 'utf8mb4';
    private $pdo;

    public function __construct() {
        $dsn = "mysql:host={$this->host};dbname={$this->db};charset={$this->charset}";
        try {
            $this->pdo = new PDO($dsn, $this->user, $this->pass);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die("Error de conexión: " . $e->getMessage());
        }
    }

    public function getConnection() {
        return $this->pdo;
    }
}

// Clase Reportes
class Reportes {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    // Obtener todos los reportes
    public function obtenerReportes() {
        $query = "SELECT r.id_reporte, o.id_opinion, o.id_receta, r.motivo, r.fecha_reporte, r.estado, 
                         u.nombre AS usuario_reportante, o.comentario AS comentario_reportado, 
                         r.id_usuario AS usuario_comentario, rec.nombre_receta
                  FROM reportes_foro r
                  JOIN opiniones o ON r.id_opinion = o.id_opinion
                  JOIN usuarios u ON r.id_usuario = u.id_usuario
                  JOIN recetas rec ON o.id_receta = rec.id_receta
                  ORDER BY r.fecha_reporte DESC";
        $stmt = $this->pdo->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Marcar un reporte como revisado
    public function actualizarEstadoReporte($id_reporte, $estado) {
        $query = "UPDATE reportes_foro SET estado = :estado WHERE id_reporte = :id_reporte";
        $stmt = $this->pdo->prepare($query);
        $stmt->bindParam(':id_reporte', $id_reporte, PDO::PARAM_INT);
        $stmt->bindParam(':estado', $estado, PDO::PARAM_STR);
        return $stmt->execute();
    }

    // Función para eliminar el comentario
// Función para eliminar el comentario y sus respuestas
public function eliminarComentario($id_opinion, $motivo_eliminacion) {
    // Eliminar primero las respuestas relacionadas
    $query = "DELETE FROM respuestas WHERE id_opinion = :id_opinion";
    $stmt = $this->pdo->prepare($query);
    $stmt->bindParam(':id_opinion', $id_opinion, PDO::PARAM_INT);
    $stmt->execute();

    // Eliminar el reporte relacionado
    $query = "DELETE FROM reportes_foro WHERE id_opinion = :id_opinion";
    $stmt = $this->pdo->prepare($query);
    $stmt->bindParam(':id_opinion', $id_opinion, PDO::PARAM_INT);
    $stmt->execute();

    // Luego, actualizar la tabla 'opiniones' con el motivo de eliminación
    $query = "UPDATE opiniones SET motivo_eliminacion = :motivo WHERE id_opinion = :id_opinion";
    $stmt = $this->pdo->prepare($query);
    $stmt->bindParam(':motivo', $motivo_eliminacion);
    $stmt->bindParam(':id_opinion', $id_opinion, PDO::PARAM_INT);
    $stmt->execute();

    // Finalmente, eliminar el comentario de la tabla 'opiniones'
    $query = "DELETE FROM opiniones WHERE id_opinion = :id_opinion";
    $stmt = $this->pdo->prepare($query);
    $stmt->bindParam(':id_opinion', $id_opinion, PDO::PARAM_INT);
    return $stmt->execute();
}


}

// Crear objetos de las clases
$database = new Database();
$pdo = $database->getConnection();
$reportes = new Reportes($pdo);

// Obtener los reportes
$reportes_lista = $reportes->obtenerReportes();

// Procesar el formulario para cambiar el estado del reporte
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['revisar_reporte'])) {
        $id_reporte = $_POST['id_reporte'];
        $estado = $_POST['estado'];
        $reportes->actualizarEstadoReporte($id_reporte, $estado);
    }

    // Procesar eliminación de comentario
    if (isset($_POST['eliminar_comentario'])) {
        $id_opinion = $_POST['id_opinion'];
        $motivo_eliminacion = $_POST['motivo_eliminacion'];
        $reportes->eliminarComentario($id_opinion, $motivo_eliminacion);
        header("Location: ver_reportes.php");
        exit;
    }
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ver Reportes</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        header {
            background: #35424a;
            color: white;
            padding: 20px;
            text-align: center;
        }
        .container {
            width: 80%;
            margin: 20px auto;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #35424a;
            color: white;
        }
        .btn {
            padding: 5px 10px;
            background-color: #e8491d;
            color: white;
            text-decoration: none;
            border-radius: 5px;
        }
        .btn:hover {
            background-color: #35424a;
        }
        .status-pending {
            color: orange;
        }
        .status-reviewed {
            color: green;
        }
        .btn-update {
            background-color: #35424a;
        }
        .btn-update:hover {
            background-color: #e8491d;
        }
    </style>
</head>
<body>

<header>
    <h1>Reportes de Comentarios</h1>
</header>

<div class="container">
    <table>
        <thead>
            <tr>
                <th>ID Reporte</th>
                <th>Comentario Reportado</th>
                <th>Motivo</th>
                <th>ID Receta</th>
                <th>Nombre Receta</th>
                <th>ID Usuario Comentario</th>
                <th>Fecha de Reporte</th>
                <th>Estado</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($reportes_lista): ?>
                <?php foreach ($reportes_lista as $reporte): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($reporte['id_reporte']); ?></td>
                        <td><?php echo nl2br(htmlspecialchars($reporte['comentario_reportado'])); ?></td>
                        <td><?php echo nl2br(htmlspecialchars($reporte['motivo'])); ?></td>
                        <td><?php echo htmlspecialchars($reporte['id_receta']); ?></td>
                        <td><?php echo nl2br(htmlspecialchars($reporte['nombre_receta'])); ?></td>
                        <td><?php echo htmlspecialchars($reporte['usuario_comentario']); ?></td>
                        <td><?php echo $reporte['fecha_reporte']; ?></td>
                        <td class="<?php echo $reporte['estado'] === 'pendiente' ? 'status-pending' : 'status-reviewed'; ?>">
                            <?php echo ucfirst($reporte['estado']); ?>
                        </td>
                        <td>
                            <form method="POST">
                                <input type="hidden" name="id_reporte" value="<?php echo $reporte['id_reporte']; ?>">
                                <select name="estado">
                                    <option value="pendiente" <?php echo $reporte['estado'] === 'pendiente' ? 'selected' : ''; ?>>Pendiente</option>
                                    <option value="revisado" <?php echo $reporte['estado'] === 'revisado' ? 'selected' : ''; ?>>Revisado</option>
                                </select>
                                <button type="submit" name="revisar_reporte" class="btn btn-update">Actualizar Estado</button>
                            </form>

                            <!-- Botón para eliminar comentario -->
                            <form method="POST">
                                <input type="hidden" name="id_opinion" value="<?php echo $reporte['id_opinion']; ?>">
                                <label for="motivo_eliminacion">Motivo de eliminación:</label>
                                <textarea name="motivo_eliminacion" required></textarea><br><br>
                                <button type="submit" name="eliminar_comentario" class="btn btn-update">Eliminar Comentario</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="9">No hay reportes para mostrar.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <a href="dashboard_admin.php" class="btn">Volver al Panel de Administrador</a>
</div>

</body>
</html>

<?php
require_once 'connection_db.php';

class Auth {
    private $db;

    public function __construct() {
        $this->db = (new Database())->getConnection();
    }

    public function login($email, $password) {
        $sql = "SELECT * FROM usuarios WHERE email = :email";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':email', $email, PDO::PARAM_STR);
        $stmt->execute();

        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($user && password_verify($password, $user['contrasena'])) {
            // Retornar datos del usuario, excluyendo información sensible
            unset($user['contrasena']);
            return $user;
        } else {
            return false;
        }
    }

    public function register($name, $email, $password, $role = 'usuario') {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $sql = "INSERT INTO usuarios (nombre, email, contrasena, rol) VALUES (:nombre, :email, :contrasena, :rol)";
        $stmt = $this->db->prepare($sql);

        $stmt->bindParam(':nombre', $name, PDO::PARAM_STR);
        $stmt->bindParam(':email', $email, PDO::PARAM_STR);
        $stmt->bindParam(':contrasena', $hashedPassword, PDO::PARAM_STR);
        $stmt->bindParam(':rol', $role, PDO::PARAM_STR);

        try {
            $stmt->execute();
            return true;
        } catch (PDOException $e) {
            // Manejar errores de manera apropiada, como retornar un mensaje amigable
            error_log("Error en registro: " . $e->getMessage());
            return false;
        }
    }
}

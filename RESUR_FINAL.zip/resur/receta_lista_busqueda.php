<?php
session_start();

// Verificar si el usuario está logueado, si no, redirigir al login
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_nombre']) || !isset($_SESSION['user_email'])) {
    header("Location: login.php");
    exit;
}



class Database {
    private $host = 'localhost';
    private $db = 'recesur';
    private $user = 'root';
    private $pass = '';
    private $charset = 'utf8mb4';
    private $pdo;

    public function __construct() {
        $dsn = "mysql:host={$this->host};dbname={$this->db};charset={$this->charset}";
        try {
            $this->pdo = new PDO($dsn, $this->user, $this->pass);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die("Error de conexión: " . $e->getMessage());
        }
    }

    public function getConnection() {
        return $this->pdo;
    }
}

// Crear la conexión a la base de datos
$database = new Database();
$pdo = $database->getConnection();

// Obtener el ID de la receta de la URL
$receta_id = isset($_GET['id']) ? $_GET['id'] : null;

// Depurar: Verificar si el ID está pasando correctamente
var_dump($receta_id); // Esto debería mostrar el ID de la receta. Si es null, no está pasando correctamente.

if ($receta_id) {
    // Verificar que el ID es válido y es un número entero
    if (!is_numeric($receta_id)) {
        die('ID de receta no válido');
    }

    // Obtener los detalles de la receta
    $query = "SELECT r.id_receta, r.nombre_receta, r.descripcion, r.instrucciones 
              FROM recetas r 
              WHERE r.id_receta = :receta_id";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':receta_id', $receta_id, PDO::PARAM_INT);
    $stmt->execute();
    $receta = $stmt->fetch(PDO::FETCH_ASSOC);

    // Depuración: Verificar si la receta existe
    if (!$receta) {
        echo "Receta no encontrada en la base de datos. ID: " . $receta_id;
        exit; // Detener ejecución si no se encuentra la receta.
    }

    // Obtener los ingredientes de la receta
    $query_ingredientes = "SELECT i.nombre_ingrediente, ri.cantidad 
                           FROM receta_ingredientes ri 
                           JOIN ingredientes i ON ri.id_ingrediente = i.id_ingrediente 
                           WHERE ri.id_receta = :receta_id";
    $stmt_ingredientes = $pdo->prepare($query_ingredientes);
    $stmt_ingredientes->bindParam(':receta_id', $receta_id, PDO::PARAM_INT);
    $stmt_ingredientes->execute();
    $ingredientes = $stmt_ingredientes->fetchAll(PDO::FETCH_ASSOC);
} else {
    echo "ID de receta no proporcionado.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalles de la Receta</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        header {
            background: #35424a;
            color: white;
            padding: 20px;
            text-align: center;
        }
        header h1 {
            margin: 0;
        }
        .container {
            width: 80%;
            margin: 20px auto;
        }
        .recipe-details {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .recipe-details h2 {
            margin-top: 0;
        }
        .recipe-details ul {
            list-style: none;
            padding: 0;
        }
        .recipe-details ul li {
            margin: 5px 0;
        }
        .btn {
            background-color: #e8491d;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
        }
        .btn:hover {
            background-color: #35424a;
        }
    </style>
</head>
<body>
    <header>
        <h1>Detalles de la Receta</h1>
    </header>

    <div class="container">
        <?php if ($receta): ?>
            <div class="recipe-details">
                <h2><?php echo htmlspecialchars($receta['nombre_receta']); ?></h2>
                <p><strong>Descripción:</strong> <?php echo nl2br(htmlspecialchars($receta['descripcion'])); ?></p>
                <h3>Ingredientes:</h3>
                <ul>
                    <?php foreach ($ingredientes as $ingrediente): ?>
                        <li><?php echo htmlspecialchars($ingrediente['nombre_ingrediente']) . " - " . htmlspecialchars($ingrediente['cantidad']); ?></li>
                    <?php endforeach; ?>
                </ul>
                <h3>Instrucciones:</h3>
                <p><?php echo nl2br(htmlspecialchars($receta['instrucciones'])); ?></p>
                <a href="dashboard_usuario.php" class="btn">Volver al Dashboard</a>
            </div>
        <?php else: ?>
            <p>Receta no encontrada.</p>
        <?php endif; ?>
    </div>
</body>
</html>

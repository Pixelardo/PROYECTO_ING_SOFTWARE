<?php
session_start();
require_once 'includes/connection_db.php';

class Auth {
    private $db;

    public function __construct() {
        $this->db = (new Database())->getConnection();
    }

    // Método para obtener la información del usuario y sus datos adicionales
    public function getUserInfo($user_id) {
        $sql = "SELECT u.*, d.rut, d.telefono, d.fecha_nacimiento, d.estado_cuenta 
                FROM usuarios u
                LEFT JOIN datos_usuarios d ON u.id_usuario = d.id_usuario
                WHERE u.id_usuario = :user_id";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Método para actualizar la información del usuario y sus datos adicionales
    public function updateUserInfo($user_id, $name, $apellido_paterno, $apellido_materno, $email, $diet_preferences, $rut, $telefono, $fecha_nacimiento, $estado_cuenta) {
        try {
            // Iniciar transacción
            $this->db->beginTransaction();

            // Actualizar datos en la tabla `usuarios`
            $sqlUsuario = "UPDATE usuarios 
                           SET nombre = :nombre, apellido_paterno = :apellido_paterno, apellido_materno = :apellido_materno, 
                               email = :email, preferencias_dietas = :preferencias_dietas
                           WHERE id_usuario = :user_id";
            $stmtUsuario = $this->db->prepare($sqlUsuario);

            $stmtUsuario->bindParam(':nombre', $name);
            $stmtUsuario->bindParam(':apellido_paterno', $apellido_paterno);
            $stmtUsuario->bindParam(':apellido_materno', $apellido_materno);
            $stmtUsuario->bindParam(':email', $email);
            $stmtUsuario->bindParam(':preferencias_dietas', $diet_preferences);
            $stmtUsuario->bindParam(':user_id', $user_id, PDO::PARAM_INT);

            $stmtUsuario->execute();

            // Actualizar datos en la tabla `datos_usuarios`
            $sqlDatos = "INSERT INTO datos_usuarios (id_usuario, rut, telefono, fecha_nacimiento, estado_cuenta) 
                         VALUES (:user_id, :rut, :telefono, :fecha_nacimiento, :estado_cuenta)
                         ON DUPLICATE KEY UPDATE 
                         rut = :rut, telefono = :telefono, fecha_nacimiento = :fecha_nacimiento, estado_cuenta = :estado_cuenta";
            $stmtDatos = $this->db->prepare($sqlDatos);

            $stmtDatos->bindParam(':user_id', $user_id, PDO::PARAM_INT);
            $stmtDatos->bindParam(':rut', $rut);
            $stmtDatos->bindParam(':telefono', $telefono);
            $stmtDatos->bindParam(':fecha_nacimiento', $fecha_nacimiento);
            $stmtDatos->bindParam(':estado_cuenta', $estado_cuenta);

            $stmtDatos->execute();

            // Confirmar la transacción
            $this->db->commit();
            return true;
        } catch (PDOException $e) {
            // Revertir la transacción en caso de error
            $this->db->rollBack();
            return false;
        }
    }

    // Método para cambiar el estado de la cuenta
    public function updateAccountStatus($user_id, $status) {
        try {
            $sql = "UPDATE datos_usuarios SET estado_cuenta = :estado_cuenta WHERE id_usuario = :user_id";
            $stmt = $this->db->prepare($sql);
            $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
            $stmt->bindParam(':estado_cuenta', $status, PDO::PARAM_STR);
            $stmt->execute();
            return true;
        } catch (PDOException $e) {
            return false;
        }
    }

    // Método para eliminar todos los datos relacionados al usuario
    public function deleteUserAccount($user_id) {
        try {
            // Iniciar transacción
            $this->db->beginTransaction();

            // Eliminar datos en la tabla `datos_usuarios`
            $sqlDatos = "DELETE FROM datos_usuarios WHERE id_usuario = :user_id";
            $stmtDatos = $this->db->prepare($sqlDatos);
            $stmtDatos->bindParam(':user_id', $user_id, PDO::PARAM_INT);
            $stmtDatos->execute();

            // Eliminar datos en la tabla `usuarios`
            $sqlUsuario = "DELETE FROM usuarios WHERE id_usuario = :user_id";
            $stmtUsuario = $this->db->prepare($sqlUsuario);
            $stmtUsuario->bindParam(':user_id', $user_id, PDO::PARAM_INT);
            $stmtUsuario->execute();

            // Confirmar la transacción
            $this->db->commit();
            return true;
        } catch (PDOException $e) {
            // Revertir la transacción en caso de error
            $this->db->rollBack();
            return false;
        }
    }
}

// Verificar si el usuario está logueado
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php"); // Redirigir al login si no está logueado
    exit;
}

$user_id = $_SESSION['user_id']; // Obtener el ID del usuario logueado
$auth = new Auth();
$user_info = $auth->getUserInfo($user_id); // Obtener la información del usuario desde la base de datos

// Si el formulario fue enviado, actualizar la información
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_user'])) {
        // Actualización de datos del usuario
        $name = $_POST['name'] ?? '';
        $apellido_paterno = $_POST['apellido_paterno'] ?? '';
        $apellido_materno = $_POST['apellido_materno'] ?? '';
        $email = $_POST['email'] ?? '';
        $diet_preferences = $_POST['diet_preferences'] ?? 'normal';

        $rut = $_POST['rut'] ?? '';
        $telefono = $_POST['telefono'] ?? '';
        $fecha_nacimiento = $_POST['fecha_nacimiento'] ?? '';

        $success = $auth->updateUserInfo($user_id, $name, $apellido_paterno, $apellido_materno, $email, $diet_preferences, $rut, $telefono, $fecha_nacimiento, $user_info['estado_cuenta']);
        if ($success) {
            $message = "Información actualizada correctamente.";
            $user_info = $auth->getUserInfo($user_id); // Actualizar la información en pantalla
        } else {
            $error = "Error al actualizar la información. Intente nuevamente.";
        }
    }

    // Si se ha solicitado desactivar la cuenta
    if (isset($_POST['deactivate_account'])) {
        $success = $auth->updateAccountStatus($user_id, 'desactivada');
        if ($success) {
            $message = "Cuenta desactivada correctamente.";
        } else {
            $error = "Error al desactivar la cuenta.";
        }
    }

    // Si se ha solicitado eliminar la cuenta
    if (isset($_POST['delete_account'])) {
        $success = $auth->deleteUserAccount($user_id);
        if ($success) {
            // Redirigir al login después de eliminar la cuenta
            session_destroy(); // Eliminar la sesión
            header("Location: index.php");
            exit;
        } else {
            $error = "Error al eliminar la cuenta.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Información</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        /* Contenedor del logo */
.logo-container {
    display: flex;
    justify-content: center;
    align-items: center;
    margin-bottom: 20px; /* Espaciado entre el logo y el formulario */
}

.logo-container img {
    width: 500px; /* Ajusta el tamaño según tus necesidades */
    height: auto;
}

/* Estilo para los campos del formulario */
.form-container input,
.form-container select {
    width: 100%;
    padding: 12px; /* Ajuste del tamaño del campo */
    font-size: 16px; /* Tamaño de la fuente más grande */
    margin-bottom: 15px;
    border: 1px solid #ddd; /* Borde sutil */
    border-radius: 8px; /* Bordes redondeados */
    transition: border-color 0.3s, box-shadow 0.3s; /* Transiciones para enfoque */
}

.form-container input:focus,
.form-container select:focus {
    border-color: #e8491d; /* Color del borde al enfocar */
    box-shadow: 0 0 8px rgba(232, 73, 29, 0.5); /* Sombra al enfocar */
    outline: none; /* Elimina el contorno azul por defecto */
}

/* Botones */
.form-container button {
    width: 100%;
    padding: 12px;
    font-size: 16px;
    background: #35424a;
    color: white;
    border: none;
    border-radius: 8px;
    cursor: pointer;
    margin-bottom: 15px; /* Añadimos un margen inferior para separar los botones */
    transition: background-color 0.3s ease;
}

.form-container button:hover {
    background: #e8491d;
}

/* Mensajes */
.error, .message {
    text-align: center;
    font-size: 14px;
    margin-bottom: 10px;
}

.error {
    color: red;
}

.message {
    color: green;
}
    </style>
</head>
<body>
    <div class="form-container">
        <div class="logo-container">
            <a href="dashboard_usuario.php">
                <img src="logod.png" alt="Logo">
            </a>
        </div>
        <h1>Editar Información</h1>

        <?php if (!empty($error)): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>
        
        <?php if (!empty($message)): ?>
            <p class="message"><?php echo htmlspecialchars($message); ?></p>
        <?php endif; ?>

        <form method="POST">
            <label for="name">Nombre</label>
            <input type="text" name="name" id="name" value="<?php echo htmlspecialchars($user_info['nombre']); ?>" required>

            <label for="apellido_paterno">Apellido Paterno</label>
            <input type="text" name="apellido_paterno" id="apellido_paterno" value="<?php echo htmlspecialchars($user_info['apellido_paterno']); ?>" required>

            <label for="apellido_materno">Apellido Materno</label>
            <input type="text" name="apellido_materno" id="apellido_materno" value="<?php echo htmlspecialchars($user_info['apellido_materno']); ?>" required>

            <label for="email">Correo Electrónico</label>
            <input type="email" name="email" id="email" value="<?php echo htmlspecialchars($user_info['email']); ?>" required>

            <label for="diet_preferences">Preferencias Dietéticas</label>
            <select name="diet_preferences" id="diet_preferences">
                <option value="normal" <?php echo $user_info['preferencias_dietas'] === 'normal' ? 'selected' : ''; ?>>Normal</option>
                <option value="sin_gluten" <?php echo $user_info['preferencias_dietas'] === 'sin_gluten' ? 'selected' : ''; ?>>Sin Gluten</option>
                <option value="vegetariano" <?php echo $user_info['preferencias_dietas'] === 'vegetariano' ? 'selected' : ''; ?>>Vegetariano</option>
                <option value="vegano" <?php echo $user_info['preferencias_dietas'] === 'vegano' ? 'selected' : ''; ?>>Vegano</option>
            </select>

            <label for="rut">RUT</label>
            <input type="text" name="rut" id="rut" value="<?php echo htmlspecialchars($user_info['rut']); ?>" required>

            <label for="telefono">Teléfono</label>
            <input type="text" name="telefono" id="telefono" value="<?php echo htmlspecialchars($user_info['telefono']); ?>" required>

            <label for="fecha_nacimiento">Fecha de Nacimiento</label>
            <input type="date" name="fecha_nacimiento" id="fecha_nacimiento" value="<?php echo htmlspecialchars($user_info['fecha_nacimiento']); ?>" required>

            <button type="submit" name="update_user">Actualizar Información</button>
        </form>

        <form method="POST">
            <button type="submit" name="delete_account" class="btn-danger" onclick="return confirmAction('eliminar');">Eliminar Cuenta</button>
        </form>

        <a href="dashboard_usuario.php"><button class="btn-back">Volver al Inicio</button></a>
    </div>

    <!-- Modal de Confirmación -->
    <div id="confirmationModal" style="display:none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); color: white; text-align: center; padding-top: 150px;">
        <div style="background: #35424a; padding: 20px; border-radius: 5px; width: 300px; margin: auto;">
            <h2>¿Estás seguro?</h2>
            <p id="confirmationMessage">¿Quieres continuar con la acción?</p>
            <button id="confirmBtn" style="background: #e8491d; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer;">Confirmar</button>
            <button onclick="document.getElementById('confirmationModal').style.display='none'" style="background: #35424a; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer;">Cancelar</button>
        </div>
    </div>

    <script>
        let actionToConfirm = '';

        function confirmAction(action) {
            actionToConfirm = action;
            const modal = document.getElementById('confirmationModal');
            const message = document.getElementById('confirmationMessage');
            if (action === 'desactivar') {
                message.textContent = '¿Seguro que deseas desactivar tu cuenta?';
            } else if (action === 'eliminar') {
                message.textContent = '¿Seguro que deseas eliminar tu cuenta? Esta acción no se puede deshacer.';
            }
            modal.style.display = 'block';
            return false; // Prevenir que el formulario se envíe automáticamente
        }

        document.getElementById('confirmBtn').onclick = function() {
            const form = document.createElement('form');
            form.method = 'POST';
            form.style.display = 'none';

            if (actionToConfirm === 'desactivar') {
                const input = document.createElement('input');
                input.type = 'hidden';
                input.name = 'deactivate_account';
                form.appendChild(input);
            } else if (actionToConfirm === 'eliminar') {
                const input = document.createElement('input');
                input.type = 'hidden';
                input.name = 'delete_account';
                form.appendChild(input);
            }

            document.body.appendChild(form);
            form.submit();
        }
    </script>
</body>
</html>

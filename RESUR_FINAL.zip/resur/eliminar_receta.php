<?php
// Clase para la conexión a la base de datos
class Conexion {
    private $host = 'localhost';
    private $user = 'root';
    private $password = '';
    private $dbname = 'recesur';
    private $conn;

    public function __construct() {
        try {
            $this->conn = new mysqli($this->host, $this->user, $this->password, $this->dbname);
            if ($this->conn->connect_error) {
                die("Error de conexión: " . $this->conn->connect_error);
            }
        } catch (Exception $e) {
            die("Error de conexión: " . $e->getMessage());
        }
    }

    public function getConexion() {
        return $this->conn;
    }

    public function closeConexion() {
        $this->conn->close();
    }
}

// Clase para manejar las recetas
class Receta {
    private $conexion;

    public function __construct($conexion) {
        $this->conexion = $conexion;
    }

    // Obtener todas las recetas
    public function obtenerRecetas() {
        $sql = "SELECT id_receta, nombre_receta FROM recetas";
        $result = $this->conexion->query($sql);

        if ($result->num_rows > 0) {
            return $result->fetch_all(MYSQLI_ASSOC);
        } else {
            return [];
        }
    }

    // Eliminar receta
    public function eliminarReceta($id_receta) {
        $sql = "DELETE FROM recetas WHERE id_receta = ?";
        $stmt = $this->conexion->prepare($sql);
        $stmt->bind_param("i", $id_receta);
        return $stmt->execute();
    }
}

// Instanciamos la conexión y las clases
$conexion = new Conexion();
$receta = new Receta($conexion->getConexion());

// Si se ha enviado el formulario para eliminar una receta
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id_receta'])) {
    $id_receta = $_POST['id_receta'];
    if ($receta->eliminarReceta($id_receta)) {
        echo "<script>alert('Receta eliminada exitosamente.'); window.location.href='eliminar_receta.php';</script>";
    } else {
        echo "<script>alert('Error al eliminar la receta.'); window.location.href='eliminar_receta.php';</script>";
    }
}

// Obtener todas las recetas para mostrarlas
$recetas = $receta->obtenerRecetas();
$conexion->closeConexion();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Eliminar Receta</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        header {
            background: #35424a;
            color: #ffffff;
            padding: 20px 0;
            text-align: center;
        }
        header h1 {
            margin: 0;
            font-size: 24px;
        }
        .volver {
            text-align: center;
            margin: 20px 0;
        }
        .volver button {
            padding: 10px 20px;
            font-size: 16px;
            background-color: #e8491d;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        .volver button:hover {
            background-color: #35424a;
        }
        .container {
            width: 80%;
            margin: auto;
            overflow: hidden;
            padding-top: 20px;
        }
        .grid-container {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 20px;
            padding: 20px;
        }
        .grid-item {
            background: #ffffff;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        .grid-item button {
            padding: 10px;
            font-size: 14px;
            background-color: #e8491d;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .grid-item button:hover {
            background-color: #35424a;
        }
    </style>
</head>
<body>
    <header>
        <h1>Eliminar Receta</h1>
    </header>
    <!-- Botón Volver al Menú -->
    <div class="volver">
        <form method="GET" action="dashboard_admin.php">
            <button type="submit">Volver al Menú</button>
        </form>
    </div>
    <div class="container">
        <div class="grid-container">
            <?php if (count($recetas) > 0): ?>
                <?php foreach ($recetas as $row): ?>
                    <div class="grid-item">
                        <p><strong>ID:</strong> <?php echo htmlspecialchars($row['id_receta']); ?></p>
                        <p><strong>Nombre:</strong> <?php echo htmlspecialchars($row['nombre_receta']); ?></p>
                        <form method="POST" action="eliminar_receta.php">
                            <input type="hidden" name="id_receta" value="<?php echo htmlspecialchars($row['id_receta']); ?>">
                            <button type="submit">Eliminar</button>
                        </form>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>No hay recetas disponibles.</p>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>

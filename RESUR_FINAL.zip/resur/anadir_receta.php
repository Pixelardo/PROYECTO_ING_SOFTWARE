<?php
session_start();

// Verificar si el usuario está logueado, si no, redirigir al login
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_nombre']) || !isset($_SESSION['user_email'])) {
    header("Location: login.php");
    exit;
}

// Conexión a la base de datos
$host = 'localhost';
$user = 'root';
$password = '';
$dbname = 'recesur';

$conn = new mysqli($host, $user, $password, $dbname);
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

$mensaje = "";

// Procesar el formulario
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nombre = $conn->real_escape_string($_POST['nombre_receta']);
    $descripcion = $conn->real_escape_string($_POST['descripcion']);
    $tipo_comida = $conn->real_escape_string($_POST['tipo_comida']);
    $dieta = $conn->real_escape_string($_POST['dieta']);
    $instrucciones = $conn->real_escape_string($_POST['instrucciones']);

    // Insertar la receta
    $sql_receta = "INSERT INTO recetas (nombre_receta, descripcion, tipo_comida, dieta, instrucciones)
                   VALUES ('$nombre', '$descripcion', '$tipo_comida', '$dieta', '$instrucciones')";

    if ($conn->query($sql_receta) === TRUE) {
        $receta_id = $conn->insert_id; // Obtener el ID de la receta recién insertada

        // Procesar los ingredientes
        if (isset($_POST['ingredientes']) && !empty($_POST['ingredientes'])) {
            foreach ($_POST['ingredientes'] as $ingrediente) {
                $nombre_ingrediente = $conn->real_escape_string($ingrediente['nombre_ingrediente']);
                $cantidad = $conn->real_escape_string($ingrediente['cantidad']);

                // Insertar los ingredientes en la tabla 'ingredientes'
                $sql_ingrediente = "INSERT INTO ingredientes (nombre_ingrediente) 
                                    VALUES ('$nombre_ingrediente')";

                if ($conn->query($sql_ingrediente) === TRUE) {
                    $ingrediente_id = $conn->insert_id; // Obtener el ID del ingrediente insertado

                    // Relacionar el ingrediente con la receta
                    $sql_receta_ingrediente = "INSERT INTO receta_ingredientes (id_receta, id_ingrediente, cantidad) 
                                               VALUES ($receta_id, $ingrediente_id, '$cantidad')";
                    $conn->query($sql_receta_ingrediente);
                }
            }
        }

        $mensaje = "Receta añadida exitosamente.";
    } else {
        $mensaje = "Error al añadir la receta: " . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Añadir Receta</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 80%;
            margin: auto;
            overflow: hidden;
        }
        header {
            background: #35424a;
            color: #ffffff;
            padding: 20px 0;
            text-align: center;
        }
        header h1 {
            margin: 0;
            font-size: 24px;
        }
        form {
            background: #ffffff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        form label {
            display: block;
            margin-top: 10px;
            font-size: 14px;
        }
        form input, form select, form textarea, form button {
            width: 100%;
            margin-top: 5px;
            padding: 10px;
            font-size: 14px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        form button {
            background-color: #35424a;
            color: white;
            border: none;
            cursor: pointer;
        }
        form button:hover {
            background-color: #e8491d;
        }
        .mensaje {
            margin-top: 20px;
            text-align: center;
            font-size: 16px;
            color: #333;
        }
        .btn-volver {
            display: block;
            margin: 20px auto;
            text-align: center;
            padding: 10px 20px;
            font-size: 16px;
            background-color: #35424a;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            width: fit-content;
        }
        .btn-volver:hover {
            background-color: #e8491d;
        }
        .ingredient-fields {
            display: flex;
            gap: 10px;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <header>
        <h1>Añadir Nueva Receta</h1>
    </header>
    <div class="container">
        <form method="POST">
            <label for="nombre_receta">Nombre de la receta:</label>
            <input type="text" id="nombre_receta" name="nombre_receta" required>

            <label for="descripcion">Descripción:</label>
            <textarea id="descripcion" name="descripcion" rows="3" required></textarea>

            <label for="tipo_comida">Tipo de comida:</label>
            <select id="tipo_comida" name="tipo_comida" required>
                <option value="desayuno">Desayuno</option>
                <option value="almuerzo">Almuerzo</option>
                <option value="cena">Cena</option>
            </select>

            <label for="dieta">Dieta:</label>
            <select id="dieta" name="dieta" required>
                <option value="sin_gluten">Sin Gluten</option>
                <option value="vegetariano">Vegetariano</option>
                <option value="vegano">Vegano</option>
                <option value="normal">Normal</option>
            </select>

            <label for="instrucciones">Instrucciones:</label>
            <textarea id="instrucciones" name="instrucciones" rows="5" required></textarea>

            <!-- Ingredientes -->
            <h3>Ingredientes</h3>
            <div id="ingredients-container">
                <div class="ingredient-fields">
                    <input type="text" name="ingredientes[0][nombre_ingrediente]" placeholder="Nombre del ingrediente" required>
                    <input type="text" name="ingredientes[0][cantidad]" placeholder="Cantidad" required>
                </div>
            </div>
            <button type="button" id="add-ingredient">Añadir Ingrediente</button>

            <button type="submit">Añadir Receta</button>
        </form>

        <?php if ($mensaje): ?>
            <div class="mensaje">
                <?php echo $mensaje; ?>
            </div>
        <?php endif; ?>

        <!-- Botón para regresar al dashboard -->
        <a href="dashboard_admin.php" class="btn-volver">Volver al Menu</a>
    </div>

    <script>
        document.getElementById('add-ingredient').addEventListener('click', function() {
            const container = document.getElementById('ingredients-container');
            const newIngredient = document.createElement('div');
            newIngredient.classList.add('ingredient-fields');
            newIngredient.innerHTML = `
                <input type="text" name="ingredientes[new][nombre_ingrediente]" placeholder="Nombre del ingrediente" required>
                <input type="text" name="ingredientes[new][cantidad]" placeholder="Cantidad" required>
            `;
            container.appendChild(newIngredient);
        });
    </script>
</body>
</html>

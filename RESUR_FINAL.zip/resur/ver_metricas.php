<?php
session_start();

// Verificar si el administrador está logueado
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_nombre']) || !isset($_SESSION['user_email'])) {
    header("Location: login.php");
    exit;
}

// Clase Database
class Database {
    private $host = 'localhost';
    private $db = 'recesur';
    private $user = 'root';
    private $pass = '';
    private $charset = 'utf8mb4';
    private $pdo;

    public function __construct() {
        $dsn = "mysql:host={$this->host};dbname={$this->db};charset={$this->charset}";
        try {
            $this->pdo = new PDO($dsn, $this->user, $this->pass);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die("Error de conexión: " . $e->getMessage());
        }
    }

    public function getConnection() {
        return $this->pdo;
    }
}

// Crear conexión
$database = new Database();
$pdo = $database->getConnection();

// Consultar cuántos usuarios están activos, desactivados y sus preferencias dietéticas
$query = "
    SELECT estado_cuenta, COUNT(*) AS total 
    FROM datos_usuarios 
    GROUP BY estado_cuenta
";
$stmt = $pdo->prepare($query);
$stmt->execute();
$resultado = $stmt->fetchAll(PDO::FETCH_ASSOC);

$activos = 0;
$desactivados = 0;

foreach ($resultado as $row) {
    if ($row['estado_cuenta'] == 'activa') {
        $activos = $row['total'];
    } elseif ($row['estado_cuenta'] == 'desactivada') {
        $desactivados = $row['total'];
    }
}

// Consultar preferencias dietéticas
$query_dietas = "
    SELECT preferencias_dietas, COUNT(*) AS total 
    FROM usuarios 
    GROUP BY preferencias_dietas
";
$stmt_dietas = $pdo->prepare($query_dietas);
$stmt_dietas->execute();
$dietas_resultado = $stmt_dietas->fetchAll(PDO::FETCH_ASSOC);

$preferencias_dietas = [
    'sin_gluten' => 0,
    'vegetariano' => 0,
    'vegano' => 0,
    'normal' => 0
];

foreach ($dietas_resultado as $row) {
    if (array_key_exists($row['preferencias_dietas'], $preferencias_dietas)) {
        $preferencias_dietas[$row['preferencias_dietas']] = $row['total'];
    }
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Métricas de Usuarios</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        header {
            background: #35424a;
            color: white;
            padding: 20px 0;
            text-align: center;
        }
        header h1 {
            margin: 0;
            font-size: 24px;
        }
        .container {
            width: 80%;
            margin: auto;
            overflow: hidden;
            padding-top: 20px;
        }
        .result {
            background: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        .result h3 {
            margin: 20px 0;
            color: #35424a;
        }
        .result p {
            font-size: 18px;
            color: #333;
        }
        canvas {
            max-width: 100%;
        }
        .btn-back {
            position: absolute;
            top: 20px;
            right: 20px;
            background-color: #e8491d;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
        }
        .btn-back:hover {
            background-color: #35424a;
        }
    </style>
</head>
<body>
    <header>
        <h1>Métricas de Usuarios</h1>
        <!-- Botón de Volver -->
        <a href="dashboard_admin.php" class="btn-back">Volver</a>
    </header>

    <div class="container">
        <div class="result">
            <h3>Usuarios Activos</h3>
            <p><?php echo $activos; ?> usuarios activos.</p>

            <h3>Usuarios Desactivados</h3>
            <p><?php echo $desactivados; ?> usuarios desactivados.</p>
        </div>

        <!-- Gráfico de preferencias dietéticas -->
        <div class="result">
            <h3>Preferencias Dietéticas de los Usuarios</h3>
            <canvas id="dietChart"></canvas>
        </div>
    </div>

    <script>
        // Gráfico de barras para las preferencias dietéticas
        const ctx = document.getElementById('dietChart').getContext('2d');
        const dietChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Sin Gluten', 'Vegetariano', 'Vegano', 'Normal'],
                datasets: [{
                    label: 'Cantidad de Usuarios',
                    data: [<?php echo $preferencias_dietas['sin_gluten']; ?>, <?php echo $preferencias_dietas['vegetariano']; ?>, <?php echo $preferencias_dietas['vegano']; ?>, <?php echo $preferencias_dietas['normal']; ?>],
                    backgroundColor: ['#ff9f40', '#ffcd56', '#4bc0c0', '#36a2eb'],
                    borderColor: ['#ff9f40', '#ffcd56', '#4bc0c0', '#36a2eb'],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
</body>
</html>

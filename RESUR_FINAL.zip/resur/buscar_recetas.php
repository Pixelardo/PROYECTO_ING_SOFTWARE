<?php
// Conexión a la base de datos
$pdo = new PDO('mysql:host=localhost;dbname=recesur', 'root', ''); // Actualiza tus credenciales si es necesario
$searchTerm = $_GET['search'] ?? '';

// Consulta para obtener las recetas que coinciden con el término de búsqueda
$query = "SELECT nombre_receta, descripcion FROM recetas WHERE nombre_receta LIKE :searchTerm OR descripcion LIKE :searchTerm";
$stmt = $pdo->prepare($query);
$stmt->bindValue(':searchTerm', '%' . $searchTerm . '%', PDO::PARAM_STR);
$stmt->execute();

// Obtener los resultados y devolverlos como JSON
$recipes = $stmt->fetchAll(PDO::FETCH_ASSOC);
echo json_encode($recipes);
?>

<?php
session_start();

// Verificar si el usuario está logueado, si no, redirigir al login
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_nombre']) || !isset($_SESSION['user_email'])) {
    header("Location: login.php");
    exit;
}

// Clase para la conexión a la base de datos
class Database {
    private $host = 'localhost';
    private $db = 'recesur';
    private $user = 'root';
    private $pass = '';
    private $charset = 'utf8mb4';
    private $pdo;

    public function __construct() {
        $dsn = "mysql:host={$this->host};dbname={$this->db};charset={$this->charset}";
        try {
            $this->pdo = new PDO($dsn, $this->user, $this->pass);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die("Error de conexión: " . $e->getMessage());
        }
    }

    public function getConnection() {
        return $this->pdo;
    }
}

// Clase Usuario para gestionar la información del usuario
class Usuario {
    private $pdo;
    private $user_id;

    public function __construct($pdo, $user_id) {
        $this->pdo = $pdo;
        $this->user_id = $user_id;
    }

    public function getNombre() {
        $query = "SELECT nombre FROM usuarios WHERE id_usuario = :user_id";
        $stmt = $this->pdo->prepare($query);
        $stmt->bindParam(':user_id', $this->user_id, PDO::PARAM_INT);
        $stmt->execute();
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
        return $usuario ? $usuario['nombre'] : null;
    }

    // Obtener las preferencias de dieta del usuario
    public function getPreferenciasDietas() {
        $query = "SELECT preferencias_dietas FROM usuarios WHERE id_usuario = :user_id";
        $stmt = $this->pdo->prepare($query);
        $stmt->bindParam(':user_id', $this->user_id, PDO::PARAM_INT);
        $stmt->execute();
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
        return $usuario ? $usuario['preferencias_dietas'] : 'normal'; // valor predeterminado
    }
}

// Crear un objeto Usuario a partir de los datos de la sesión
$database = new Database();
$pdo = $database->getConnection();
$user_id = $_SESSION['user_id'];
$usuario = new Usuario($pdo, $user_id);
$nombreUsuario = $usuario->getNombre();
$preferenciasDietas = $usuario->getPreferenciasDietas();

// Si las preferencias son "normal", mostrar todas las recetas
if ($preferenciasDietas === 'normal') {
    $query = "SELECT id_receta, nombre_receta, descripcion 
              FROM recetas 
              ORDER BY RAND() 
              LIMIT 6"; // Cambiar el número de recetas aquí si es necesario
} else {
    // Filtrar por la dieta específica
    $query = "SELECT id_receta, nombre_receta, descripcion 
              FROM recetas 
              WHERE dieta = :preferencias_dietas
              ORDER BY RAND() 
              LIMIT 6";
}

$stmt = $pdo->prepare($query);
if ($preferenciasDietas !== 'normal') {
    $stmt->bindParam(':preferencias_dietas', $preferenciasDietas, PDO::PARAM_STR);
}
$stmt->execute();
$recetas = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>


<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Usuario</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        header {
            background: #35424a;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 30px;
        }
        header h1 {
            margin: 0;
            font-size: 24px;
        }

        /* Contenedor del logo */
        .logo-container {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .logo-container img {
            width: 200px; /* Ajusta el tamaño del logo aquí */
            height: auto;
        }

        /* Menú de navegación */
        .nav-menu {
            display: flex;
            gap: 20px;
            font-size: 16px;
        }

        .nav-menu a {
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            background: #e8491d;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .nav-menu a:hover {
            background: #35424a;
        }

        /* Menú de perfil */
        .profile-menu {
            position: relative;
        }

        .profile-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: #e8491d;
            display: flex;
            justify-content: center;
            align-items: center;
            cursor: pointer;
        }

        .profile-icon img {
            width: 70%;
            height: auto;
        }

        .dropdown {
            position: absolute;
            right: 0;
            top: 50px;
            background: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 5px;
            overflow: hidden;
            display: none;
            z-index: 10;
        }

        .dropdown a {
            display: block;
            padding: 10px 20px;
            text-decoration: none;
            color: #333;
            background: white;
            font-size: 14px;
            transition: background-color 0.3s ease;
        }

        .dropdown a:hover {
            background-color: #f4f4f9;
        }

        /* Carrusel */
        .carousel-container {
            position: relative;
            width: 80%;
            margin: 40px auto;
            overflow: hidden;
        }
        .carousel {
            display: flex;
            transition: transform 0.5s ease;
        }
        .carousel-item {
            flex: 0 0 16.66%; /* Mostrar 6 elementos a la vez */
            margin-right: 20px;
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
            cursor: pointer;
        }
        .carousel-item img {
            width: 100%;
            height: auto;
            border-radius: 8px;
        }
        .carousel-item h3 {
            color: #35424a;
            margin-top: 10px;
        }
        .carousel-item p {
            color: #555;
            font-size: 14px;
        }
        .carousel-item a {
            display: block;
            margin-top: 15px;
            background: #e8491d;
            color: white;
            padding: 10px;
            border-radius: 5px;
            text-decoration: none;
            font-size: 14px;
        }

        /* Botones de navegación */
        .carousel-nav {
            position: absolute;
            top: 50%;
            width: 100%;
            display: flex;
            justify-content: space-between;
            transform: translateY(-50%);
        }
        .carousel-nav button {
            background-color: rgba(0, 0, 0, 0.5);
            color: white;
            border: none;
            padding: 10px;
            cursor: pointer;
            font-size: 18px;
        }
        .carousel-nav button:hover {
            background-color: rgba(0, 0, 0, 0.8);
        }
        /* Estilos para la sección de introducción al foro */
        .forum-intro {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin: 40px 20px;
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .forum-intro img {
            width: 40%;
            border-radius: 8px;
        }

        .forum-intro-text {
            width: 55%;
            padding-left: 20px;
        }

        .forum-intro h2 {
            color: #35424a;
            margin-bottom: 15px;
        }

        .forum-intro p {
            color: #555;
            font-size: 16px;
        }

        .forum-intro .btn-forum {
            margin-top: 20px;
            padding: 10px 20px;
            background: #e8491d;
            color: white;
            font-size: 16px;
            border-radius: 5px;
            text-decoration: none;
        }

        .forum-intro .btn-forum:hover {
            background: #35424a;
        }

 /* Acerca de */
.about-section {
    background-color: #ffffff;
    padding: 20px 200px;
    margin: 40px 20px;
    border-radius: 80px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.about-container {
    display: flex;
    flex-direction: column;
    gap: 20px;
}

.about-header {
    display: flex;
    align-items: center;
    gap: 15px;
}

.about-logo {
    width: 200px;
    height: auto;
}

.about-header h2 {
    color: #35424a;
    margin: 0;
}

.about-text {
    margin-top: 20px;
}

.about-text p {
    color: #555;
    font-size: 16px;
    margin-bottom: 15px;
}

.about-text ul {
    list-style: disc;
    margin-left: 20px;
    color: #555;
}


/* Contáctanos */
footer {
    background-color: #35424a;
    color: white;
    text-align: center;
    padding: 20px 0;
    margin-top: 40px;
}

.contact-section h2 {
    font-size: 24px;
    margin-bottom: 10px;
}

.contact-section p {
    font-size: 16px;
    margin-bottom: 20px;
}

.contact-links {
    display: flex;
    justify-content: center;
    gap: 20px;
}

.contact-links a {
    text-decoration: none;
    color: white;
    background-color: #e8491d;
    padding: 10px 20px;
    border-radius: 5px;
    font-size: 16px;
    transition: background-color 0.3s ease;
}

.contact-links a:hover {
    background-color: #ffffff;
    color: #35424a;
}

/* Carrusel de funcionalidades */
.features-carousel {
    text-align: center;
    background-color: #ffffff;
    padding: 40px 20px;
    margin: 40px 20px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.features-carousel h2 {
    color: #35424a;
    margin-bottom: 20px;
    font-size: 24px;
}

.features-carousel-container {
    display: flex;
    gap: 20px;
    justify-content: center;
    flex-wrap: wrap;
}

.features-carousel-item {
    flex: 0 1 30%; /* Ajusta para mostrar 3 elementos en la línea */
    background: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    text-align: center;
    transition: transform 0.3s ease, box-shadow 0.3s ease;
}

.features-carousel-item img {
    width: 100px;
    height: auto;
    margin-bottom: 10px;
}

.features-carousel-item h3 {
    color: #35424a;
    margin: 10px 0;
}

.features-carousel-item p {
    color: #555;
    font-size: 14px;
}

.features-carousel-item:hover {
    transform: translateY(-5px);
    box-shadow: 0 6px 12px rgba(0, 0, 0, 0.15);
}


        
    </style>
    <script>
        let currentSlide = 0;

        // Función para mover el carrusel manualmente
        function moveCarousel() {
            const carousel = document.querySelector('.carousel');
            const totalSlides = document.querySelectorAll('.carousel-item').length;
            currentSlide = (currentSlide + 1) % totalSlides;
            carousel.style.transform = `translateX(-${currentSlide * (100 / 6)}%)`; // Mover el carrusel
        }

        // Función para mover el carrusel hacia la izquierda
        function moveLeft() {
            const carousel = document.querySelector('.carousel');
            const totalSlides = document.querySelectorAll('.carousel-item').length;
            currentSlide = (currentSlide - 1 + totalSlides) % totalSlides;
            carousel.style.transform = `translateX(-${currentSlide * (100 / 6)}%)`;
        }

        // Función para mover el carrusel hacia la derecha
        function moveRight() {
            const carousel = document.querySelector('.carousel');
            const totalSlides = document.querySelectorAll('.carousel-item').length;
            currentSlide = (currentSlide + 1) % totalSlides;
            carousel.style.transform = `translateX(-${currentSlide * (100 / 6)}%)`;
        }
        
        function toggleDropdown() {
        const dropdown = document.getElementById('dropdown-menu');
        dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
    }

    // Cerrar el menú si se hace clic fuera de él
    window.addEventListener('click', function(event) {
        const dropdown = document.getElementById('dropdown-menu');
        const profileIcon = document.querySelector('.profile-icon');
        if (dropdown && profileIcon) {
            if (!profileIcon.contains(event.target) && !dropdown.contains(event.target)) {
                dropdown.style.display = 'none';
            }
        }
    });

        // Mover el carrusel cada 3 segundos
        setInterval(moveCarousel, 3000);
    </script>
</head>
<body>
    <header>
        <div class="logo-container">
            <a href="dashboard_usuario.php">
                <img src="logod.png" alt="Logo">
            </a>
        </div>

        <div class="nav-menu">
            <a href="ver_recetas.php">Ver Recetas</a>
            <a href="foro.php">Foro</a>
            <a href="buscar.php">Buscar Recetas por Ingrediente</a>
        </div>

        <div class="profile-menu">
            <div class="profile-icon" onclick="toggleDropdown()">
                <img src="profile-icon.png" alt="Perfil">
            </div>
            <div class="dropdown" id="dropdown-menu">
                <a href="Editar_Información.php">Editar Información</a>
                <a href="recetas_guardadas.php">Ver Recetas Guardadas</a>
                <a href="listas_compras.php">Ver Lista de Ingredientes</a>
                <a href="planificacion_comidas.php">Planificar Horarios</a>
                <a href="logout.php">Cerrar Sesión</a>
            </div>
        </div>
    </header>

    <!-- Bienvenida -->
    <h1>Bienvenido <?php echo $usuario->getNombre(); ?>, estas son algunas recetas recomendadas según tus preferencias</h1>

    <!-- Carrusel de recetas recomendadas -->
    <div class="carousel-container">
        <div class="carousel">
            <?php foreach ($recetas as $receta): ?>
                <div class="carousel-item">
                    <h3><?php echo htmlspecialchars($receta['nombre_receta']); ?></h3>
                    <p><?php echo htmlspecialchars($receta['descripcion']); ?></p>
                    <a href="ver_receta_detalles.php?id=<?php echo $receta['id_receta']; ?>">Ver Receta</a>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Flechas para mover el carrusel manualmente -->
        <div class="carousel-nav">
            <button onclick="moveLeft()">&#8592;</button>
            <button onclick="moveRight()">&#8594;</button>
        </div>
    </div>

    <!-- Sección Acerca de -->
<section class="about-section">
    <div class="about-container">
        <!-- Logo junto al título -->
        <div class="about-header">
            <h2>Acerca de</h2>
            <img src="logod.png" alt="Logo" class="about-logo">
        </div>
        <div class="about-text">
            <p>Bienvenido a nuestra plataforma de recetas, diseñada para mejorar tu experiencia culinaria. Aquí encontrarás recetas adaptadas a tus necesidades, podrás compartir tus propias experiencias y conectarte con una comunidad apasionada por la cocina. ¡Nuestro objetivo es facilitarte el camino hacia una alimentación deliciosa y saludable!</p>
            <p><strong>¿Qué te ofrecemos?</strong></p>
            <ul>
                <li>Recetas personalizadas basadas en tus preferencias.</li>
                <li>Un foro donde puedes compartir ideas y resolver dudas culinarias.</li>
                <li>Herramientas para planificar tus comidas y listas de compras.</li>
            </ul>
        </div>
    </div>
</section>

                <!-- Carrusel de funcionalidades -->
<section class="features-carousel">
    <h2>Nuestras Herramientas</h2>
    <div class="features-carousel-container">
        <div class="features-carousel">
            <!-- Función 1: Calendario -->
            <div class="features-carousel-item">
                <img src="calendario.png" alt="Calendario">
                <h3>Planificación de Comidas</h3>
                <p>Organiza tus horarios y planifica tus comidas de forma eficiente con nuestra herramienta de calendario.</p>
            </div>

            <!-- Función 2: Lupa -->
            <div class="features-carousel-item">
                <img src="luparda.png" alt="Explorar Recetas">
                <h3>Explorar Recetas</h3>
                <p>Descubre nuevas recetas más allá de tus preferencias seleccionadas. ¡Explora el mundo culinario!</p>
            </div>

            <!-- Función 3: Lista de compras -->
            <div class="features-carousel-item">
                <img src="lista.png" alt="Lista de Compras">
                <h3>Lista de Compras</h3>
                <p>Genera una lista de ingredientes necesaria para preparar tus recetas favoritas de forma sencilla.</p>
            </div>
        </div>
    </div>
</section>


    <!-- Introducción al Foro -->
    <div class="forum-intro">
        <img src="foro.png" alt="Foro">
        <div class="forum-intro-text">
            <h2>Únete a nuestra comunidad</h2>
            <p>El foro es el lugar perfecto para compartir recetas, discutir ideas culinarias, resolver dudas y conocer a otros entusiastas de la cocina. Participa y haz crecer nuestra comunidad. ¡Esperamos tus aportes!</p>
            <a href="foro.php" class="btn-forum">Ir al Foro</a>
        </div>
    </div>

    <!-- Sección Contáctanos -->
    <footer>
        <div class="contact-section">
            <h2>Contáctanos</h2>
            <p>Si tienes dudas, sugerencias o necesitas ayuda, no dudes en comunicarte con nosotros a través de los siguientes medios:</p>
            <div class="contact-links">
                <a href="https://wa.me/123456789" target="_blank">WhatsApp</a>
                <a href="https://www.facebook.com/tu-pagina" target="_blank">Facebook</a>
                <a href="https://www.instagram.com/tu-pagina" target="_blank">Instagram</a>
            </div>
        </div>
    </footer>
</body>

</html>

<?php
session_start();

// Verificar si el usuario está logueado
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_nombre']) || !isset($_SESSION['user_email'])) {
    header("Location: login.php");
    exit;
}

// Clase Database: conexión a la base de datos
class Database {
    private $host = 'localhost';
    private $db = 'recesur';
    private $user = 'root';
    private $pass = '';
    private $charset = 'utf8mb4';
    private $pdo;

    public function __construct() {
        $dsn = "mysql:host={$this->host};dbname={$this->db};charset={$this->charset}";
        try {
            $this->pdo = new PDO($dsn, $this->user, $this->pass);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die("Error de conexión: " . $e->getMessage());
        }
    }

    public function getConnection() {
        return $this->pdo;
    }
}

// Clase Usuario: gestionar datos del usuario
class Usuario {
    private $pdo;
    private $userId;

    public function __construct($pdo, $userId) {
        $this->pdo = $pdo;
        $this->userId = $userId;
    }

    public function getNombre() {
        $query = "SELECT nombre FROM usuarios WHERE id_usuario = :user_id";
        $stmt = $this->pdo->prepare($query);
        $stmt->bindParam(':user_id', $this->userId, PDO::PARAM_INT);
        $stmt->execute();
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
        return $usuario ? $usuario['nombre'] : null;
    }
}

// Clase Foro: gestionar opiniones y respuestas
class Foro {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    // Listar opiniones filtradas por receta con paginación
    public function listarOpiniones($filtro = '', $pagina = 1, $opinionesPorPagina = 5) {
        $offset = ($pagina - 1) * $opinionesPorPagina;
        $query = "SELECT o.id_opinion, r.nombre_receta, u.nombre, o.comentario, o.fecha 
                  FROM opiniones o
                  JOIN recetas r ON o.id_receta = r.id_receta
                  JOIN usuarios u ON o.id_usuario = u.id_usuario
                  WHERE r.nombre_receta LIKE :filtro
                  ORDER BY o.fecha DESC
                  LIMIT :offset, :opinionesPorPagina";
        $stmt = $this->pdo->prepare($query);
        $stmt->bindValue(':filtro', "%$filtro%", PDO::PARAM_STR);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->bindValue(':opinionesPorPagina', $opinionesPorPagina, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Agregar una nueva opinión
    public function agregarOpinion($idReceta, $idUsuario, $comentario) {
        $query = "INSERT INTO opiniones (id_receta, id_usuario, comentario) 
                  VALUES (:id_receta, :id_usuario, :comentario)";
        $stmt = $this->pdo->prepare($query);
        $stmt->bindParam(':id_receta', $idReceta, PDO::PARAM_INT);
        $stmt->bindParam(':id_usuario', $idUsuario, PDO::PARAM_INT);
        $stmt->bindParam(':comentario', $comentario, PDO::PARAM_STR);
        return $stmt->execute();
    }

    // Ver detalles de una opinión
    public function obtenerOpinion($idOpinion) {
        $query = "SELECT o.id_opinion, r.nombre_receta, u.nombre, o.comentario, o.fecha 
                  FROM opiniones o
                  JOIN recetas r ON o.id_receta = r.id_receta
                  JOIN usuarios u ON o.id_usuario = u.id_usuario
                  WHERE o.id_opinion = :id_opinion";
        $stmt = $this->pdo->prepare($query);
        $stmt->bindParam(':id_opinion', $idOpinion, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }
}

// Crear objetos de las clases
$database = new Database();
$pdo = $database->getConnection();
$userId = $_SESSION['user_id'];
$usuario = new Usuario($pdo, $userId);
$foro = new Foro($pdo);

// Lógica para agregar opiniones
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['agregar_opinion'])) {
    $idReceta = $_POST['id_receta'];
    $comentario = $_POST['comentario'];
    $foro->agregarOpinion($idReceta, $userId, $comentario);
    header("Location: foro.php");
    exit;
}

// Obtener el filtro de búsqueda
$filtro = '';
if (isset($_POST['buscar'])) {
    $filtro = $_POST['filtro'];
}

// Obtener las opiniones con paginación
$pagina = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
$opinionesPorPagina = 5;
$opiniones = $foro->listarOpiniones($filtro, $pagina, $opinionesPorPagina);

// Obtener el número total de opiniones para la paginación
$query = "SELECT COUNT(*) FROM opiniones o
          JOIN recetas r ON o.id_receta = r.id_receta
          WHERE r.nombre_receta LIKE :filtro";
$stmt = $pdo->prepare($query);
$stmt->bindValue(':filtro', "%$filtro%", PDO::PARAM_STR);
$stmt->execute();
$totalOpiniones = $stmt->fetchColumn();
$totalPaginas = ceil($totalOpiniones / $opinionesPorPagina);

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Foro de Opiniones</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        header {
            background: #35424a;
            color: white;
            padding: 20px;
            text-align: center;
            position: relative;
        }
        header h1 {
            margin: 0;
        }
        .logo-container {
            margin-top: 10px;
        }
        .logo-container img {
            width: 150px; /* Ajusta el tamaño del logo según tus necesidades */
            height: auto;
        }
        .container {
            width: 80%;
            margin: 20px auto;
        }
        .opinion-card {
            background: white;
            margin-bottom: 20px;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .opinion-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
        }
        .opinion-card h3 {
            color: #35424a;
        }
        .opinion-card p {
            color: #555;
        }
        .btn {
            display: inline-block;
            margin-top: 10px;
            padding: 10px 20px;
            color: white;
            background: #e8491d;
            border-radius: 5px;
            text-decoration: none;
            font-size: 14px;
        }
        .btn:hover {
            background: #35424a;
        }
        
        .btn-back, .btn-add-opinion {
            position: absolute;
            top: 20px;
            background-color: #e8491d;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
        }

        .btn-back:hover, .btn-add-opinion:hover {
            background-color: #35424a;
        }

        /* Botón Volver */
        .btn-back {
            left: 20px;
        }

        /* Botón Agregar Opinión */
        .btn-add-opinion {
            right: 20px;
        }

        /* Sección de filtros y búsqueda */
        .filters {
            display: flex;
            justify-content: flex-start;
            align-items: center;
            margin-bottom: 20px;
        }
        .filters input {
            padding: 10px;
            font-size: 16px;
            width: 70%;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        .filters button {
            padding: 10px 20px;
            background-color: #e8491d;
            color: white;
            font-size: 16px;
            border-radius: 5px;
            cursor: pointer;
            margin-left: 10px;
        }
        /* Paginación */
        .pagination {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }
        .pagination a {
            margin: 0 5px;
            padding: 10px 20px;
            background-color: #e8491d;
            color: white;
            border-radius: 5px;
            text-decoration: none;
        }
        .pagination a:hover {
            background-color: #35424a;
        }
        .pagination .active {
            background-color: #35424a;
            cursor: default;
        }
    </style>
</head>
<body>
    <header>
        <h1>Foro de Opiniones</h1>
        <div class="logo-container">
            <a href="dashboard_usuario.php">
                <img src="logod.png" alt="Logo">
            </a>
        </div>
        <a href="dashboard_usuario.php" class="btn-back">Volver</a>
        <a href="agregar_opinion.php" class="btn-add-opinion">Agregar Opinión</a>
    </header>

    <div class="container">
        <!-- Filtro y búsqueda -->
        <form method="POST" class="filters">
            <input type="text" name="filtro" placeholder="Buscar por receta..." value="<?php echo htmlspecialchars($filtro); ?>" />
            <button type="submit" name="buscar">Buscar</button>
        </form>

        <h2>Últimas Opiniones</h2>
        <?php foreach ($opiniones as $opinion): ?>
            <div class="opinion-card">
                <h3><?php echo htmlspecialchars($opinion['nombre_receta']); ?></h3>
                <p><strong><?php echo htmlspecialchars($opinion['nombre']); ?></strong> - <?php echo $opinion['fecha']; ?></p>
                <p><?php echo nl2br(htmlspecialchars($opinion['comentario'])); ?></p>
                <a href="ver_opinion.php?id=<?php echo $opinion['id_opinion']; ?>" class="btn">Leer más</a>
            </div>
        <?php endforeach; ?>

        <!-- Paginación -->
        <div class="pagination">
            <?php if ($pagina > 1): ?>
                <a href="?pagina=<?php echo $pagina - 1; ?>">Anterior</a>
            <?php endif; ?>

            <?php for ($i = 1; $i <= $totalPaginas; $i++): ?>
                <a href="?pagina=<?php echo $i; ?>" class="<?php echo ($i == $pagina) ? 'active' : ''; ?>"><?php echo $i; ?></a>
            <?php endfor; ?>

            <?php if ($pagina < $totalPaginas): ?>
                <a href="?pagina=<?php echo $pagina + 1; ?>">Siguiente</a>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>


<?php
session_start(); // Iniciar sesión

// Verificar si el usuario está logueado
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

class Database {
    private $host = 'localhost';
    private $db = 'recesur';
    private $user = 'root';
    private $pass = '';
    private $charset = 'utf8mb4';
    private $pdo;

    public function __construct() {
        $dsn = "mysql:host={$this->host};dbname={$this->db};charset={$this->charset}";
        try {
            $this->pdo = new PDO($dsn, $this->user, $this->pass);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die("Error de conexión: " . $e->getMessage());
        }
    }

    public function getConnection() {
        return $this->pdo;
    }
}

// Clase para gestionar la planificación de comidas
class PlanificacionComidas {
    private $db;

    public function __construct() {
        $this->db = (new Database())->getConnection();
    }

    // Añadir una planificación de comida
    public function anadirPlanificacion($user_id, $receta_id, $fecha, $hora) {
        $sql = "INSERT INTO planificacion_comida (id_usuario, id_receta, fecha, hora) 
                VALUES (:id_usuario, :id_receta, :fecha, :hora)";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':id_usuario', $user_id, PDO::PARAM_INT);
        $stmt->bindParam(':id_receta', $receta_id, PDO::PARAM_INT);
        $stmt->bindParam(':fecha', $fecha);
        $stmt->bindParam(':hora', $hora);
        return $stmt->execute();
    }

    // Obtener las recetas guardadas por el usuario
    public function obtenerRecetasGuardadas($user_id) {
        $sql = "SELECT r.id_receta, r.nombre_receta 
                FROM recetas r
                INNER JOIN planificacion p ON r.id_receta = p.id_receta
                WHERE p.id_usuario = :id_usuario"; 
        
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':id_usuario', $user_id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Obtener la planificación de comidas de un usuario
    public function obtenerPlanificaciones($user_id) {
        $sql = "SELECT pc.id_planificacion_comida, r.nombre_receta, pc.fecha, pc.hora
                FROM planificacion_comida pc
                INNER JOIN recetas r ON r.id_receta = pc.id_receta
                WHERE pc.id_usuario = :id_usuario
                ORDER BY pc.fecha, pc.hora";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':id_usuario', $user_id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Eliminar una planificación de comida
    public function eliminarPlanificacion($id_planificacion) {
        $sql = "DELETE FROM planificacion_comida WHERE id_planificacion_comida = :id_planificacion_comida";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':id_planificacion_comida', $id_planificacion, PDO::PARAM_INT);
        return $stmt->execute();
    }
}

// Obtener la información del usuario logueado
$user_id = $_SESSION['user_id'];

$planificacion = new PlanificacionComidas();
$resultado = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['anadir_planificacion'])) {
        $receta_id = $_POST['receta_id'];
        $fecha = $_POST['fecha'];
        $hora = $_POST['hora'];

        if ($planificacion->anadirPlanificacion($user_id, $receta_id, $fecha, $hora)) {
            $resultado = "Planificación añadida correctamente.";
        } else {
            $resultado = "Error al añadir planificación.";
        }
    } elseif (isset($_POST['eliminar_planificacion'])) {
        $id_planificacion = $_POST['id_planificacion'];

        if ($planificacion->eliminarPlanificacion($id_planificacion)) {
            $resultado = "Planificación eliminada correctamente.";
        } else {
            $resultado = "Error al eliminar planificación.";
        }
    }
}

// Obtener todas las planificaciones y recetas guardadas
$planificaciones = $planificacion->obtenerPlanificaciones($user_id);
$recetasGuardadas = $planificacion->obtenerRecetasGuardadas($user_id);

// Obtener el mes y año actuales
$mes_actual = isset($_GET['mes']) ? $_GET['mes'] : date("m");
$año_actual = isset($_GET['año']) ? $_GET['año'] : date("Y");

// Determinar el primer día del mes y el último
$primer_dia_del_mes = new DateTime("$año_actual-$mes_actual-01");
$ultimo_dia_del_mes = new DateTime("$año_actual-$mes_actual-01");
$ultimo_dia_del_mes->modify('last day of this month');

// Generar días del calendario
$dias_del_mes = [];
$fecha = clone $primer_dia_del_mes;
while ($fecha <= $ultimo_dia_del_mes) {
    $dias_del_mes[] = $fecha->format('Y-m-d');
    $fecha->modify('+1 day');
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Planificación de Comidas</title>
    
    <style>
        body {
    font-family: Arial, sans-serif;
    background-color: #f4f4f9;
    color: #333;
    line-height: 1.6;
    margin: 0;
    padding: 0;
}

.container {
    width: 85%;
    margin: 20px auto;
}

h1 {
    text-align: center;
    margin-bottom: 20px;
}

.formulario {
    background: #fff;
    padding: 20px;
    margin-bottom: 40px;
    border-radius: 8px;
    box-shadow: 0 0 12px rgba(0, 0, 0, 0.1);
}

.formulario label {
    font-weight: bold;
    display: block;
    margin-bottom: 8px;
}

.formulario input,
.formulario select {
    width: 100%;
    padding: 12px;
    margin-bottom: 20px;
    border-radius: 8px;
    border: 1px solid #ccc;
}

.formulario button {
    background-color: #35424a;
    color: white;
    padding: 12px 20px;
    border: none;
    cursor: pointer;
    border-radius: 8px;
    font-size: 16px;
}

.formulario button:hover {
    background-color: #e8491d;
}

.result {
    background-color: #dff0d8;
    padding: 15px;
    margin-bottom: 20px;
    text-align: center;
    border-radius: 5px;
    color: #3c763d;
}

.planificaciones {
    margin-bottom: 40px;
}

.planificacion-item {
    background: #fff;
    padding: 15px;
    margin-bottom: 10px;
    border-radius: 5px;
    box-shadow: 0 0 8px rgba(0, 0, 0, 0.1);
}

.calendar-navigation {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
}

.calendar-navigation select {
    padding: 8px;
    font-size: 16px;
    border-radius: 8px;
    border: 1px solid #ccc;
}

.calendar-title {
    font-size: 24px;
    font-weight: bold;
}

.calendar {
    display: grid;
    grid-template-columns: repeat(7, 1fr);
    gap: 10px;
}

.calendar div {
    text-align: center;
    padding: 15px;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0 0 8px rgba(0, 0, 0, 0.1);
}

.calendar div h3 {
    font-size: 18px;
    margin-bottom: 5px;
}

.event {
    background-color: #35424a;
    color: red;
    padding: 5px;
    margin-top: 5px;
    font-size: 12px;
    border-radius: 5px;
}
.btn-back {
            position: absolute;
            top: 20px;
            right: 20px;
            background-color: #e8491d;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
        }
        .btn-back:hover {
            background-color: #35424a;
        }

    </style>
</head>
<body>
    <div class="container">
        <h1>Planificación de Comidas</h1>
                <!-- Botón de Volver -->
                <a href="dashboard_usuario.php" class="btn-back">Volver</a>


        <?php if (!empty($resultado)): ?>
            <div class="result"><?php echo $resultado; ?></div>
        <?php endif; ?>

        <div class="formulario">
            <h2>Añadir Planificación</h2>
            <form method="POST">
                <label for="receta_id">Selecciona una Receta</label>
                <select name="receta_id" id="receta_id" required>
                    <?php foreach ($recetasGuardadas as $receta): ?>
                        <option value="<?php echo $receta['id_receta']; ?>"><?php echo $receta['nombre_receta']; ?></option>
                    <?php endforeach; ?>
                </select>

                <label for="fecha">Fecha</label>
                <input type="date" name="fecha" id="fecha" required>

                <label for="hora">Hora</label>
                <input type="time" name="hora" id="hora" required>

                <button type="submit" name="anadir_planificacion">Añadir Planificación</button>
            </form>
        </div>

        <div class="planificaciones">
            <h2>Planificaciones</h2>
            <?php foreach ($planificaciones as $plan): ?>
                <div class="planificacion-item">
                    <p>Fecha: <?php echo $plan['fecha']; ?>, Hora: <?php echo $plan['hora']; ?></p>
                    <p>Receta: <?php echo $plan['nombre_receta']; ?></p>
                    <form method="POST" style="display: inline;">
                        <input type="hidden" name="id_planificacion" value="<?php echo $plan['id_planificacion_comida']; ?>">
                        <button type="submit" name="eliminar_planificacion">Eliminar</button>
                    </form>
                </div>
            <?php endforeach; ?>
        </div>

        <!-- Calendario -->
        <div class="calendar-navigation">
            <form method="GET" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
                <select name="mes" onchange="this.form.submit()" class="calendar-select">
                    <?php 
                    // Meses en español
                    $meses_espanol = [
                        '01' => 'Enero', '02' => 'Febrero', '03' => 'Marzo', '04' => 'Abril',
                        '05' => 'Mayo', '06' => 'Junio', '07' => 'Julio', '08' => 'Agosto',
                        '09' => 'Septiembre', '10' => 'Octubre', '11' => 'Noviembre', '12' => 'Diciembre'
                    ];

                    // Mostrar el selector de meses
                    for ($i = 1; $i <= 12; $i++) {
                        $mes_value = str_pad($i, 2, "0", STR_PAD_LEFT);
                        $selected = $mes_value == $mes_actual ? 'selected' : '';
                        echo "<option value='$mes_value' $selected>{$meses_espanol[$mes_value]}</option>";
                    }
                    ?>
                </select>

                <select name="año" onchange="this.form.submit()" class="calendar-select">
                    <?php 
                    // Mostrar el selector de años
                    for ($i = date("Y") - 5; $i <= date("Y") + 5; $i++) {
                        $selected = $i == $año_actual ? 'selected' : '';
                        echo "<option value='$i' $selected>$i</option>";
                    }
                    ?>
                </select>
            </form>

            <h2 class="calendar-title"><?php echo $meses_espanol[$mes_actual] . " " . $año_actual; ?></h2>
        </div>

        <div class="calendar">
            <?php 
            $dias_semana = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];

            // Mostrar encabezado de los días de la semana
            foreach ($dias_semana as $dia) {
                echo "<div><h3>$dia</h3></div>";
            }

            // Mostrar los días del mes
            foreach ($dias_del_mes as $dia) {
                $eventos_del_dia = [];
                
                // Filtrar las planificaciones de comidas para ese día
                foreach ($planificaciones as $plan) {
                    if ($plan['fecha'] == $dia) {
                        $eventos_del_dia[] = $plan;
                    }
                }

                echo "<div class='calendar-day'>";
                echo "<h3>" . date('d', strtotime($dia)) . "</h3>";

                // Si hay eventos para ese día, mostrarlos
                if (!empty($eventos_del_dia)) {
                    foreach ($eventos_del_dia as $evento) {
                        echo "<div class='event'>{$evento['nombre_receta']} a las {$evento['hora']}</div>";
                    }
                } 

                echo "</div>";
            }
            ?>
        </div>
    </div>
</body>
</html>

<?php
session_start();

// Verificar si el usuario está logueado, si no, redirigir al login
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_nombre']) || !isset($_SESSION['user_email'])) {
    header("Location: login.php");
    exit;
}

// Incluir la clase Database
class Database {
    private $host = 'localhost';
    private $db = 'recesur';
    private $user = 'root';
    private $pass = '';
    private $charset = 'utf8mb4';
    private $pdo;

    public function __construct() {
        $dsn = "mysql:host={$this->host};dbname={$this->db};charset={$this->charset}";
        try {
            $this->pdo = new PDO($dsn, $this->user, $this->pass);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die("Error de conexión: " . $e->getMessage());
        }
    }

    public function getConnection() {
        return $this->pdo;
    }
}
$mensaje = ''; // Inicializar la variable para evitar errores de "Undefined variable"


// Clase Usuario
class Usuario {
    private $pdo;
    private $user_id;

    public function __construct($pdo, $user_id) {
        $this->pdo = $pdo;
        $this->user_id = $user_id;
    }

    public function getNombre() {
        $query = "SELECT nombre FROM usuarios WHERE id_usuario = :user_id";
        $stmt = $this->pdo->prepare($query);
        $stmt->bindParam(':user_id', $this->user_id, PDO::PARAM_INT);
        $stmt->execute();
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
        return $usuario ? $usuario['nombre'] : null;
    }

    public function getPreferenciasDietas() {
        $query = "SELECT preferencias_dietas FROM usuarios WHERE id_usuario = :user_id";
        $stmt = $this->pdo->prepare($query);
        $stmt->bindParam(':user_id', $this->user_id, PDO::PARAM_INT);
        $stmt->execute();
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
        return $usuario ? $usuario['preferencias_dietas'] : 'normal';
    }
}

// Clase Receta
class Receta {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    public function obtenerRecetasGuardadas($user_id, $dieta = null) {
        $query = "SELECT r.id_receta, r.nombre_receta, r.descripcion, r.tipo_comida, r.dieta 
                  FROM recetas r 
                  INNER JOIN planificacion p ON r.id_receta = p.id_receta 
                  WHERE p.id_usuario = :user_id";

        // Agregar filtro por dieta si está definido
        if ($dieta) {
            $query .= " AND r.dieta = :dieta";
        }

        $stmt = $this->pdo->prepare($query);
        $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        if ($dieta) {
            $stmt->bindParam(':dieta', $dieta, PDO::PARAM_STR);
        }
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function obtenerIngredientes($receta_id) {
        $query = "SELECT i.id_ingrediente, i.nombre_ingrediente, ri.cantidad 
                  FROM ingredientes i 
                  JOIN receta_ingredientes ri ON i.id_ingrediente = ri.id_ingrediente
                  WHERE ri.id_receta = :receta_id";
        $stmt = $this->pdo->prepare($query);
        $stmt->bindParam(':receta_id', $receta_id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function guardarListaDeCompras($user_id, $receta_id, $ingredientesSeleccionados) {
        foreach ($ingredientesSeleccionados as $ingrediente) {
            $query = "INSERT INTO lista_compras (id_usuario, id_receta, id_ingrediente, cantidad, estado) 
                      VALUES (:id_usuario, :id_receta, :id_ingrediente, :cantidad, 'pendiente')";
            $stmt = $this->pdo->prepare($query);
            $stmt->bindParam(':id_usuario', $user_id, PDO::PARAM_INT);
            $stmt->bindParam(':id_receta', $receta_id, PDO::PARAM_INT);
            $stmt->bindParam(':id_ingrediente', $ingrediente['id_ingrediente'], PDO::PARAM_INT);
            $stmt->bindParam(':cantidad', $ingrediente['cantidad'], PDO::PARAM_STR);
            $stmt->execute();
        }
    }
}

// Crear la conexión a la base de datos
$database = new Database();
$pdo = $database->getConnection();

// Obtener el ID del usuario logueado
$user_id = $_SESSION['user_id'];

// Crear instancia del objeto Usuario
$usuario = new Usuario($pdo, $user_id);
$nombreUsuario = $usuario->getNombre();
$preferenciasDietas = $usuario->getPreferenciasDietas();

// Crear instancia del objeto Receta
$receta = new Receta($pdo);

// Filtro de búsqueda según dieta
$dietaSeleccionada = $_GET['dieta'] ?? $preferenciasDietas;

// Obtener las recetas guardadas con el filtro aplicado
$recetas_guardadas = $receta->obtenerRecetasGuardadas($user_id, $dietaSeleccionada);

// Procesar el formulario si se envían ingredientes seleccionados
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['guardar_compras'])) {
    if (isset($_POST['ingredientes'])) {  // Verificar si el array 'ingredientes' está definido
        $receta_id = $_POST['receta_id'];
        $ingredientesSeleccionados = [];
        foreach ($_POST['ingredientes'] as $ingrediente_id) {
            $cantidad = $_POST['cantidad_' . $ingrediente_id] ?? '';  // Obtener la cantidad ingresada, si la hay
            $ingredientesSeleccionados[] = [
                'id_ingrediente' => $ingrediente_id, 
                'cantidad' => $cantidad
            ];
        }
        $receta->guardarListaDeCompras($user_id, $receta_id, $ingredientesSeleccionados);
    }
}

// Procesar eliminación de recetas guardadas
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['eliminar_receta'])) {
    $receta_id = $_POST['receta_id'];
    $query = "DELETE FROM planificacion WHERE id_usuario = :user_id AND id_receta = :receta_id";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
    $stmt->bindParam(':receta_id', $receta_id, PDO::PARAM_INT);
    if ($stmt->execute()) {
        echo "<script>alert('Receta eliminada correctamente');</script>";
        echo "<script>window.location.href='recetas_guardadas.php';</script>";
        exit;
    } else {
        echo "<script>alert('Error al eliminar la receta');</script>";
    }
}

// Procesar el formulario si se envían ingredientes seleccionados
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['guardar_compras'])) {
    if (isset($_POST['ingredientes'])) {
        $receta_id = $_POST['receta_id'];
        $ingredientesSeleccionados = [];
        foreach ($_POST['ingredientes'] as $ingrediente_id) {
            $cantidad = $_POST['cantidad_' . $ingrediente_id] ?? '';
            $ingredientesSeleccionados[] = [
                'id_ingrediente' => $ingrediente_id,
                'cantidad' => $cantidad
            ];
        }
        $receta->guardarListaDeCompras($user_id, $receta_id, $ingredientesSeleccionados);
        $mensaje = "Ingredientes guardados exitosamente en su lista de compras.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recetas Guardadas</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        .btn-back {
            position: absolute;
            top: 20px;
            right: 20px;
            background-color: #e8491d;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
        }
        .container {
            width: 80%;
            margin: auto;
            overflow: hidden;
        }
        header {
            background: #35424a;
            color: white;
            padding: 20px 0;
            text-align: center;
        }
        header h1 {
            margin: 0;
            font-size: 24px;
        }
        .filter {
            margin: 20px 0;
            text-align: center;
        }
        .filter select {
            padding: 10px;
            font-size: 16px;
            border-radius: 5px;
            border: 1px solid #ddd;
        }
        ul {
            list-style: none;
            padding: 0;
        }
        ul li {
            background: #ffffff;
            margin: 10px 0;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .logo-container {
            margin-top: 10px;
        }
        .logo-container img {
            width: 150px;
            height: auto;
        }
        input[type="text"][name^="cantidad_"] {
            width: 80px;
            padding: 8px;
            font-size: 14px;
            margin-left: 5px;
            border: 1px solid #ddd;
            border-radius: 5px;
            transition: border-color 0.3s, box-shadow 0.3s;
        }
        input[type="text"][name^="cantidad_"]:focus {
            border-color: #e8491d;
            box-shadow: 0 0 5px rgba(232, 73, 29, 0.5);
            outline: none;
        }
        button[name="guardar_compras"] {
            background-color: #35424a;
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            width: 100%;
            margin-top: 15px;
            transition: background-color 0.3s;
        }
        button[name="guardar_compras"]:hover {
            background-color: #e8491d;
        }
        form button[type="submit"] {
            background: none;
            border: none;
            color: red;
            font-size: 18px;
            cursor: pointer;
        }
        form button[type="submit"]:hover {
            color: darkred;
        }
        .notification {
            background-color: #d4edda;
            color: #155724;
            padding: 10px;
            margin: 20px auto;
            border: 1px solid #c3e6cb;
            border-radius: 5px;
            text-align: center;
            font-size: 16px;
            display: none;
        }
        .notification.show {
            display: block;
        }
        .btn-back {
            position: absolute;
            top: 20px;
            right: 20px;
            background-color: #e8491d;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
        }
        .btn-back:hover {
            background-color: #35424a;
        }
    </style>
</head>
<body>
    
    <header>
        
        <h1>Recetas Guardadas de <?php echo htmlspecialchars($nombreUsuario); ?></h1>
                <!-- Botón de Volver -->
                <a href="dashboard_usuario.php" class="btn-back">Volver</a>

        <div class="logo-container">
            <a href="dashboard_usuario.php">
                <img src="logod.png" alt="Logo">
            </a>
        </div>
    </header>

    <div class="container">
        <?php if ($mensaje): ?>
            <div id="notification" class="notification show">
                <?php echo htmlspecialchars($mensaje); ?>
            </div>
        <?php endif; ?>

        <div class="filter">
            <form method="GET">
                <label for="dieta">Filtrar por dieta:</label>
                <select name="dieta" id="dieta" onchange="this.form.submit()">
                    <option value="normal" <?php echo $dietaSeleccionada === 'normal' ? 'selected' : ''; ?>>Normal</option>
                    <option value="sin_gluten" <?php echo $dietaSeleccionada === 'sin_gluten' ? 'selected' : ''; ?>>Sin Gluten</option>
                    <option value="vegetariano" <?php echo $dietaSeleccionada === 'vegetariano' ? 'selected' : ''; ?>>Vegetariano</option>
                    <option value="vegano" <?php echo $dietaSeleccionada === 'vegano' ? 'selected' : ''; ?>>Vegano</option>
                </select>
            </form>
        </div>

        <h2>Recetas que has guardado:</h2>
        <?php if ($recetas_guardadas): ?>
            <ul>
                <?php foreach ($recetas_guardadas as $receta_guardada): ?>
                    <li>
                        <strong><?php echo htmlspecialchars($receta_guardada['nombre_receta']); ?></strong> - <?php echo htmlspecialchars($receta_guardada['descripcion']); ?>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="receta_id" value="<?php echo $receta_guardada['id_receta']; ?>">
                            <button type="submit" name="eliminar_receta">&#10006;</button>
                        </form>

                        <form method="POST">
                            <input type="hidden" name="receta_id" value="<?php echo $receta_guardada['id_receta']; ?>">
                            <h4>Selecciona los ingredientes para tu lista de compras:</h4>
                            <?php
                            $ingredientes = $receta->obtenerIngredientes($receta_guardada['id_receta']);
                            foreach ($ingredientes as $ingrediente):
                            ?>
                                <label>
                                    <input type="checkbox" name="ingredientes[]" value="<?php echo $ingrediente['id_ingrediente']; ?>">
                                    <?php echo htmlspecialchars($ingrediente['nombre_ingrediente']); ?> - <?php echo htmlspecialchars($ingrediente['cantidad']); ?>
                                    <input type="text" name="cantidad_<?php echo $ingrediente['id_ingrediente']; ?>" placeholder="Cantidad" />
                                </label><br>
                            <?php endforeach; ?>
                            <button type="submit" name="guardar_compras">Guardar Lista de Compras</button>
                        </form>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php else: ?>
            <p>No tienes recetas guardadas.</p>
        <?php endif; ?>
    </div>
</body>
</html>

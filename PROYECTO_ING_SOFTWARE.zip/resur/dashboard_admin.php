<?php
session_start();

// Verificar si el usuario está logueado, si no, redirigir al login
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_nombre']) || !isset($_SESSION['user_email'])) {
    header("Location: login.php");
    exit;
}

// Definir clase Administrador
class Administrador {
    private $nombre;

    public function __construct($nombre) {
        $this->nombre = $nombre;
    }

    public function getNombre() {
        return htmlspecialchars($this->nombre, ENT_QUOTES, 'UTF-8');
    }
}

// Crear un objeto Administrador a partir de los datos de la sesión
$admin = new Administrador($_SESSION['user_nombre']);

// Manejo de acciones enviadas por el usuario
$accion = isset($_POST['accion']) ? $_POST['accion'] : null;
$resultado = "";

if ($accion) {
    switch ($accion) {
        case 'anadir_receta':
            $resultado = '
                <form method="POST" action="procesar_receta.php" class="formulario">
                    <label>Nombre de la Receta: <input type="text" name="nombre_receta" required></label><br>
                    <label>Descripción: <textarea name="descripcion" required></textarea></label><br>
                    <label>Tiempo de Preparación (minutos): <input type="number" name="tiempo_preparacion" required></label><br>
                    <label>Tipo de Comida:
                        <select name="tipo_comida" required>
                            <option value="desayuno">Desayuno</option>
                            <option value="almuerzo">Almuerzo</option>
                            <option value="cena">Cena</option>
                            <option value="snack">Snack</option>
                        </select>
                    </label><br>
                    <label>Dieta:
                        <select name="dieta" required>
                            <option value="sin_gluten">Sin Gluten</option>
                            <option value="vegetariano">Vegetariano</option>
                            <option value="vegano">Vegano</option>
                            <option value="normal">Normal</option>
                        </select>
                    </label><br>
                    <label>Instrucciones: <textarea name="instrucciones" required></textarea></label><br>
                    <button class="btn bubbly-button" type="submit">Añadir Receta</button>
                </form>';
            break;
        case 'cerrar_sesion':
            session_destroy();
            header("Location: login.php");
            exit;
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Administrador</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        header {
            background: #35424a;
            color: #ffffff;
            padding: 20px 0;
            text-align: center;
        }
        header h1 {
            margin: 0;
            font-size: 24px;
        }
        .container {
            width: 80%;
            margin: auto;
            overflow: hidden;
            padding-top: 20px;
        }
        .menu {
            display: flex;
            justify-content: space-around;
            margin: 20px 0;
        }
        .menu button {
            padding: 10px 20px;
            font-size: 16px;
            background-color: #35424a;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }
        .menu button:hover {
            background-color: #e8491d;
        }
        .formulario {
            background: #ffffff;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            padding: 20px;
            max-width: 600px;
            margin: auto;
            text-align: left;
        }
        .formulario label {
            display: block;
            margin: 10px 0 5px;
            font-size: 14px;
            font-weight: bold;
            color: #333;
        }
        .formulario input[type="text"], 
        .formulario input[type="number"], 
        .formulario textarea, 
        .formulario select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
        }
        .formulario textarea {
            resize: vertical;
        }
        .formulario button {
            display: block;
            width: 100%;
            padding: 10px;
            background-color: #e8491d;
            color: #ffffff;
            border: none;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        .formulario button:hover {
            background-color: #35424a;
        }
    </style>
</head>
<body>
    <header>
        <h1>Bienvenido/a, <?php echo $admin->getNombre(); ?> (Administrador)</h1>
    </header>
    <div class="container">
    <div class="menu">
    
        <!-- Redirige directamente a anadir_receta.php -->
        <form method="GET" action="anadir_receta.php">
            <button type="submit">Añadir Receta</button>
        </form>
        
        <!-- Redirige a editar_receta.php (Aquí debes manejar la receta que quieres editar) -->
        <form method="GET" action="editar_recetas.php">
            <button type="submit">Editar Receta</button>
        </form>

        <form method="GET" action="eliminar_receta.php">
            <button type="submit">Eliminar Receta</button>
        </form>

        <form method="GET" action="consultar_usuarios.php">
            <button type="submit">Consultar datos de usuario</button>
        </form>
        
        <!-- Nuevo botón para ver los reportes -->
        <form method="GET" action="ver_reportes.php">
            <button type="submit">Ver Reportes</button>
        </form>

        <!-- Permite cerrar sesión -->
        <form method="POST">
            <button type="submit" name="accion" value="cerrar_sesion">Cerrar Sesión</button>
        </form>
    </div>
    <?php if (isset($resultado) && $resultado): ?>
        <div class="result">
            <?php echo $resultado; ?>
        </div>
    <?php endif; ?>
</div>
</body>
</html>


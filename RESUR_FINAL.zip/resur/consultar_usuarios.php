<?php
session_start();

// Verificar si el usuario está logueado, si no, redirigir al login
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_nombre']) || !isset($_SESSION['user_email'])) {
    header("Location: login.php");
    exit;
}

// Clase para la conexión a la base de datos
class Conexion {
    private $host = "localhost";
    private $db = "recesur"; // Cambia a tu base de datos real
    private $user = "root"; // Ajusta el nombre de usuario si es necesario
    private $password = ""; // Ajusta la contraseña si es necesario
    private $conn;

    public function __construct() {
        try {
            $this->conn = new PDO("mysql:host=$this->host;dbname=$this->db", $this->user, $this->password);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die("Error de conexión: " . $e->getMessage());
        }
    }

    public function getConexion() {
        return $this->conn;
    }
}

// Clase para manejar usuarios
class Usuario {
    private $conexion;

    public function __construct($conexion) {
        $this->conexion = $conexion;
    }

    // Método para obtener usuarios con rol 'usuario' y sus datos adicionales
    public function obtenerUsuarios($buscar = '') {
        $sql = "
            SELECT 
                u.id_usuario, 
                u.nombre, 
                u.apellido_paterno, 
                u.apellido_materno, 
                u.email, 
                u.rol,
                d.rut,
                d.telefono,
                d.fecha_nacimiento,
                d.estado_cuenta,         
                u.contrasena
            FROM usuarios u
            LEFT JOIN datos_usuarios d ON u.id_usuario = d.id_usuario
            WHERE u.rol = 'usuario'  
        ";

        if ($buscar) {
            $sql .= " AND (u.nombre LIKE :buscar OR u.apellido_paterno LIKE :buscar OR u.apellido_materno LIKE :buscar)";
        }

        $stmt = $this->conexion->prepare($sql);
        
        if ($buscar) {
            $stmt->bindValue(':buscar', "%$buscar%");
        }

        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Método para cambiar el estado de la cuenta (activar o desactivar)
    public function cambiarEstadoCuenta($id_usuario, $estado) {
        $sql = "UPDATE datos_usuarios SET estado_cuenta = :estado WHERE id_usuario = :id_usuario";
        $stmt = $this->conexion->prepare($sql);
        $stmt->execute([':estado' => $estado, ':id_usuario' => $id_usuario]);
    }

    // Método para eliminar un usuario
    public function eliminarUsuario($id_usuario) {
        $sql = "DELETE FROM usuarios WHERE id_usuario = :id_usuario";
        $stmt = $this->conexion->prepare($sql);
        $stmt->execute([':id_usuario' => $id_usuario]);
    }
}

// Establecer conexión y crear instancia de Usuario
$conexion = new Conexion();
$usuario = new Usuario($conexion->getConexion());
$usuarios = $usuario->obtenerUsuarios(isset($_POST['buscar']) ? $_POST['buscar'] : '');

// Cambiar el estado de la cuenta (activar o desactivar)
if (isset($_POST['accion']) && isset($_POST['id_usuario'])) {
    $id_usuario = $_POST['id_usuario'];
    if ($_POST['accion'] == 'activar') {
        $usuario->cambiarEstadoCuenta($id_usuario, 'activa');
    } elseif ($_POST['accion'] == 'desactivar') {
        $usuario->cambiarEstadoCuenta($id_usuario, 'desactivada');
    } elseif ($_POST['accion'] == 'eliminar') {
        $usuario->eliminarUsuario($id_usuario);
    }
    header("Location: ".$_SERVER['PHP_SELF']);
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Control de Usuarios</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        header {
            background: #35424a;
            color: #ffffff;
            padding: 20px 0;
            text-align: center;
        }
        header h1 {
            margin: 0;
            font-size: 24px;
        }
        .container {
            width: 80%;
            margin: auto;
            overflow: hidden;
            padding-top: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table th, table td {
            padding: 10px;
            text-align: left;
            border: 1px solid #ddd;
        }
        table th {
            background-color: #35424a;
            color: white;
        }
        table tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        .btn {
            display: inline-block;
            padding: 8px 16px;
            font-size: 14px;
            background-color: #e8491d;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            text-align: center;
        }
        .btn:hover {
            background-color: #35424a;
        }
        .action-btns {
            display: flex;
            justify-content: space-around;
        }
        .action-btns form {
            display: inline;
        }
    </style>
    <script>
        // Confirmación antes de eliminar un usuario
        function confirmarEliminacion() {
            return confirm("¿Estás seguro de que deseas eliminar este usuario?");
        }

        // Alternar visibilidad de la contraseña
        function togglePasswordVisibility(id_usuario) {
            var contrasena = document.getElementById('contrasena_' + id_usuario);
            if (contrasena.style.display === 'none') {
                contrasena.style.display = 'inline';
            } else {
                contrasena.style.display = 'none';
            }
        }
    </script>
</head>
<body>
    <header>
        <h1>Gestión de Usuarios</h1>
    </header>
    <div class="container">
        <a href="dashboard_admin.php" class="btn">Volver al Menú</a>
        <a href="register.php" class="btn">Registrar Usuario</a>
        <h2>Lista de Usuarios</h2>
        
        <!-- Formulario de búsqueda -->
        <form method="POST" action="">
            <input type="text" name="buscar" placeholder="Buscar por nombre o apellido" value="<?php echo isset($_POST['buscar']) ? $_POST['buscar'] : ''; ?>">
            <button type="submit" class="btn">Buscar</button>
        </form>

        <table>
            <thead>
                <tr>
                    <th>ID Usuario</th>
                    <th>Nombre</th>
                    <th>Apellido Paterno</th>
                    <th>Apellido Materno</th>
                    <th>Email</th>
                    <th>RUT</th>
                    <th>Teléfono</th>
                    <th>Fecha de Nacimiento</th>
                    <th>Estado de Cuenta</th>
                    <th>Contraseña</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($usuarios) > 0): ?>
                    <?php foreach ($usuarios as $usuario): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($usuario['id_usuario']); ?></td>
                            <td><?php echo htmlspecialchars($usuario['nombre']); ?></td>
                            <td><?php echo htmlspecialchars($usuario['apellido_paterno']); ?></td>
                            <td><?php echo htmlspecialchars($usuario['apellido_materno']); ?></td>
                            <td><?php echo htmlspecialchars($usuario['email']); ?></td>
                            <td><?php echo htmlspecialchars($usuario['rut']); ?></td>
                            <td><?php echo htmlspecialchars($usuario['telefono']); ?></td>
                            <td><?php echo htmlspecialchars($usuario['fecha_nacimiento']); ?></td>
                            <td><?php echo htmlspecialchars($usuario['estado_cuenta']); ?></td>
                            <td>
                                <span id="contrasena_<?php echo $usuario['id_usuario']; ?>" style="display:none;">
                                    <?php echo htmlspecialchars($usuario['contrasena']); ?>
                                </span>
                                <button type="button" onclick="togglePasswordVisibility(<?php echo $usuario['id_usuario']; ?>)">👁️ Mostrar Contraseña</button>
                            </td>
                            <td class="action-btns">
                                <?php if ($usuario['estado_cuenta'] != 'desactivada'): ?>
                                        <form method="POST">
                                            <input type="hidden" name="id_usuario" value="<?php echo $usuario['id_usuario']; ?>">
                                            <input type="hidden" name="accion" value="desactivar">
                                            <button type="submit" class="btn">Desactivar</button>
                                        </form>
                                    <?php else: ?>
                                        <form method="POST">
                                            <input type="hidden" name="id_usuario" value="<?php echo $usuario['id_usuario']; ?>">
                                            <input type="hidden" name="accion" value="activar">
                                            <button type="submit" class="btn">Activar</button>
                                        </form>
                                    <?php endif; ?>
                                <!-- Eliminar -->
                                <form method="POST" onsubmit="return confirmarEliminacion()">
                                    <input type="hidden" name="accion" value="eliminar">
                                    <input type="hidden" name="id_usuario" value="<?php echo $usuario['id_usuario']; ?>">
                                    <button type="submit" class="btn">Eliminar</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="12">No se encontraron usuarios.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>

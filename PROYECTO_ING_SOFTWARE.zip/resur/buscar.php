<?php
session_start();

// Verificar si el usuario está logueado, si no, redirigir al login
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_nombre']) || !isset($_SESSION['user_email'])) {
    header("Location: login.php");
    exit;
}

// Clase para la conexión a la base de datos
class Database {
    private $host = 'localhost';
    private $db = 'recesur'; // Cambiado a recesur
    private $user = 'root';
    private $pass = '';
    private $charset = 'utf8mb4';
    private $pdo;

    public function __construct() {
        $dsn = "mysql:host={$this->host};dbname={$this->db};charset={$this->charset}";
        try {
            $this->pdo = new PDO($dsn, $this->user, $this->pass);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die("Error de conexión: " . $e->getMessage());
        }
    }

    public function getConnection() {
        return $this->pdo;
    }
}

// Clase Receta para gestionar la búsqueda de recetas
class Receta {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    public function buscarRecetasPorIngrediente($ingrediente) {
        // Consulta para buscar recetas por ingredientes
        $query = "SELECT r.id_receta, r.nombre_receta, r.descripcion, r.tipo_comida, r.dieta
                  FROM recetas r
                  INNER JOIN receta_ingredientes ri ON r.id_receta = ri.id_receta
                  INNER JOIN ingredientes i ON ri.id_ingrediente = i.id_ingrediente
                  WHERE i.nombre_ingrediente LIKE :ingrediente";
        $stmt = $this->pdo->prepare($query);
        $stmt->bindValue(':ingrediente', '%' . $ingrediente . '%', PDO::PARAM_STR);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

// Crear la conexión a la base de datos
$database = new Database();
$pdo = $database->getConnection();

// Obtener el ingrediente ingresado por el usuario
$busqueda = isset($_POST['busqueda']) ? $_POST['busqueda'] : '';
$recetas_encontradas = [];

if ($busqueda) {
    // Crear una instancia de la clase Receta y buscar recetas
    $receta = new Receta($pdo);
    $recetas_encontradas = $receta->buscarRecetasPorIngrediente($busqueda);
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buscar Receta</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 80%;
            margin: auto;
            overflow: hidden;
        }
        header {
            background: #35424a;
            color: white;
            padding: 20px 0;
            text-align: center;
        }
        header h1 {
            margin: 0;
            font-size: 24px;
        }
        .menu {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            margin: 20px 0;
        }
        .menu button {
            margin: 10px;
            padding: 10px 20px;
            font-size: 16px;
            background-color: #35424a;
            color: white;
            border: none;
            cursor: pointer;
        }
        .menu button:hover {
            background-color: #e8491d;
        }
        .result {
            margin: 20px 0;
            text-align: center;
            font-size: 18px;
            color: #333;
        }
        .logout {
            text-align: center;
            margin-top: 20px;
        }
        .btn.bubbly-button {
            background-color: #e8491d;
            color: white;
            border: none;
            padding: 10px 20px;
            font-size: 16px;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        .btn.bubbly-button:hover {
            background-color: #35424a;
        }
        .btn-back {
            position: absolute;
            top: 20px;
            right: 20px;
            background-color: #e8491d;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
        }
        .btn-back:hover {
            background-color: #35424a;
        }
        .logo-container {
            margin-top: 10px;
        }
        .logo-container img {
            width: 150px; /* Ajusta el tamaño del logo según tus necesidades */
            height: auto;
        }
    </style>
</head>
<body>
    <header>
        <h1>Buscar Recetas por Ingrediente</h1>
                <!-- Botón de Volver -->
                <a href="dashboard_usuario.php" class="btn-back">Volver</a>
                <div class="logo-container">
            <a href="dashboard_usuario.php">
                <img src="logod.png" alt="Logo">
            </a>
        </div>
    </header>
    <div class="container">
        <form method="POST" action="buscar.php">
            <label>Buscar Receta por Ingrediente: <input type="text" name="busqueda" value="<?php echo htmlspecialchars($busqueda); ?>"></label>
            <button type="submit">Buscar</button>
        </form>

        <?php if ($recetas_encontradas): ?>
            <h2>Resultados de la Búsqueda:</h2>
            <ul>
                <?php foreach ($recetas_encontradas as $receta): ?>
                    <li>
                        <strong><?php echo htmlspecialchars($receta['nombre_receta']); ?></strong> - <?php echo htmlspecialchars($receta['descripcion']); ?>
                        <br>
                        Tipo de comida: <?php echo htmlspecialchars($receta['tipo_comida']); ?>
                        <br>
                        Dieta: <?php echo htmlspecialchars($receta['dieta']); ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php elseif ($busqueda): ?>
            <p>No se encontraron recetas que coincidan con el ingrediente "<?php echo htmlspecialchars($busqueda); ?>".</p>
        <?php endif; ?>
    </div>
</body>
</html>

<?php
session_start();

// Verificar si el usuario está logueado, si no, redirigir al login
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_nombre']) || !isset($_SESSION['user_email'])) {
    header("Location: login.php");
    exit;
}

// Clase para la conexión a la base de datos
class Database {
    private $host = 'localhost';
    private $db = 'recesur';
    private $user = 'root';
    private $pass = '';
    private $charset = 'utf8mb4';
    private $pdo;

    public function __construct() {
        $dsn = "mysql:host={$this->host};dbname={$this->db};charset={$this->charset}";
        try {
            $this->pdo = new PDO($dsn, $this->user, $this->pass);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die("Error de conexión: " . $e->getMessage());
        }
    }

    public function getConnection() {
        return $this->pdo;
    }
}

// Clase Receta para gestionar las recetas
class Receta {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    // Obtener los detalles de una receta por ID
    public function obtenerRecetaPorId($id_receta) {
        $query = "SELECT id_receta, nombre_receta, descripcion, tipo_comida, dieta, instrucciones 
                  FROM recetas WHERE id_receta = :id_receta";
        $stmt = $this->pdo->prepare($query);
        $stmt->bindParam(':id_receta', $id_receta, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Obtener los ingredientes de una receta por ID
    public function obtenerIngredientes($id_receta) {
        $query = "SELECT i.nombre_ingrediente, ri.cantidad 
                  FROM receta_ingredientes ri 
                  JOIN ingredientes i ON ri.id_ingrediente = i.id_ingrediente
                  WHERE ri.id_receta = :id_receta";
        $stmt = $this->pdo->prepare($query);
        $stmt->bindParam(':id_receta', $id_receta, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

// Crear la conexión a la base de datos
$database = new Database();
$pdo = $database->getConnection();

// Obtener el ID de la receta desde la URL
$id_receta = $_GET['id'] ?? null;
if (!$id_receta) {
    echo "ID de receta no válido.";
    exit;
}

// Crear instancia de la clase Receta
$receta = new Receta($pdo);

// Obtener los detalles de la receta
$receta_detalles = $receta->obtenerRecetaPorId($id_receta);

// Obtener los ingredientes de la receta
$ingredientes = $receta->obtenerIngredientes($id_receta);

// Verificar si la receta existe
if (!$receta_detalles) {
    echo "Receta no encontrada.";
    exit;
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalles de la Receta</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        header {
            background: #35424a;
            color: white;
            padding: 20px;
            text-align: center;
        }
        header h1 {
            margin: 0;
            font-size: 24px;
        }
        .btn-back {
            position: absolute;
            top: 20px;
            right: 20px;
            background-color: #e8491d;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
        }
        .btn-back:hover {
            background-color: #35424a;
        }
        .container {
            width: 80%;
            margin: 20px auto;
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        h2 {
            color: #35424a;
        }
        .ingredients-list {
            margin-top: 20px;
            list-style-type: none;
            padding: 0;
        }
        .ingredients-list li {
            margin: 5px 0;
        }
        .instructions {
            margin-top: 20px;
            font-size: 16px;
            color: #555;
        }
    </style>
</head>
<body>
    <header>
        <h1>Detalles de la Receta: <?php echo htmlspecialchars($receta_detalles['nombre_receta']); ?></h1>
        <a href="dashboard_usuario.php" class="btn-back">Volver</a>
    </header>

    <div class="container">
        <h2>Descripción:</h2>
        <p><?php echo nl2br(htmlspecialchars($receta_detalles['descripcion'])); ?></p>

        <h3>Ingredientes:</h3>
        <ul class="ingredients-list">
            <?php foreach ($ingredientes as $ingrediente): ?>
                <li><?php echo htmlspecialchars($ingrediente['nombre_ingrediente']); ?> - <?php echo htmlspecialchars($ingrediente['cantidad']); ?></li>
            <?php endforeach; ?>
        </ul>

        <h3>Instrucciones:</h3>
        <p class="instructions"><?php echo nl2br(htmlspecialchars($receta_detalles['instrucciones'])); ?></p>
    </div>

</body>
</html>

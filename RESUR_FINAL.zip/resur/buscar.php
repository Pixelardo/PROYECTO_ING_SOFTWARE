<?php
session_start();

// Verificar si el usuario está logueado, si no, redirigir al login
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_nombre']) || !isset($_SESSION['user_email'])) {
    header("Location: login.php");
    exit;
}

// Clase para la conexión a la base de datos
class Database {
    private $host = 'localhost';
    private $db = 'recesur'; // Cambiado a recesur
    private $user = 'root';
    private $pass = '';
    private $charset = 'utf8mb4';
    private $pdo;

    public function __construct() {
        $dsn = "mysql:host={$this->host};dbname={$this->db};charset={$this->charset}";
        try {
            $this->pdo = new PDO($dsn, $this->user, $this->pass);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die("Error de conexión: " . $e->getMessage());
        }
    }

    public function getConnection() {
        return $this->pdo;
    }
}

// Clase Receta para gestionar la búsqueda de recetas
class Receta {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    public function buscarRecetasPorIngrediente($ingrediente) {
        // Consulta para buscar recetas por ingredientes
        $query = "SELECT r.id_receta, r.nombre_receta, r.descripcion, r.tipo_comida, r.dieta
                  FROM recetas r
                  INNER JOIN receta_ingredientes ri ON r.id_receta = ri.id_receta
                  INNER JOIN ingredientes i ON ri.id_ingrediente = i.id_ingrediente
                  WHERE i.nombre_ingrediente LIKE :ingrediente";
        $stmt = $this->pdo->prepare($query);
        $stmt->bindValue(':ingrediente', '%' . $ingrediente . '%', PDO::PARAM_STR);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
}

// Crear la conexión a la base de datos
$database = new Database();
$pdo = $database->getConnection();

// Obtener el ingrediente ingresado por el usuario
$busqueda = isset($_POST['busqueda']) ? $_POST['busqueda'] : '';
$recetas_encontradas = [];

if ($busqueda) {
    // Crear una instancia de la clase Receta y buscar recetas
    $receta = new Receta($pdo);
    $recetas_encontradas = $receta->buscarRecetasPorIngrediente($busqueda);
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Buscar Receta</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }

        /* Estilo del header */
        header {
            background: #35424a;
            color: white;
            padding: 20px 0;
            text-align: center;
            position: relative;
        }

        header h1 {
            margin: 0;
            font-size: 24px;
        }

        .btn-back {
            position: absolute;
            top: 20px;
            right: 20px;
            background-color: #e8491d;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
        }

        .btn-back:hover {
            background-color: #35424a;
        }

        .logo-container {
            margin-top: 10px;
        }

        .logo-container img {
            width: 150px; /* Ajusta el tamaño del logo según tus necesidades */
            height: auto;
        }

        /* Contenedor principal */
        .container {
            width: 80%;
            margin: auto;
            padding: 20px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
        }

        /* Estilo del formulario de búsqueda */
        form {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            align-items: center;
            gap: 10px;
            margin-bottom: 20px;
        }

        form input[type="text"] {
            padding: 10px;
            font-size: 16px;
            width: 60%;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        form button {
            padding: 10px 20px;
            background-color: #35424a;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        form button:hover {
            background-color: #e8491d;
        }

        /* Resultados de búsqueda */
        h2 {
            text-align: center;
            color: #35424a;
            margin-bottom: 20px;
        }

        ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        ul li {
            background: #f9f9f9;
            padding: 15px;
            margin-bottom: 10px;
            border-radius: 5px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        ul li strong {
            color: #35424a;
            font-size: 18px;
        }

        ul li p {
            margin: 5px 0;
            color: #666;
            font-size: 14px;
        }

        /* Mensaje de retroalimentación */
        .feedback {
            text-align: center;
            padding: 15px;
            margin-top: 20px;
            border-radius: 5px;
        }

        .feedback.exito {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .feedback.error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
    </style>
</head>
<body>
    <header>
        <h1>Buscar Recetas por Ingrediente</h1>
        <a href="dashboard_usuario.php" class="btn-back">Volver</a>
        <div class="logo-container">
            <a href="dashboard_usuario.php">
                <img src="logod.png" alt="Logo">
            </a>
        </div>
    </header>
    <div class="container">
        <form method="POST" action="buscar.php">
            <input type="text" name="busqueda" placeholder="Ingrese un ingrediente..." value="<?php echo htmlspecialchars($busqueda); ?>">
            <button type="submit">Buscar</button>
        </form>

        <?php if ($recetas_encontradas): ?>
            <h2>Resultados de la Búsqueda</h2>
            <ul>
                <?php foreach ($recetas_encontradas as $receta): ?>
                    <li>
                        <strong><?php echo htmlspecialchars($receta['nombre_receta']); ?></strong>
                        <p><?php echo htmlspecialchars($receta['descripcion']); ?></p>
                        <p><strong>Tipo de comida:</strong> <?php echo htmlspecialchars($receta['tipo_comida']); ?></p>
                        <p><strong>Dieta:</strong> <?php echo htmlspecialchars($receta['dieta']); ?></p>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php elseif ($busqueda): ?>
            <div class="feedback error">
                No se encontraron recetas que coincidan con el ingrediente "<?php echo htmlspecialchars($busqueda); ?>".
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
<?php
session_start();

// Verificar si el usuario está logueado, si no, redirigir al login
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_nombre']) || !isset($_SESSION['user_email'])) {
    header("Location: login.php");
    exit;
}

// Incluir la clase Database
class Database {
    private $host = 'localhost';
    private $db = 'recesur';
    private $user = 'root';
    private $pass = '';
    private $charset = 'utf8mb4';
    private $pdo;

    public function __construct() {
        $dsn = "mysql:host={$this->host};dbname={$this->db};charset={$this->charset}";
        try {
            $this->pdo = new PDO($dsn, $this->user, $this->pass);
            $this->pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) {
            die("Error de conexión: " . $e->getMessage());
        }
    }

    public function getConnection() {
        return $this->pdo;
    }
}

// Clase Usuario
class Usuario {
    private $pdo;
    private $user_id;

    public function __construct($pdo, $user_id) {
        $this->pdo = $pdo;
        $this->user_id = $user_id;
    }

    public function getNombre() {
        $query = "SELECT nombre FROM usuarios WHERE id_usuario = :user_id";
        $stmt = $this->pdo->prepare($query);
        $stmt->bindParam(':user_id', $this->user_id, PDO::PARAM_INT);
        $stmt->execute();
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
        return $usuario ? $usuario['nombre'] : null;
    }
}

// Clase Lista de Compras
class ListaCompras {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    // Obtener los ingredientes guardados en la lista de compras
    public function obtenerLista($user_id) {
        $query = "SELECT i.id_ingrediente, i.nombre_ingrediente, lc.cantidad, lc.estado
                  FROM lista_compras lc
                  JOIN ingredientes i ON lc.id_ingrediente = i.id_ingrediente
                  WHERE lc.id_usuario = :user_id AND lc.estado = 'pendiente'";
        $stmt = $this->pdo->prepare($query);
        $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Actualizar el estado de los ingredientes seleccionados
    public function actualizarEstado($user_id, $ingredientesSeleccionados) {
        foreach ($ingredientesSeleccionados as $ingrediente_id) {
            $query = "UPDATE lista_compras SET estado = 'comprado' WHERE id_usuario = :user_id AND id_ingrediente = :id_ingrediente";
            $stmt = $this->pdo->prepare($query);
            $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
            $stmt->bindParam(':id_ingrediente', $ingrediente_id, PDO::PARAM_INT);
            $stmt->execute();
        }
    }
}

// Crear la conexión a la base de datos
$database = new Database();
$pdo = $database->getConnection();

// Obtener el ID del usuario logueado
$user_id = $_SESSION['user_id'];

// Crear instancia del objeto Usuario
$usuario = new Usuario($pdo, $user_id);
$nombreUsuario = $usuario->getNombre();

// Crear instancia del objeto ListaCompras
$listaCompras = new ListaCompras($pdo);

// Inicializar variable de mensaje
$mensaje = "";

// Procesar el formulario si se envían ingredientes seleccionados
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['actualizar_estado'])) {
    if (isset($_POST['ingredientes_comprados'])) {  
        // Actualizar el estado de los ingredientes seleccionados
        $ingredientesSeleccionados = $_POST['ingredientes_comprados'];
        $listaCompras->actualizarEstado($user_id, $ingredientesSeleccionados);
        
        // Establecer mensaje de éxito
        $mensaje = "¡Ingredientes actualizados exitosamente!";
    }
}

// Obtener la lista de compras guardada
$ingredientes_lista = $listaCompras->obtenerLista($user_id);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Compras</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        .btn-back {
            position: absolute;
            top: 20px;
            right: 20px;
            background-color: #e8491d;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
        }
        .container {
            width: 80%;
            margin: auto;
            overflow: hidden;
        }
        header {
            background: #35424a;
            color: white;
            padding: 20px 0;
            text-align: center;
        }
        header h1 {
            margin: 0;
            font-size: 24px;
        }
        .ingredientes-lista {
            margin-top: 20px;
        }
        .ingredientes-lista label {
            margin-right: 10px;
        }
        .btn {
            background-color: #35424a;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
        }
        .btn:hover {
            background-color: #e8491d;
        }

        .ingredientes-lista {
    margin-top: 20px;
    padding-left: 20px;
}

.ingredientes-lista label {
    display: block;
    font-size: 16px;
    padding: 8px;
    margin-bottom: 10px;
    border: 1px solid #ddd;
    border-radius: 5px;
    background-color: #f9f9f9;
    transition: background-color 0.3s, border-color 0.3s;
}

.ingredientes-lista input[type="checkbox"] {
    margin-right: 10px;
}

.ingredientes-lista label:hover {
    background-color: #e8491d;
    border-color: #e8491d;
    color: white;
}
        .mensaje-exito {
            background-color: #4CAF50;
            color: white;
            padding: 10px;
            margin-bottom: 20px;
            text-align: center;
            border-radius: 5px;
        }
        .mensaje-error {
            background-color: #f44336;
            color: white;
            padding: 10px;
            margin-bottom: 20px;
            text-align: center;
            border-radius: 5px;
        }
        button[type="submit"] {
    background-color: #35424a;
    color: white;
    padding: 12px 20px;
    border: none;
    border-radius: 5px;
    cursor: pointer;
    width: 100%; /* Hace que el botón ocupe todo el ancho del contenedor */
    font-size: 16px;
    transition: background-color 0.3s;
    margin-top: 20px;
}

button[type="submit"]:hover {
    background-color: #e8491d;
}
        
    </style>
</head>
<body>
    <header>
        <h1>Lista de Compras de <?php echo htmlspecialchars($nombreUsuario); ?></h1>
        <a href="dashboard_usuario.php" class="btn-back">Volver</a>
    </header>
    <div class="container">
        <!-- Mostrar mensaje de éxito si está disponible -->
        <?php if ($mensaje): ?>
            <div class="mensaje-exito"><?php echo $mensaje; ?></div>
        <?php endif; ?>

        <form method="POST">
            <h3>Ingredientes guardados para comprar:</h3>
            <ul class="ingredientes-lista">
                <!-- Mostrar mensaje si no hay ingredientes en la lista -->
                <?php if (empty($ingredientes_lista)): ?>
                    <div class="mensaje-error">No hay ingredientes guardados para comprar.</div>
                <?php endif; ?>
                <?php foreach ($ingredientes_lista as $ingrediente): ?>
                    <li>
                        <label>
                            <input type="checkbox" name="ingredientes_comprados[]" value="<?php echo $ingrediente['id_ingrediente']; ?>">
                            <?php echo htmlspecialchars($ingrediente['nombre_ingrediente']); ?> - 
                            <?php echo htmlspecialchars($ingrediente['cantidad']); ?>
                        </label>
                    </li>
                <?php endforeach; ?>
            </ul>
            <button type="submit" name="actualizar_estado">Actualizar Estado</button>
        </form>
    </div>
</body>
</html>
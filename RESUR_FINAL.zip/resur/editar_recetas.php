<?php
session_start();
require_once 'includes/connection_db.php';

// Verificar si el usuario está logueado y tiene permisos de administrador
if (!isset($_SESSION['user_id']) || $_SESSION['user_tipo'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Conexión a la base de datos
class Recetas {
    private $pdo;

    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    // Obtener todas las recetas
    public function obtenerRecetas() {
        $query = "SELECT id_receta, nombre_receta FROM recetas";
        $stmt = $this->pdo->prepare($query);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Obtener receta por ID
    public function obtenerRecetaPorId($id_receta) {
        $query = "SELECT * FROM recetas WHERE id_receta = :id_receta";
        $stmt = $this->pdo->prepare($query);
        $stmt->bindParam(':id_receta', $id_receta, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Obtener ingredientes de una receta
    public function obtenerIngredientesPorId($id_receta) {
        $query = "SELECT ri.id_ingrediente, i.nombre_ingrediente, ri.cantidad 
                  FROM receta_ingredientes ri
                  JOIN ingredientes i ON ri.id_ingrediente = i.id_ingrediente
                  WHERE ri.id_receta = :id_receta";
        $stmt = $this->pdo->prepare($query);
        $stmt->bindParam(':id_receta', $id_receta, PDO::PARAM_INT);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Actualizar la receta
    public function actualizarReceta($id_receta, $nombre_receta, $descripcion, $tipo_comida, $dieta) {
        $query = "UPDATE recetas 
                  SET nombre_receta = :nombre_receta, descripcion = :descripcion, tipo_comida = :tipo_comida, dieta = :dieta
                  WHERE id_receta = :id_receta";
        $stmt = $this->pdo->prepare($query);
        $stmt->bindParam(':id_receta', $id_receta, PDO::PARAM_INT);
        $stmt->bindParam(':nombre_receta', $nombre_receta);
        $stmt->bindParam(':descripcion', $descripcion);
        $stmt->bindParam(':tipo_comida', $tipo_comida);
        $stmt->bindParam(':dieta', $dieta);
        return $stmt->execute();
    }

    // Actualizar ingredientes de la receta
    public function actualizarIngredientes($id_receta, $ingredientes) {
        // Primero eliminamos los ingredientes antiguos
        $queryDelete = "DELETE FROM receta_ingredientes WHERE id_receta = :id_receta";
        $stmtDelete = $this->pdo->prepare($queryDelete);
        $stmtDelete->bindParam(':id_receta', $id_receta, PDO::PARAM_INT);
        $stmtDelete->execute();

        // Insertamos los nuevos ingredientes
        $queryInsert = "INSERT INTO receta_ingredientes (id_receta, id_ingrediente, cantidad) 
                        VALUES (:id_receta, :id_ingrediente, :cantidad)";
        $stmtInsert = $this->pdo->prepare($queryInsert);

        foreach ($ingredientes as $ingrediente) {
            $stmtInsert->bindParam(':id_receta', $id_receta, PDO::PARAM_INT);
            $stmtInsert->bindParam(':id_ingrediente', $ingrediente['id_ingrediente'], PDO::PARAM_INT);
            $stmtInsert->bindParam(':cantidad', $ingrediente['cantidad']);
            $stmtInsert->execute();
        }
    }
}

// Crear instancia de la clase Recetas
$database = new Database();
$pdo = $database->getConnection();
$recetas = new Recetas($pdo);

// Obtener la lista de recetas para el menú de selección
$recetas_lista = $recetas->obtenerRecetas();

// Verificar si se ha seleccionado una receta para editar
if (isset($_GET['id_receta'])) {
    $id_receta = $_GET['id_receta'];
    $receta = $recetas->obtenerRecetaPorId($id_receta);
    $ingredientes = $recetas->obtenerIngredientesPorId($id_receta);

    if (!$receta) {
        echo "Receta no encontrada.";
        exit;
    }
}

// Procesar el formulario de edición de receta
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_receta = $_POST['id_receta'];
    $nombre_receta = $_POST['nombre_receta'];
    $descripcion = $_POST['descripcion'];
    $tipo_comida = $_POST['tipo_comida'];
    $dieta = $_POST['dieta'];

    // Actualizar la receta
    $exito = $recetas->actualizarReceta($id_receta, $nombre_receta, $descripcion, $tipo_comida, $dieta);

    // Actualizar los ingredientes
    $ingredientes = [];
    if (isset($_POST['ingredientes'])) {
        foreach ($_POST['ingredientes'] as $id_ingrediente => $cantidad) {
            $ingredientes[] = [
                'id_ingrediente' => $id_ingrediente,
                'cantidad' => $cantidad
            ];
        }
        $recetas->actualizarIngredientes($id_receta, $ingredientes);
    }
    
    if ($exito) {
        header("Location: dashboard_admin.php"); // Redirigir al panel de administrador
        exit;
    } else {
        $error = "Hubo un error al actualizar la receta. Intenta de nuevo.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Receta</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 0;
        }
        header {
            background: #35424a;
            color: white;
            padding: 20px;
            text-align: center;
        }
        .form-container {
            width: 50%;
            margin: 40px auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .form-container h2 {
            text-align: center;
            color: #35424a;
        }
        .form-container label {
            display: block;
            margin-bottom: 5px;
            color: #333;
        }
        .form-container input,
        .form-container textarea,
        .form-container select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .form-container button {
            width: 100%;
            padding: 10px;
            background: #35424a;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .form-container button:hover {
            background: #e8491d;
        }
        .error {
            color: red;
            text-align: center;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>

<header>
    <h1>Editar Receta</h1>
</header>

<div class="form-container">
    <h2>Selecciona una receta para editar:</h2>

    <form method="GET">
        <div class="recetas-lista">
            <label for="id_receta">Recetas disponibles</label>
            <select name="id_receta" id="id_receta" onchange="this.form.submit()">
                <option value="">Selecciona una receta</option>
                <?php foreach ($recetas_lista as $receta_item): ?>
                    <option value="<?php echo $receta_item['id_receta']; ?>" <?php echo (isset($id_receta) && $id_receta == $receta_item['id_receta']) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($receta_item['nombre_receta']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
    </form>

    <?php if (isset($receta)): ?>
        <h2>Editar Receta</h2>
        <?php if (!empty($error)): ?>
            <p class="error"><?php echo $error; ?></p>
        <?php endif; ?>

        <form method="POST">
            <input type="hidden" name="id_receta" value="<?php echo $receta['id_receta']; ?>">

            <label for="nombre_receta">Nombre de la receta</label>
            <input type="text" name="nombre_receta" id="nombre_receta" value="<?php echo htmlspecialchars($receta['nombre_receta']); ?>" required>

            <label for="descripcion">Descripción</label>
            <textarea name="descripcion" id="descripcion" rows="4" required><?php echo htmlspecialchars($receta['descripcion']); ?></textarea>

            <label for="tipo_comida">Tipo de comida</label>
            <select name="tipo_comida" id="tipo_comida">
                <option value="desayuno" <?php echo $receta['tipo_comida'] === 'desayuno' ? 'selected' : ''; ?>>Desayuno</option>
                <option value="almuerzo" <?php echo $receta['tipo_comida'] === 'almuerzo' ? 'selected' : ''; ?>>Almuerzo</option>
                <option value="cena" <?php echo $receta['tipo_comida'] === 'cena' ? 'selected' : ''; ?>>Cena</option>
            </select>

            <label for="dieta">Dieta</label>
            <select name="dieta" id="dieta">
                <option value="normal" <?php echo $receta['dieta'] === 'normal' ? 'selected' : ''; ?>>Normal</option>
                <option value="sin_gluten" <?php echo $receta['dieta'] === 'sin_gluten' ? 'selected' : ''; ?>>Sin Gluten</option>
                <option value="vegetariano" <?php echo $receta['dieta'] === 'vegetariano' ? 'selected' : ''; ?>>Vegetariano</option>
                <option value="vegano" <?php echo $receta['dieta'] === 'vegano' ? 'selected' : ''; ?>>Vegano</option>
            </select>

            <h3>Ingredientes</h3>
            <?php foreach ($ingredientes as $ingrediente): ?>
                <label for="ingrediente_<?php echo $ingrediente['id_ingrediente']; ?>">
                    <?php echo htmlspecialchars($ingrediente['nombre_ingrediente']); ?>:
                    <input type="number" name="ingredientes[<?php echo $ingrediente['id_ingrediente']; ?>]" 
                           value="<?php echo htmlspecialchars($ingrediente['cantidad']); ?>" required>
                </label><br>
            <?php endforeach; ?>

            <button type="submit">Actualizar Receta</button>
        </form>
    <?php endif; ?>
</div>

</body>
</html>

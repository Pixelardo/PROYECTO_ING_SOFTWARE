<?php
session_start();
require_once 'includes/connection_db.php';

class Auth {
    private $db;

    public function __construct() {
        $this->db = (new Database())->getConnection();
    }

    // Método para iniciar sesión
    public function login($email, $password) {
        $sql = "SELECT * FROM usuarios WHERE email = :email AND contrasena = :contrasena";
        $stmt = $this->db->prepare($sql);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':contrasena', $password);
        $stmt->execute();
        
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        return $user ? $user : false;
    }
}

// Si el formulario es enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    // Instanciar la clase de autenticación
    $auth = new Auth();
    $user = $auth->login($email, $password);

    if ($user) {
        // Guardar los datos del usuario en la sesión
        $_SESSION['user_id'] = $user['id_usuario'];
        $_SESSION['user_nombre'] = $user['nombre'];
        $_SESSION['user_email'] = $user['email'];
        $_SESSION['user_tipo'] = $user['rol']; // Guardamos el rol (admin o usuario)

        // Redirigir según el rol del usuario
        if ($user['rol'] === 'admin') {
            header("Location: dashboard_admin.php");
        } else {
            header("Location: dashboard_usuario.php");
        }
        exit;
    } else {
        $error = "Correo o contraseña incorrectos.";
    }
}

// Verificación si el usuario ya está logueado (prevenir que alguien acceda al login si ya está logueado)
if (isset($_SESSION['user_id'])) {
    if ($_SESSION['user_tipo'] === 'admin') {
        header("Location: dashboard_admin.php");
    } else {
        header("Location: dashboard_usuario.php");
    }
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #35424a;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .form-container {
            background: white;
            padding: 60px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 320px; /* Ajuste el tamaño del formulario */
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .form-container h1 {
            text-align: center;
            margin-bottom: 20px;
            font-size: 24px;
            color: #35424a;
        }
        .form-container label {
            display: block;
            margin-bottom: 8px;
            color: #333;
            font-size: 14px;
        }
        .form-container input {
            width: 100%;
            padding: 12px; /* Aumenté el padding para hacerlo más grande */
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }
        .form-container input:focus {
            border-color: #e8491d; /* Color al hacer foco */
            box-shadow: 0 0 8px rgba(232, 73, 29, 0.5);
            outline: none; /* Elimina el borde azul por defecto */
        }
        .form-container button {
            width: 100%;
            padding: 12px;
            background: #35424a;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        .form-container button:hover {
            background: #e8491d;
        }
        .form-container .register-link {
            text-align: center;
            margin-top: 15px;
        }
        .form-container .register-link a {
            text-decoration: none;
            color: #35424a;
            font-size: 14px;
        }
        .form-container .register-link a:hover {
            color: #e8491d;
        }
        .logo-container {
            text-align: center;
            margin-bottom: 20px;
        }
        .logo-container img {
            width: 150px;
            height: auto;
        }
        .error {
            color: red;
            text-align: center;
            margin-bottom: 10px;
        }
        /* Botón de Volver en la esquina superior izquierda */
        .btn-back {
            position: absolute;
            top: 20px;
            left: 20px;
            background-color: #35424a;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            font-size: 14px;
        }

        .btn-back:hover {
            background-color: #e8491d;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <div class="logo-container">
            <img src="logod.png" alt="Logo"> <!-- Ajusta la ruta de la imagen según sea necesario -->
        </div>
        <!-- Botón de Volver -->
    <a href="index.php" class="btn-back">Volver</a>
        <h1>Login</h1>

        <?php if (!empty($error)): ?>
            <p class="error"><?php echo htmlspecialchars($error); ?></p>
        <?php endif; ?>

        <form method="POST">
            <label for="email">Correo Electrónico</label>
            <input type="email" name="email" id="email" required>

            <label for="password">Contraseña</label>
            <input type="password" name="password" id="password" required>

            <button type="submit">Iniciar Sesión</button>
        </form>

        <div class="register-link">
            <p>¿No tienes cuenta? <a href="register.php">¡Regístrate aquí!</a></p>
        </div>
    </div>
</body>
</html>

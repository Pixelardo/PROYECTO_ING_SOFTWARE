<?php
session_start();
require_once 'includes/Auth.php'; // Incluye la clase que maneja la autenticación

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Recibe los datos de login desde el formulario
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Instancia de la clase Auth
    $auth = new Auth();
    
    // Intenta autenticar al usuario
    $user = $auth->login($email, $password);

    // Si el usuario es autenticado correctamente
    if ($user) {
        // Guarda el ID, el nombre completo, correo y tipo de usuario en la sesión
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_nombre'] = $user['nombre_usuario'];  // Guarda el nombre del usuario
        $_SESSION['user_email'] = $user['correo']; // Guarda el correo en la sesión
        $_SESSION['user_tipo'] = $user['tipo']; // Tipo de usuario (admin/usuario)

        // Verifica si ya estás logueado y redirige al dashboard correspondiente
        if ($user['tipo'] === 'admin') {
            header("Location: dashboard_admin.php");
        } else {
            header("Location: dashboard_usuario.php");
        }
        exit();
    } else {
        // Si las credenciales no son correctas, guarda un mensaje de error en la sesión
        $_SESSION['error'] = 'Credenciales incorrectas.';
        header("Location: login.php");
        exit();
    }
}
?>
